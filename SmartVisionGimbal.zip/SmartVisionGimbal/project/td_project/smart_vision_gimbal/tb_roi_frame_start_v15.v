`timescale 1ns/1ps
module tb_roi_frame_start_v15;
    reg clk=0, rst_n=0;
    wire vs, hs, de, user, last, roi_valid, roi_frame_start;
    wire [10:0] roi_x;
    wire [9:0] roi_y;
    integer user_frames=0, output_starts=0, cycles_after_user=0;
    always #5 clk=~clk;

    uivtc #(.H_ActiveSize(1280),.H_FrameSize(1650),.H_SyncStart(1390),
      .H_SyncEnd(1430),.V_ActiveSize(720),.V_FrameSize(750),
      .V_SyncStart(725),.V_SyncEnd(730)) vtc (
      .I_vtc_rstn(rst_n),.I_vtc_clk(clk),.O_vtc_vs(vs),.O_vtc_hs(hs),
      .O_vtc_de_valid(de),.O_vtc_user(user),.O_vtc_last(last));

    hdmi_mixer #(.IMG_WIDTH(1280),.IMG_HEIGHT(720)) mixer (
      .I_clk(clk),.I_rst_n(rst_n),.I_video_vsync(vs),.I_video_hsync(hs),
      .I_video_de(de),.I_video_user(user),.I_video_last(last),
      .I_debug_status(4'd0),.I_night_mode(1'b0),.I_time_setting(1'b0),
      .I_time_bcd(24'h175500),.I_latency_valid(1'b0),.I_latency_frames(8'd0),
      .I_fps_valid(1'b0),.I_fps_tenths(10'd0),.I_track_status(3'd0),
      .I_box_valid(1'b0),.I_box_x0(11'd0),.I_box_y0(10'd0),
      .I_box_x1(11'd0),.I_box_y1(10'd0),.O_video_rd_en(),
      .I_video_rd_data(24'd0),.O_hdmi_vsync(),.O_hdmi_hsync(),
      .O_hdmi_de(),.O_hdmi_data(),.O_roi_valid(roi_valid),
      .O_roi_frame_start(roi_frame_start),.O_roi_x(roi_x),.O_roi_y(roi_y),
      .O_roi_rgb());

    always @(posedge clk) begin
      if (rst_n) begin
        if (user) begin
          user_frames=user_frames+1;
          cycles_after_user=0;
        end else if (user_frames != 0) begin
          cycles_after_user=cycles_after_user+1;
        end
        if (roi_frame_start) begin
          output_starts=output_starts+1;
          if (!roi_valid) $fatal(1,"frame-start without valid ROI");
          if (cycles_after_user == 0) $fatal(1,"frame-start was not delayed from frame marker");
        end
        if (user_frames == 3 && cycles_after_user > 100) begin
          if (output_starts != 3) $fatal(1,"got %0d starts for %0d frames",output_starts,user_frames);
          $display("tb_roi_frame_start_v15 PASS");
          $finish;
        end
      end
    end
    initial begin #25 rst_n=1; #50000000; $fatal(1,"timeout"); end
endmodule

`timescale 1ns/1ps
module tb_info_font_v15;
    reg clk=0, rst_n=0;
    reg [11:0] x=0, y=0;
    reg fps_valid=0, latency_valid=0;
    reg [9:0] fps10=600;
    reg [7:0] latency=2;
    integer col, row, i;
    reg expected_pixel;
    always #5 clk=~clk;

    hdmi_mixer #(.IMG_WIDTH(1280),.IMG_HEIGHT(720)) dut (
        .I_clk(clk),.I_rst_n(rst_n),.I_video_vsync(1'b0),.I_video_hsync(1'b0),
        .I_video_de(1'b1),.I_video_user(1'b0),.I_video_last(1'b0),
        .I_debug_status(4'd0),.I_night_mode(1'b0),.I_time_setting(1'b0),
        .I_time_bcd(24'h175500),.I_latency_valid(latency_valid),
        .I_latency_frames(latency),.I_fps_valid(fps_valid),.I_fps_tenths(fps10),
        .I_track_status(3'd0),.I_box_valid(1'b0),.I_box_x0(11'd300),.I_box_y0(10'd200),
        .I_box_x1(11'd400),.I_box_y1(10'd300),.I_video_rd_data(24'hffffff),
        .O_video_rd_en(),.O_hdmi_vsync(),.O_hdmi_hsync(),.O_hdmi_de(),
        .O_hdmi_data(),.O_roi_valid(),.O_roi_x(),.O_roi_y(),.O_roi_rgb());

    task check_slot;
        input integer slot, line;
        input [5:0] expected_glyph;
        reg [4:0] pattern;
        begin
            for (row=0; row<16; row=row+1) begin
                pattern=dut.glyph_row(expected_glyph, row >> 1);
                for (col=0; col<16; col=col+1) begin
                    x=992+slot*16+col; y=16+line*20+row; #1;
                    if (dut.info_glyph !== expected_glyph)
                        $fatal(1,"glyph line=%0d slot=%0d got=%0d expected=%0d",line,slot,dut.info_glyph,expected_glyph);
                    expected_pixel=(row<14 && col<10) ? pattern[4-(col >> 1)] : 1'b0;
                    if (dut.info_pixel !== expected_pixel)
                        $fatal(1,"pixel line=%0d slot=%0d x=%0d y=%0d",line,slot,col,row);
                end
            end
        end
    endtask

    initial begin
        force dut.S_x_2d=x; force dut.S_y_2d=y;
        #20; rst_n=1;
        check_slot(0,0,28); check_slot(1,0,26); check_slot(2,0,37);
        check_slot(3,0,25); check_slot(4,0,27); check_slot(5,0,26);
        check_slot(6,0,63); check_slot(7,0,35); check_slot(8,0,38);
        check_slot(9,0,24); check_slot(10,0,12); check_slot(11,0,63);
        check_slot(12,0,36); check_slot(13,0,36); check_slot(14,0,40);
        check_slot(15,0,36); check_slot(16,0,63);
        check_slot(0,1,39); check_slot(1,1,19); check_slot(2,1,16);
        check_slot(3,1,25); check_slot(4,1,30); check_slot(5,1,63);
        check_slot(6,1,16); check_slot(7,1,25); check_slot(8,1,29);
        check_slot(9,1,26); check_slot(10,1,17); check_slot(11,1,12);
        check_slot(12,1,63); check_slot(13,1,36); check_slot(14,1,36);
        check_slot(15,1,63); check_slot(16,1,35);
        fps_valid=1; latency_valid=1; #1;
        check_slot(12,0,6); check_slot(13,0,0); check_slot(15,0,0);
        check_slot(13,1,0); check_slot(14,1,2);
        for (i=0; i<10; i=i+1) begin
            latency=i; #1; check_slot(14,1,i);
        end
        x=992; y=32; #1; if (dut.info_on) $fatal(1,"interline gap");
        x=1264; y=16; #1; if (dut.info_on) $fatal(1,"right boundary");
        $display("tb_info_font_v15 PASS"); $finish;
    end
endmodule

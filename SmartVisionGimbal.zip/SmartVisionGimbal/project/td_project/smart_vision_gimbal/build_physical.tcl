import_device ph1_35p.db -package PH1P35MDG324 -speed 3
import_db smart_vision_gimbal_gate.db
insert_debugger
place
update_timing -mode manhattan
report_timing_summary -file smart_vision_gimbal_place.timing
report_area -io_info -file smart_vision_gimbal_phy.area
export_db smart_vision_gimbal_place.db
route
fix_hold
update_timing -mode final
report_timing_status -file smart_vision_gimbal_phy.ts
report_timing_summary -file smart_vision_gimbal_pr.timing
report_area -io_info -file smart_vision_gimbal_pr.area
flow_status -file route_flow.status
export_db smart_vision_gimbal_pr.db
bitgen -bit smart_vision_gimbal.bit

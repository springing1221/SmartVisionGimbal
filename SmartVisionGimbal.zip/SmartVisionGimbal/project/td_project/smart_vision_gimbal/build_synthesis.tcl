import_device ph1_35p.db -package PH1P35MDG324 -speed 3
cd ..
open_project smart_vision_gimbal.al -single_run
load_run_param -run syn_1
cd smart_vision_gimbal
elaborate -top smart_vision_gimbal_top
read_adc constraints/pin_auto_gimbal.adc
read_ip_adc -ip ddr2 -file ../../user_source/hdl_source/ph1p35_ddr/ddr2/src/adc/ddr2.adc
read_sdc ../camera_to_dsi_display.sdc
read_sdc -ip ddr2 ../../user_source/hdl_source/ph1p35_ddr/ddr2/src/sdc/ddr2.sdc
read_sdc -ip w128_d512_fifo ../../user_source/ip_source/w128_d512_fifo/w128_d512_fifo.tcl
insert_debugger
optimize_rtl
report_area -file smart_vision_gimbal_rtl.area
optimize_gate -packarea smart_vision_gimbal_gate.area
legalize_phy_inst
update_timing
report_timing_status -file smart_vision_gimbal_gate.ts
report_timing_summary -file smart_vision_gimbal_gate.timing
export_db smart_vision_gimbal_gate.db

// Generate exactly one pulse for each debounced active-low key press.
// Holding the key does not repeat, because manual tilt trim is one degree per
// press. A new pulse is possible only after the key is stably released.
module gimbal_key_step #(
    parameter [19:0] DEBOUNCE_CYCLES = 20'd1000000
) (
    input  wire I_clk,
    input  wire I_rst_n,
    input  wire I_key_n,
    output reg  O_step
);
    reg [1:0] S_sync;
    reg       S_stable_key_n;
    reg [19:0] S_count;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            S_sync <= 2'b11;
            S_stable_key_n <= 1'b1;
            S_count <= 20'd0;
            O_step <= 1'b0;
        end else begin
            S_sync <= {S_sync[0], I_key_n};
            O_step <= 1'b0;
            if (S_sync[1] == S_stable_key_n) begin
                S_count <= 20'd0;
            end else if (S_count == DEBOUNCE_CYCLES - 20'd1) begin
                if (S_stable_key_n && !S_sync[1])
                    O_step <= 1'b1;
                S_stable_key_n <= S_sync[1];
                S_count <= 20'd0;
            end else begin
                S_count <= S_count + 20'd1;
            end
        end
    end
endmodule

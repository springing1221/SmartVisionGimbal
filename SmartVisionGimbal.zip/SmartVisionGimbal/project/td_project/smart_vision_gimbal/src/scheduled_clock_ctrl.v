module scheduled_clock_ctrl #(
    parameter integer CYCLES_PER_MS = 100000,
    parameter integer MS_PER_SECOND = 1000,
    parameter integer DEBOUNCE_MS = 10,
    parameter integer REPEAT_START_MS = 500,
    parameter integer REPEAT_PERIOD_MS = 150
) (
    input wire I_clk,
    input wire I_rst_n,
    input wire I_setting,
    input wire [3:0] I_key_n,
    output wire [1:0] O_gain_key_n,
    output wire O_tilt_step_up,
    output wire O_tilt_step_down,
    output wire [23:0] O_time_bcd,
    output reg O_night_mode
);
    localparam integer MS_WIDTH = (CYCLES_PER_MS <= 1) ? 1 : $clog2(CYCLES_PER_MS);
    localparam integer SECOND_WIDTH = (MS_PER_SECOND <= 1) ? 1 : $clog2(MS_PER_SECOND);
    localparam integer DEBOUNCE_WIDTH = (DEBOUNCE_MS <= 1) ? 1 : $clog2(DEBOUNCE_MS);
    localparam integer REPEAT_WIDTH = $clog2(REPEAT_START_MS + 1);

    reg [MS_WIDTH-1:0] ms_divider;
    reg [SECOND_WIDTH-1:0] ms_in_second;
    wire ms_tick = ms_divider == CYCLES_PER_MS - 1;

    reg [3:0] key_sync1, key_sync2, key_stable_n, key_previous_n;
    reg [DEBOUNCE_WIDTH-1:0] key_debounce [0:3];
    reg normal_keys_ready, edit_keys_ready, setting_previous;
    reg [1:0] held_key;
    reg held_key_valid, repeating;
    reg [REPEAT_WIDTH-1:0] held_ms;
    integer key_index;

    reg [3:0] hour_tens, hour_ones;
    reg [3:0] minute_tens, minute_ones;
    reg [3:0] second_tens, second_ones;
    wire [3:0] key_press = key_previous_n & ~key_stable_n;
    wire [3:0] down = ~key_stable_n;
    wire one_key_down = down == 4'b0001 || down == 4'b0010 ||
                        down == 4'b0100 || down == 4'b1000;
    wire [1:0] selected_key = down[0] ? 2'd0 :
                              down[1] ? 2'd1 :
                              down[2] ? 2'd2 : 2'd3;
    wire repeat_due = I_setting && edit_keys_ready && ms_tick &&
                      held_key_valid && one_key_down &&
                      selected_key == held_key &&
                      held_ms == (repeating ? REPEAT_PERIOD_MS - 1 :
                                               REPEAT_START_MS - 1);
    wire [3:0] edit_step = I_setting && edit_keys_ready && one_key_down ?
                           (key_press | (repeat_due ? (4'b0001 << held_key) : 4'b0000)) :
                           4'b0000;
    wire scheduled_night = (hour_tens == 4'd2) ||
                           (hour_tens == 4'd1 && hour_ones >= 4'd8) ||
                           (hour_tens == 4'd0 && hour_ones < 4'd6);

    assign O_gain_key_n = (!I_setting && normal_keys_ready) ?
                          key_stable_n[1:0] : 2'b11;
    assign O_tilt_step_up = !I_setting && normal_keys_ready && key_press[2];
    assign O_tilt_step_down = !I_setting && normal_keys_ready && key_press[3];
    assign O_time_bcd = {hour_tens, hour_ones, minute_tens, minute_ones,
                         second_tens, second_ones};

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            ms_divider <= 0;
            key_sync1 <= 4'hf;
            key_sync2 <= 4'hf;
            key_stable_n <= 4'hf;
            key_previous_n <= 4'hf;
            normal_keys_ready <= 1'b0;
            edit_keys_ready <= 1'b0;
            setting_previous <= 1'b0;
            held_key <= 0;
            held_key_valid <= 1'b0;
            repeating <= 1'b0;
            held_ms <= 0;
            for (key_index = 0; key_index < 4; key_index = key_index + 1)
                key_debounce[key_index] <= 0;
        end else begin
            key_sync1 <= I_key_n;
            key_sync2 <= key_sync1;
            key_previous_n <= key_stable_n;
            setting_previous <= I_setting;
            ms_divider <= ms_tick ? {MS_WIDTH{1'b0}} : ms_divider + 1'b1;

            if (ms_tick) begin
                for (key_index = 0; key_index < 4; key_index = key_index + 1) begin
                    if (key_sync2[key_index] == key_stable_n[key_index])
                        key_debounce[key_index] <= 0;
                    else if (key_debounce[key_index] == DEBOUNCE_MS - 1) begin
                        key_stable_n[key_index] <= key_sync2[key_index];
                        key_debounce[key_index] <= 0;
                    end else
                        key_debounce[key_index] <= key_debounce[key_index] + 1'b1;
                end
            end

            if (I_setting != setting_previous) begin
                normal_keys_ready <= 1'b0;
                edit_keys_ready <= 1'b0;
                held_key_valid <= 1'b0;
                repeating <= 1'b0;
                held_ms <= 0;
            end else if (I_setting) begin
                if (key_stable_n == 4'hf && key_sync2 == 4'hf &&
                    key_sync1 == 4'hf && I_key_n == 4'hf)
                    edit_keys_ready <= 1'b1;
                if (ms_tick) begin
                    if (!edit_keys_ready || !one_key_down) begin
                        held_key_valid <= 1'b0;
                        repeating <= 1'b0;
                        held_ms <= 0;
                    end else if (!held_key_valid || selected_key != held_key) begin
                        held_key <= selected_key;
                        held_key_valid <= 1'b1;
                        repeating <= 1'b0;
                        held_ms <= 0;
                    end else if (repeat_due) begin
                        repeating <= 1'b1;
                        held_ms <= 0;
                    end else
                        held_ms <= held_ms + 1'b1;
                end
            end else if (key_stable_n == 4'hf && key_sync2 == 4'hf &&
                         key_sync1 == 4'hf && I_key_n == 4'hf) begin
                normal_keys_ready <= 1'b1;
            end
        end
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            ms_in_second <= 0;
            hour_tens <= 4'd1;
            hour_ones <= 4'd7;
            minute_tens <= 4'd5;
            minute_ones <= 4'd5;
            second_tens <= 0;
            second_ones <= 0;
            O_night_mode <= 1'b0;
        end else if (I_setting) begin
            ms_in_second <= 0;
            second_tens <= 0;
            second_ones <= 0;
            if (edit_step[0]) begin
                if (hour_tens == 0 && hour_ones == 0) begin
                    hour_tens <= 4'd2;
                    hour_ones <= 4'd3;
                end else if (hour_ones == 0) begin
                    hour_tens <= hour_tens - 1'b1;
                    hour_ones <= 4'd9;
                end else
                    hour_ones <= hour_ones - 1'b1;
            end else if (edit_step[1]) begin
                if (hour_tens == 4'd2 && hour_ones == 4'd3) begin
                    hour_tens <= 0;
                    hour_ones <= 0;
                end else if (hour_ones == 4'd9) begin
                    hour_tens <= hour_tens + 1'b1;
                    hour_ones <= 0;
                end else
                    hour_ones <= hour_ones + 1'b1;
            end else if (edit_step[2]) begin
                if (minute_tens == 4'd5 && minute_ones == 4'd9) begin
                    minute_tens <= 0;
                    minute_ones <= 0;
                end else if (minute_ones == 4'd9) begin
                    minute_tens <= minute_tens + 1'b1;
                    minute_ones <= 0;
                end else
                    minute_ones <= minute_ones + 1'b1;
            end else if (edit_step[3]) begin
                if (minute_tens == 0 && minute_ones == 0) begin
                    minute_tens <= 4'd5;
                    minute_ones <= 4'd9;
                end else if (minute_ones == 0) begin
                    minute_tens <= minute_tens - 1'b1;
                    minute_ones <= 4'd9;
                end else
                    minute_ones <= minute_ones - 1'b1;
            end
        end else if (setting_previous) begin
            ms_in_second <= 0;
            second_tens <= 0;
            second_ones <= 0;
            O_night_mode <= scheduled_night;
        end else if (ms_tick) begin
            if (ms_in_second == MS_PER_SECOND - 1) begin
                ms_in_second <= 0;
                if (second_ones != 4'd9)
                    second_ones <= second_ones + 1'b1;
                else begin
                    second_ones <= 0;
                    if (second_tens != 4'd5)
                        second_tens <= second_tens + 1'b1;
                    else begin
                        second_tens <= 0;
                        if (minute_ones != 4'd9)
                            minute_ones <= minute_ones + 1'b1;
                        else begin
                            minute_ones <= 0;
                            if (minute_tens != 4'd5)
                                minute_tens <= minute_tens + 1'b1;
                            else begin
                                minute_tens <= 0;
                                if (hour_tens == 4'd2 && hour_ones == 4'd3) begin
                                    hour_tens <= 0;
                                    hour_ones <= 0;
                                end else if (hour_ones == 4'd9) begin
                                    hour_tens <= hour_tens + 1'b1;
                                    hour_ones <= 0;
                                end else
                                    hour_ones <= hour_ones + 1'b1;
                                if (hour_tens == 4'd1 && hour_ones == 4'd7)
                                    O_night_mode <= 1'b1;
                                else if (hour_tens == 0 && hour_ones == 4'd5)
                                    O_night_mode <= 1'b0;
                            end
                        end
                    end
                end
            end else
                ms_in_second <= ms_in_second + 1'b1;
        end
    end
endmodule

// Transfers one completed box-center result into the 100-MHz servo domain.
// Source data is held until the next frame result, so the destination waits
// two additional clocks after the synchronized toggle before sampling it.
module gimbal_result_cdc (
    input  wire        I_src_clk,
    input  wire        I_src_rst_n,
    input  wire        I_src_update,
    input  wire [10:0] I_src_x,
    input  wire [9:0]  I_src_y,
    input  wire        I_src_valid,
    input  wire        I_dst_clk,
    input  wire        I_dst_rst_n,
    output reg  [10:0] O_dst_x,
    output reg  [9:0]  O_dst_y,
    output reg         O_dst_valid,
    output reg         O_dst_update
);
    reg [10:0] S_src_x;
    reg [9:0]  S_src_y;
    reg        S_src_valid;
    reg        S_req_toggle;
    reg        S_req_sync_0;
    reg        S_req_sync_1;
    reg        S_req_seen;
    reg [1:0]  S_settle_count;
    reg        S_capture_pending;

    always @(posedge I_src_clk or negedge I_src_rst_n) begin
        if (!I_src_rst_n) begin
            S_src_x      <= 11'd640;
            S_src_y      <= 10'd360;
            S_src_valid  <= 1'b0;
            S_req_toggle <= 1'b0;
        end else if (I_src_update) begin
            S_src_x      <= I_src_x;
            S_src_y      <= I_src_y;
            S_src_valid  <= I_src_valid;
            S_req_toggle <= ~S_req_toggle;
        end
    end

    always @(posedge I_dst_clk or negedge I_dst_rst_n) begin
        if (!I_dst_rst_n) begin
            S_req_sync_0      <= 1'b0;
            S_req_sync_1      <= 1'b0;
            S_req_seen        <= 1'b0;
            S_settle_count    <= 2'd0;
            S_capture_pending <= 1'b0;
            O_dst_x           <= 11'd640;
            O_dst_y           <= 10'd360;
            O_dst_valid       <= 1'b0;
            O_dst_update      <= 1'b0;
        end else begin
            O_dst_update <= 1'b0;
            S_req_sync_0 <= S_req_toggle;
            S_req_sync_1 <= S_req_sync_0;

            if (!S_capture_pending && (S_req_sync_1 != S_req_seen)) begin
                S_req_seen        <= S_req_sync_1;
                S_capture_pending <= 1'b1;
                S_settle_count    <= 2'd2;
            end else if (S_capture_pending) begin
                if (S_settle_count != 2'd0)
                    S_settle_count <= S_settle_count - 2'd1;
                else begin
                    O_dst_x           <= S_src_x;
                    O_dst_y           <= S_src_y;
                    O_dst_valid       <= S_src_valid;
                    O_dst_update      <= 1'b1;
                    S_capture_pending <= 1'b0;
                end
            end
        end
    end
endmodule

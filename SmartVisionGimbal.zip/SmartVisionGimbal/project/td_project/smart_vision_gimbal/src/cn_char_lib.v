// 16x16 中文字库（宋体点阵，自动生成）
module cn_char_lib (
    input  wire [3:0] I_char,   // 字符索引 0~13
    input  wire [3:0] I_row,    // 行 0~15
    output reg  [15:0] O_row_bits
);

    localparam C_YUAN = 4'd0;
    localparam C_TU = 4'd1;
    localparam C_HUI = 4'd2;
    localparam C_DU = 4'd3;
    localparam C_ER = 4'd4;
    localparam C_ZHI = 4'd5;
    localparam C_HUA = 4'd6;
    localparam C_BIAN = 4'd7;
    localparam C_YUAN2 = 4'd8;
    localparam C_WEI = 4'd9;
    localparam C_CAI = 4'd10;
    localparam C_SE = 4'd11;
    localparam C_KA = 4'd12;
    localparam C_TONG = 4'd13;
    localparam C_BLANK = 4'd15;   // 空白

    always @(*) begin
        case(I_char)
            C_YUAN: begin
                case(I_row)
                    4'd0: O_row_bits = 16'h3FFE;
                    4'd1: O_row_bits = 16'h2080;
                    4'd2: O_row_bits = 16'h2100;
                    4'd3: O_row_bits = 16'h27F0;
                    4'd4: O_row_bits = 16'h2410;
                    4'd5: O_row_bits = 16'h2410;
                    4'd6: O_row_bits = 16'h27F0;
                    4'd7: O_row_bits = 16'h2410;
                    4'd8: O_row_bits = 16'h2410;
                    4'd9: O_row_bits = 16'h27F0;
                    4'd10: O_row_bits = 16'h2080;
                    4'd11: O_row_bits = 16'h2490;
                    4'd12: O_row_bits = 16'h4888;
                    4'd13: O_row_bits = 16'h5284;
                    4'd14: O_row_bits = 16'h8100;
                    4'd15: O_row_bits = 16'h0000;
                    default: O_row_bits = 16'h0000;
                endcase
            end
            C_TU: begin
                case(I_row)
                    4'd0: O_row_bits = 16'h7FFC;
                    4'd1: O_row_bits = 16'h4204;
                    4'd2: O_row_bits = 16'h4204;
                    4'd3: O_row_bits = 16'h47E4;
                    4'd4: O_row_bits = 16'h4C44;
                    4'd5: O_row_bits = 16'h5284;
                    4'd6: O_row_bits = 16'h4104;
                    4'd7: O_row_bits = 16'h46C4;
                    4'd8: O_row_bits = 16'h783C;
                    4'd9: O_row_bits = 16'h4304;
                    4'd10: O_row_bits = 16'h4084;
                    4'd11: O_row_bits = 16'h4604;
                    4'd12: O_row_bits = 16'h4184;
                    4'd13: O_row_bits = 16'h7FFC;
                    4'd14: O_row_bits = 16'h4004;
                    4'd15: O_row_bits = 16'h0000;
                    default: O_row_bits = 16'h0000;
                endcase
            end
            C_HUI: begin
                case(I_row)
                    4'd0: O_row_bits = 16'h0400;
                    4'd1: O_row_bits = 16'h0400;
                    4'd2: O_row_bits = 16'h0400;
                    4'd3: O_row_bits = 16'hFFFE;
                    4'd4: O_row_bits = 16'h0800;
                    4'd5: O_row_bits = 16'h0880;
                    4'd6: O_row_bits = 16'h0884;
                    4'd7: O_row_bits = 16'h1284;
                    4'd8: O_row_bits = 16'h1288;
                    4'd9: O_row_bits = 16'h2490;
                    4'd10: O_row_bits = 16'h2940;
                    4'd11: O_row_bits = 16'h4140;
                    4'd12: O_row_bits = 16'h8220;
                    4'd13: O_row_bits = 16'h0410;
                    4'd14: O_row_bits = 16'h1808;
                    4'd15: O_row_bits = 16'h6006;
                    default: O_row_bits = 16'h0000;
                endcase
            end
            C_DU: begin
                case(I_row)
                    4'd0: O_row_bits = 16'h0100;
                    4'd1: O_row_bits = 16'h0080;
                    4'd2: O_row_bits = 16'h3FFE;
                    4'd3: O_row_bits = 16'h2220;
                    4'd4: O_row_bits = 16'h2220;
                    4'd5: O_row_bits = 16'h3FFC;
                    4'd6: O_row_bits = 16'h2220;
                    4'd7: O_row_bits = 16'h2220;
                    4'd8: O_row_bits = 16'h23E0;
                    4'd9: O_row_bits = 16'h2000;
                    4'd10: O_row_bits = 16'h2FF0;
                    4'd11: O_row_bits = 16'h2410;
                    4'd12: O_row_bits = 16'h4220;
                    4'd13: O_row_bits = 16'h41C0;
                    4'd14: O_row_bits = 16'h8630;
                    4'd15: O_row_bits = 16'h380E;
                    default: O_row_bits = 16'h0000;
                endcase
            end
            C_ER: begin
                case(I_row)
                    4'd0: O_row_bits = 16'h0000;
                    4'd1: O_row_bits = 16'h0000;
                    4'd2: O_row_bits = 16'h3FF8;
                    4'd3: O_row_bits = 16'h0000;
                    4'd4: O_row_bits = 16'h0000;
                    4'd5: O_row_bits = 16'h0000;
                    4'd6: O_row_bits = 16'h0000;
                    4'd7: O_row_bits = 16'h0000;
                    4'd8: O_row_bits = 16'h0000;
                    4'd9: O_row_bits = 16'h0000;
                    4'd10: O_row_bits = 16'h0000;
                    4'd11: O_row_bits = 16'hFFFE;
                    4'd12: O_row_bits = 16'h0000;
                    4'd13: O_row_bits = 16'h0000;
                    4'd14: O_row_bits = 16'h0000;
                    4'd15: O_row_bits = 16'h0000;
                    default: O_row_bits = 16'h0000;
                endcase
            end
            C_ZHI: begin
                case(I_row)
                    4'd0: O_row_bits = 16'h0840;
                    4'd1: O_row_bits = 16'h0840;
                    4'd2: O_row_bits = 16'h0FFC;
                    4'd3: O_row_bits = 16'h1040;
                    4'd4: O_row_bits = 16'h1040;
                    4'd5: O_row_bits = 16'h33F8;
                    4'd6: O_row_bits = 16'h3208;
                    4'd7: O_row_bits = 16'h53F8;
                    4'd8: O_row_bits = 16'h9208;
                    4'd9: O_row_bits = 16'h13F8;
                    4'd10: O_row_bits = 16'h1208;
                    4'd11: O_row_bits = 16'h13F8;
                    4'd12: O_row_bits = 16'h1208;
                    4'd13: O_row_bits = 16'h1208;
                    4'd14: O_row_bits = 16'h1FFE;
                    4'd15: O_row_bits = 16'h1000;
                    default: O_row_bits = 16'h0000;
                endcase
            end
            C_HUA: begin
                case(I_row)
                    4'd0: O_row_bits = 16'h0880;
                    4'd1: O_row_bits = 16'h0880;
                    4'd2: O_row_bits = 16'h0884;
                    4'd3: O_row_bits = 16'h1088;
                    4'd4: O_row_bits = 16'h1090;
                    4'd5: O_row_bits = 16'h30A0;
                    4'd6: O_row_bits = 16'h30C0;
                    4'd7: O_row_bits = 16'h5080;
                    4'd8: O_row_bits = 16'h9180;
                    4'd9: O_row_bits = 16'h1280;
                    4'd10: O_row_bits = 16'h1480;
                    4'd11: O_row_bits = 16'h1082;
                    4'd12: O_row_bits = 16'h1082;
                    4'd13: O_row_bits = 16'h1082;
                    4'd14: O_row_bits = 16'h107E;
                    4'd15: O_row_bits = 16'h1000;
                    default: O_row_bits = 16'h0000;
                endcase
            end
            C_BIAN: begin
                case(I_row)
                    4'd0: O_row_bits = 16'h0040;
                    4'd1: O_row_bits = 16'h2040;
                    4'd2: O_row_bits = 16'h1040;
                    4'd3: O_row_bits = 16'h13FC;
                    4'd4: O_row_bits = 16'h0044;
                    4'd5: O_row_bits = 16'h0044;
                    4'd6: O_row_bits = 16'hF044;
                    4'd7: O_row_bits = 16'h1084;
                    4'd8: O_row_bits = 16'h1084;
                    4'd9: O_row_bits = 16'h1104;
                    4'd10: O_row_bits = 16'h1104;
                    4'd11: O_row_bits = 16'h1228;
                    4'd12: O_row_bits = 16'h1410;
                    4'd13: O_row_bits = 16'h2800;
                    4'd14: O_row_bits = 16'h47FE;
                    4'd15: O_row_bits = 16'h0000;
                    default: O_row_bits = 16'h0000;
                endcase
            end
            C_YUAN2: begin
                case(I_row)
                    4'd0: O_row_bits = 16'h1080;
                    4'd1: O_row_bits = 16'h10FC;
                    4'd2: O_row_bits = 16'h2104;
                    4'd3: O_row_bits = 16'h21F8;
                    4'd4: O_row_bits = 16'h4808;
                    4'd5: O_row_bits = 16'hFBFE;
                    4'd6: O_row_bits = 16'h1040;
                    4'd7: O_row_bits = 16'h20A2;
                    4'd8: O_row_bits = 16'h4334;
                    4'd9: O_row_bits = 16'hF858;
                    4'd10: O_row_bits = 16'h4094;
                    4'd11: O_row_bits = 16'h0334;
                    4'd12: O_row_bits = 16'h1852;
                    4'd13: O_row_bits = 16'hE090;
                    4'd14: O_row_bits = 16'h4350;
                    4'd15: O_row_bits = 16'h0020;
                    default: O_row_bits = 16'h0000;
                endcase
            end
            C_WEI: begin
                case(I_row)
                    4'd0: O_row_bits = 16'h0840;
                    4'd1: O_row_bits = 16'h0A40;
                    4'd2: O_row_bits = 16'h0940;
                    4'd3: O_row_bits = 16'h1140;
                    4'd4: O_row_bits = 16'h1040;
                    4'd5: O_row_bits = 16'h37FC;
                    4'd6: O_row_bits = 16'h3044;
                    4'd7: O_row_bits = 16'h5044;
                    4'd8: O_row_bits = 16'h9084;
                    4'd9: O_row_bits = 16'h10A4;
                    4'd10: O_row_bits = 16'h1094;
                    4'd11: O_row_bits = 16'h1114;
                    4'd12: O_row_bits = 16'h1104;
                    4'd13: O_row_bits = 16'h1204;
                    4'd14: O_row_bits = 16'h1428;
                    4'd15: O_row_bits = 16'h1810;
                    default: O_row_bits = 16'h0000;
                endcase
            end
            C_CAI: begin
                case(I_row)
                    4'd0: O_row_bits = 16'h0100;
                    4'd1: O_row_bits = 16'h0784;
                    4'd2: O_row_bits = 16'h7804;
                    4'd3: O_row_bits = 16'h0888;
                    4'd4: O_row_bits = 16'h4490;
                    4'd5: O_row_bits = 16'h2522;
                    4'd6: O_row_bits = 16'h2002;
                    4'd7: O_row_bits = 16'h0404;
                    4'd8: O_row_bits = 16'h7F88;
                    4'd9: O_row_bits = 16'h0C10;
                    4'd10: O_row_bits = 16'h1622;
                    4'd11: O_row_bits = 16'h1502;
                    4'd12: O_row_bits = 16'h2484;
                    4'd13: O_row_bits = 16'h4408;
                    4'd14: O_row_bits = 16'h8410;
                    4'd15: O_row_bits = 16'h0460;
                    default: O_row_bits = 16'h0000;
                endcase
            end
            C_SE: begin
                case(I_row)
                    4'd0: O_row_bits = 16'h0800;
                    4'd1: O_row_bits = 16'h0800;
                    4'd2: O_row_bits = 16'h1FE0;
                    4'd3: O_row_bits = 16'h2020;
                    4'd4: O_row_bits = 16'h4040;
                    4'd5: O_row_bits = 16'hBFF8;
                    4'd6: O_row_bits = 16'h2108;
                    4'd7: O_row_bits = 16'h2108;
                    4'd8: O_row_bits = 16'h2108;
                    4'd9: O_row_bits = 16'h3FF8;
                    4'd10: O_row_bits = 16'h2000;
                    4'd11: O_row_bits = 16'h2002;
                    4'd12: O_row_bits = 16'h2002;
                    4'd13: O_row_bits = 16'h2002;
                    4'd14: O_row_bits = 16'h1FFE;
                    4'd15: O_row_bits = 16'h0000;
                    default: O_row_bits = 16'h0000;
                endcase
            end
            C_KA: begin
                case(I_row)
                    4'd0: O_row_bits = 16'h0200;
                    4'd1: O_row_bits = 16'h0200;
                    4'd2: O_row_bits = 16'h03F8;
                    4'd3: O_row_bits = 16'h0200;
                    4'd4: O_row_bits = 16'h0200;
                    4'd5: O_row_bits = 16'h0200;
                    4'd6: O_row_bits = 16'hFFFE;
                    4'd7: O_row_bits = 16'h0200;
                    4'd8: O_row_bits = 16'h0200;
                    4'd9: O_row_bits = 16'h0240;
                    4'd10: O_row_bits = 16'h0220;
                    4'd11: O_row_bits = 16'h0210;
                    4'd12: O_row_bits = 16'h0208;
                    4'd13: O_row_bits = 16'h0200;
                    4'd14: O_row_bits = 16'h0200;
                    4'd15: O_row_bits = 16'h0200;
                    default: O_row_bits = 16'h0000;
                endcase
            end
            C_TONG: begin
                case(I_row)
                    4'd0: O_row_bits = 16'h47F8;
                    4'd1: O_row_bits = 16'h2010;
                    4'd2: O_row_bits = 16'h21A0;
                    4'd3: O_row_bits = 16'h0040;
                    4'd4: O_row_bits = 16'h07FC;
                    4'd5: O_row_bits = 16'hE444;
                    4'd6: O_row_bits = 16'h2444;
                    4'd7: O_row_bits = 16'h27FC;
                    4'd8: O_row_bits = 16'h2444;
                    4'd9: O_row_bits = 16'h2444;
                    4'd10: O_row_bits = 16'h27FC;
                    4'd11: O_row_bits = 16'h2444;
                    4'd12: O_row_bits = 16'h2454;
                    4'd13: O_row_bits = 16'h5408;
                    4'd14: O_row_bits = 16'h8FFE;
                    4'd15: O_row_bits = 16'h0000;
                    default: O_row_bits = 16'h0000;
                endcase
            end
            default: O_row_bits = 16'h0000;
        endcase
    end

endmodule


// Gray counter crosses into the pixel domain; frame tags follow DDR bank selection.
module video_measure #(
    parameter integer PIXEL_CLOCK_HZ = 75000000
) (
    input wire I_clk, I_rst_n,
    input wire [15:0] I_camera_gray,
    input wire [15:0] I_read_sequence,
    input wire I_read_valid, I_read_toggle,
    input wire I_output_first_pixel,
    output reg [9:0] O_fps_tenths,
    output reg O_fps_valid,
    output reg [7:0] O_delay_frames,
    output reg O_delay_valid
);
    (* ASYNC_REG = "TRUE" *) reg [15:0] gray_sync1, gray_sync2;
    (* ASYNC_REG = "TRUE" *) reg toggle1, toggle2;
    reg toggle_seen, tag_ready, tag_valid;
    reg [15:0] tag_hold;
    reg [2:0] tag_settle;
    reg [26:0] second_ticks;
    reg [15:0] camera_prev;
    reg [7:0] buckets [0:9];
    reg [3:0] bucket_index, bucket_fill;
    reg [10:0] bucket_sum;
    reg [3:0] idle_seconds;
    integer j;
    function [15:0] from_gray;
        input [15:0] value;
        integer bit_index;
        begin
            from_gray[15]=value[15];
            for (bit_index=14; bit_index>=0; bit_index=bit_index-1)
                from_gray[bit_index]=from_gray[bit_index+1] ^ value[bit_index];
        end
    endfunction
    wire [15:0] camera_now = from_gray(gray_sync2);
    wire [15:0] frame_delta = camera_now - camera_prev;
    wire [7:0] bucket_new = frame_delta > 255 ? 8'd255 : frame_delta[7:0];
    wire [10:0] next_sum = bucket_sum - {3'd0,buckets[bucket_index]} + {3'd0,bucket_new};
    wire [15:0] age = camera_now - tag_hold;
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            gray_sync1<=0; gray_sync2<=0; toggle1<=0; toggle2<=0;
            toggle_seen<=0; tag_ready<=0; tag_valid<=0; tag_hold<=0; tag_settle<=0;
            second_ticks<=0; camera_prev<=0; bucket_index<=0; bucket_fill<=0;
            bucket_sum<=0; idle_seconds<=0; O_fps_tenths<=0; O_fps_valid<=0;
            O_delay_frames<=0; O_delay_valid<=0;
            for (j=0;j<10;j=j+1) buckets[j]<=0;
        end else begin
            gray_sync1<=I_camera_gray; gray_sync2<=gray_sync1;
            toggle1<=I_read_toggle; toggle2<=toggle1;
            if (toggle2 != toggle_seen) begin
                toggle_seen<=toggle2; tag_settle<=3; tag_ready<=0;
            end else if (tag_settle != 0) begin
                tag_settle<=tag_settle-1'b1;
                if (tag_settle == 1) begin
                    tag_hold<=I_read_sequence; tag_valid<=I_read_valid; tag_ready<=1;
                end
            end
            if (second_ticks == PIXEL_CLOCK_HZ-1) begin
                second_ticks<=0; camera_prev<=camera_now;
                buckets[bucket_index]<=bucket_new; bucket_sum<=next_sum;
                bucket_index<=bucket_index == 9 ? 0 : bucket_index + 1'b1;
                if (bucket_fill < 10) bucket_fill<=bucket_fill+1'b1;
                O_fps_tenths<=next_sum > 999 ? 10'd999 : next_sum[9:0];
                O_fps_valid<=bucket_fill >= 9 && next_sum != 0 && bucket_new != 0;
                if (bucket_new == 0) begin
                    if (idle_seconds < 15) idle_seconds<=idle_seconds+1'b1;
                end else idle_seconds<=0;
            end else second_ticks<=second_ticks+1'b1;
            if (I_output_first_pixel) begin
                O_delay_valid<=tag_ready && tag_valid && idle_seconds < 2 && age < 100;
                O_delay_frames<=age[7:0];
                tag_ready<=0;
            end
        end
    end
endmodule

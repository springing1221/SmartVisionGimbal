// Result mailbox: detector values are stable for a complete camera frame.
// A toggle plus two flip-flop synchronizers transfers them into HDMI clock
// domain; the overlay latches only at HDMI frame start.
module light_hand_result_cdc(
    input wire I_src_clk,
    input wire I_src_rst_n,
    input wire I_result_toggle,
    input wire I_hand_valid,
    input wire I_lock_valid,
    input wire [1:0] I_track_state,
    input wire [3:0] I_confirm_count,
    input wire [3:0] I_lost_count,
    input wire I_candidate_valid,
    input wire [8:0] I_xmin, I_xmax,
    input wire [7:0] I_ymin, I_ymax,
    input wire I_wrist_valid,
    input wire [7:0] I_wrist_y,
    input wire [3:0] I_finger_max_runs,
    input wire [16:0] I_foreground_area,
    input wire [3:0] I_fail_code,
    input wire I_area_ok,
    input wire I_aspect_ok,
    input wire I_fill_ok,
    input wire I_segment_ok,
    input wire I_gesture_valid,
    input wire [3:0] I_gesture_code,
    input wire [3:0] I_gesture_candidate_code,
    input wire [7:0] I_gesture_best_streak_2,
    input wire [7:0] I_gesture_best_streak_3,
    input wire [7:0] I_gesture_best_streak_4,
    input wire [7:0] I_gesture_best_streak_5,
    input wire [7:0] I_gesture_narrow_best,
    input wire I_dst_clk,
    input wire I_dst_rst_n,
    output reg O_hand_valid,
    output reg O_lock_valid,
    output reg [1:0] O_track_state,
    output reg [3:0] O_confirm_count,
    output reg [3:0] O_lost_count,
    output reg O_candidate_valid,
    output reg [8:0] O_xmin, O_xmax,
    output reg [7:0] O_ymin, O_ymax,
    output reg O_wrist_valid,
    output reg [7:0] O_wrist_y,
    output reg [3:0] O_finger_max_runs,
    output reg [16:0] O_foreground_area,
    output reg [3:0] O_fail_code,
    output reg O_area_ok,
    output reg O_aspect_ok,
    output reg O_fill_ok,
    output reg O_segment_ok,
    output reg O_gesture_valid,
    output reg [3:0] O_gesture_code,
    output reg [3:0] O_gesture_candidate_code,
    output reg [7:0] O_gesture_best_streak_2,
    output reg [7:0] O_gesture_best_streak_3,
    output reg [7:0] O_gesture_best_streak_4,
    output reg [7:0] O_gesture_best_streak_5,
    output reg [7:0] O_gesture_narrow_best
);
    reg S_toggle_1d, S_toggle_2d, S_toggle_seen;
    reg S_valid_1d, S_valid_2d;
    reg S_lock_valid_1d, S_lock_valid_2d;
    reg [1:0] S_track_state_1d, S_track_state_2d;
    reg [3:0] S_confirm_count_1d, S_confirm_count_2d;
    reg [3:0] S_lost_count_1d, S_lost_count_2d;
    reg S_candidate_valid_1d, S_candidate_valid_2d;
    reg [8:0] S_xmin_1d, S_xmin_2d, S_xmax_1d, S_xmax_2d;
    reg [7:0] S_ymin_1d, S_ymin_2d, S_ymax_1d, S_ymax_2d;
    reg S_wrist_valid_1d, S_wrist_valid_2d;
    reg [7:0] S_wrist_y_1d, S_wrist_y_2d;
    reg [3:0] S_finger_max_runs_1d, S_finger_max_runs_2d;
    reg [16:0] S_foreground_area_1d, S_foreground_area_2d;
    reg [3:0] S_fail_code_1d, S_fail_code_2d;
    reg S_area_ok_1d, S_area_ok_2d, S_aspect_ok_1d, S_aspect_ok_2d;
    reg S_fill_ok_1d, S_fill_ok_2d, S_segment_ok_1d, S_segment_ok_2d;
    reg S_gesture_valid_1d, S_gesture_valid_2d;
    reg [3:0] S_gesture_code_1d, S_gesture_code_2d;
    reg [3:0] S_gesture_candidate_code_1d, S_gesture_candidate_code_2d;
    reg [7:0] S_gesture_best_streak_2_1d, S_gesture_best_streak_2_2d;
    reg [7:0] S_gesture_best_streak_3_1d, S_gesture_best_streak_3_2d;
    reg [7:0] S_gesture_best_streak_4_1d, S_gesture_best_streak_4_2d;
    reg [7:0] S_gesture_best_streak_5_1d, S_gesture_best_streak_5_2d;
    reg [7:0] S_gesture_narrow_best_1d, S_gesture_narrow_best_2d;

    always @(posedge I_dst_clk or negedge I_dst_rst_n) begin
        if(!I_dst_rst_n) begin
            S_toggle_1d <= 1'b0; S_toggle_2d <= 1'b0; S_toggle_seen <= 1'b0;
            S_valid_1d <= 1'b0; S_valid_2d <= 1'b0;
            S_lock_valid_1d <= 1'b0; S_lock_valid_2d <= 1'b0;
            S_track_state_1d <= 2'd0; S_track_state_2d <= 2'd0;
            S_confirm_count_1d <= 4'd0; S_confirm_count_2d <= 4'd0;
            S_lost_count_1d <= 4'd0; S_lost_count_2d <= 4'd0;
            S_candidate_valid_1d <= 1'b0; S_candidate_valid_2d <= 1'b0;
            S_xmin_1d <= 9'd0; S_xmin_2d <= 9'd0; S_xmax_1d <= 9'd0; S_xmax_2d <= 9'd0;
            S_ymin_1d <= 8'd0; S_ymin_2d <= 8'd0; S_ymax_1d <= 8'd0; S_ymax_2d <= 8'd0;
            S_wrist_valid_1d <= 1'b0; S_wrist_valid_2d <= 1'b0;
            S_wrist_y_1d <= 8'd0; S_wrist_y_2d <= 8'd0;
            S_finger_max_runs_1d <= 4'd0; S_finger_max_runs_2d <= 4'd0;
            S_foreground_area_1d <= 17'd0; S_foreground_area_2d <= 17'd0;
            S_fail_code_1d <= 4'd1; S_fail_code_2d <= 4'd1;
            S_area_ok_1d <= 1'b0; S_area_ok_2d <= 1'b0;
            S_aspect_ok_1d <= 1'b0; S_aspect_ok_2d <= 1'b0;
            S_fill_ok_1d <= 1'b0; S_fill_ok_2d <= 1'b0;
            S_segment_ok_1d <= 1'b0; S_segment_ok_2d <= 1'b0;
            S_gesture_valid_1d <= 1'b0; S_gesture_valid_2d <= 1'b0;
            S_gesture_code_1d <= 3'd0; S_gesture_code_2d <= 3'd0;
            S_gesture_candidate_code_1d <= 3'd0; S_gesture_candidate_code_2d <= 3'd0;
            S_gesture_best_streak_2_1d <= 8'd0; S_gesture_best_streak_2_2d <= 8'd0;
            S_gesture_best_streak_3_1d <= 8'd0; S_gesture_best_streak_3_2d <= 8'd0;
            S_gesture_best_streak_4_1d <= 8'd0; S_gesture_best_streak_4_2d <= 8'd0;
            S_gesture_best_streak_5_1d <= 8'd0; S_gesture_best_streak_5_2d <= 8'd0;
            S_gesture_narrow_best_1d <= 8'd0; S_gesture_narrow_best_2d <= 8'd0;
            O_hand_valid <= 1'b0; O_xmin <= 9'd0; O_xmax <= 9'd0;
            O_lock_valid <= 1'b0; O_track_state <= 2'd0;
            O_confirm_count <= 4'd0; O_lost_count <= 4'd0;
            O_ymin <= 8'd0; O_ymax <= 8'd0; O_wrist_valid <= 1'b0; O_wrist_y <= 8'd0;
            O_candidate_valid <= 1'b0; O_finger_max_runs <= 4'd0;
            O_foreground_area <= 17'd0; O_fail_code <= 4'd1;
            O_area_ok <= 1'b0; O_aspect_ok <= 1'b0;
            O_fill_ok <= 1'b0; O_segment_ok <= 1'b0;
            O_gesture_valid <= 1'b0; O_gesture_code <= 3'd0;
            O_gesture_candidate_code <= 3'd0;
            O_gesture_best_streak_2 <= 8'd0; O_gesture_best_streak_3 <= 8'd0;
            O_gesture_best_streak_4 <= 8'd0; O_gesture_best_streak_5 <= 8'd0;
            O_gesture_narrow_best <= 8'd0;
        end else begin
            S_toggle_1d <= I_result_toggle; S_toggle_2d <= S_toggle_1d;
            S_valid_1d <= I_hand_valid; S_valid_2d <= S_valid_1d;
            S_lock_valid_1d <= I_lock_valid; S_lock_valid_2d <= S_lock_valid_1d;
            S_track_state_1d <= I_track_state; S_track_state_2d <= S_track_state_1d;
            S_confirm_count_1d <= I_confirm_count; S_confirm_count_2d <= S_confirm_count_1d;
            S_lost_count_1d <= I_lost_count; S_lost_count_2d <= S_lost_count_1d;
            S_candidate_valid_1d <= I_candidate_valid; S_candidate_valid_2d <= S_candidate_valid_1d;
            S_xmin_1d <= I_xmin; S_xmin_2d <= S_xmin_1d; S_xmax_1d <= I_xmax; S_xmax_2d <= S_xmax_1d;
            S_ymin_1d <= I_ymin; S_ymin_2d <= S_ymin_1d; S_ymax_1d <= I_ymax; S_ymax_2d <= S_ymax_1d;
            S_wrist_valid_1d <= I_wrist_valid; S_wrist_valid_2d <= S_wrist_valid_1d;
            S_wrist_y_1d <= I_wrist_y; S_wrist_y_2d <= S_wrist_y_1d;
            S_finger_max_runs_1d <= I_finger_max_runs; S_finger_max_runs_2d <= S_finger_max_runs_1d;
            S_foreground_area_1d <= I_foreground_area; S_foreground_area_2d <= S_foreground_area_1d;
            S_fail_code_1d <= I_fail_code; S_fail_code_2d <= S_fail_code_1d;
            S_area_ok_1d <= I_area_ok; S_area_ok_2d <= S_area_ok_1d;
            S_aspect_ok_1d <= I_aspect_ok; S_aspect_ok_2d <= S_aspect_ok_1d;
            S_fill_ok_1d <= I_fill_ok; S_fill_ok_2d <= S_fill_ok_1d;
            S_segment_ok_1d <= I_segment_ok; S_segment_ok_2d <= S_segment_ok_1d;
            S_gesture_valid_1d <= I_gesture_valid; S_gesture_valid_2d <= S_gesture_valid_1d;
            S_gesture_code_1d <= I_gesture_code; S_gesture_code_2d <= S_gesture_code_1d;
            S_gesture_candidate_code_1d <= I_gesture_candidate_code;
            S_gesture_candidate_code_2d <= S_gesture_candidate_code_1d;
            S_gesture_best_streak_2_1d <= I_gesture_best_streak_2;
            S_gesture_best_streak_2_2d <= S_gesture_best_streak_2_1d;
            S_gesture_best_streak_3_1d <= I_gesture_best_streak_3;
            S_gesture_best_streak_3_2d <= S_gesture_best_streak_3_1d;
            S_gesture_best_streak_4_1d <= I_gesture_best_streak_4;
            S_gesture_best_streak_4_2d <= S_gesture_best_streak_4_1d;
            S_gesture_best_streak_5_1d <= I_gesture_best_streak_5;
            S_gesture_best_streak_5_2d <= S_gesture_best_streak_5_1d;
            S_gesture_narrow_best_1d <= I_gesture_narrow_best;
            S_gesture_narrow_best_2d <= S_gesture_narrow_best_1d;
            if(S_toggle_2d != S_toggle_seen) begin
                S_toggle_seen <= S_toggle_2d;
                O_hand_valid <= S_valid_2d;
                O_lock_valid <= S_lock_valid_2d;
                O_track_state <= S_track_state_2d;
                O_confirm_count <= S_confirm_count_2d;
                O_lost_count <= S_lost_count_2d;
                O_candidate_valid <= S_candidate_valid_2d;
                O_xmin <= S_xmin_2d; O_xmax <= S_xmax_2d;
                O_ymin <= S_ymin_2d; O_ymax <= S_ymax_2d;
                O_wrist_valid <= S_wrist_valid_2d; O_wrist_y <= S_wrist_y_2d;
                O_finger_max_runs <= S_finger_max_runs_2d;
                O_foreground_area <= S_foreground_area_2d;
                O_fail_code <= S_fail_code_2d;
                O_area_ok <= S_area_ok_2d; O_aspect_ok <= S_aspect_ok_2d;
                O_fill_ok <= S_fill_ok_2d; O_segment_ok <= S_segment_ok_2d;
                O_gesture_valid <= S_gesture_valid_2d;
                O_gesture_code <= S_gesture_code_2d;
                O_gesture_candidate_code <= S_gesture_candidate_code_2d;
                O_gesture_best_streak_2 <= S_gesture_best_streak_2_2d;
                O_gesture_best_streak_3 <= S_gesture_best_streak_3_2d;
                O_gesture_best_streak_4 <= S_gesture_best_streak_4_2d;
                O_gesture_best_streak_5 <= S_gesture_best_streak_5_2d;
                O_gesture_narrow_best <= S_gesture_narrow_best_2d;
            end
        end
    end
endmodule

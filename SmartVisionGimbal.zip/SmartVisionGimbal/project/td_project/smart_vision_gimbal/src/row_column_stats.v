// Buffer one 320-pixel sample row, reject broad exposure-artifact rows,
// and accumulate foreground columns for rows 8..144.
//
// The v15 implementation represented the row buffer, counters, and tags as
// individual registers/LUT RAM. This equivalent implementation uses compact
// synchronous memories. Candidate scanning already occurs after each frame,
// so the added read latency is absorbed by candidate_span wait states.
module row_column_stats (
    input  wire       I_clk,
    input  wire       I_rst_n,
    input  wire       I_frame_start,
    input  wire       I_valid,
    input  wire       I_foreground,
    input  wire [8:0] I_x,
    input  wire [7:0] I_y,
    input  wire [8:0] I_read_x,
    output reg  [7:0] O_column_count,
    output reg        O_frame_ready,
    output reg        O_overrun,
    output reg        O_mask_valid,
    output reg        O_mask_pixel,
    output reg  [8:0] O_mask_x,
    output reg  [7:0] O_mask_y
);
    // {frame_tag, count}. At each frame start, the 320 entries are cleared
    // sequentially while the sampler is still in its top margin. This keeps
    // v15's per-frame accumulation semantics without a 320-register clear
    // fanout, and does not rely on a tag eventually wrapping around.
    (* ram_style = "block" *) reg [8:0] column_memory [0:319];
    (* ram_style = "block" *) reg       line_memory [0:319];

    reg frame_tag;
    reg [8:0] row_sum;
    reg row_accept;

    reg clear_active;
    reg [8:0] clear_x;

    reg drain_issue;
    reg [8:0] drain_x;
    reg [7:0] drain_y;
    reg line_read_valid;
    reg [8:0] line_read_x;
    reg [7:0] line_read_y;
    reg line_read_bit;

    reg [8:0] column_read_word;
    wire line_draining = drain_issue || line_read_valid;
    wire count_enable = line_read_y < 8'd145 && row_accept && line_read_bit;

    // Memories intentionally have no reset. The frame-start clear sweep
    // initializes all counters before sampled row 8 can arrive.
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            O_column_count <= 8'd0;
            line_read_x <= 9'd0;
            line_read_y <= 8'd0;
            line_read_bit <= 1'b0;
        end else begin
        if (clear_active) begin
            // frame_tag has already advanced on the preceding frame-start
            // edge, so the cleared entry belongs to the current frame.
            column_memory[clear_x] <= {frame_tag, 8'd0};
        end else if (line_read_valid) begin
            if (column_memory[line_read_x][8] == frame_tag)
                column_memory[line_read_x] <= {frame_tag,
                    count_enable ? column_memory[line_read_x][7:0] + 8'd1 :
                                   column_memory[line_read_x][7:0]};
            else
                column_memory[line_read_x] <= {frame_tag,
                    count_enable ? 8'd1 : 8'd0};
        end else if (!drain_issue) begin
            column_read_word <= column_memory[I_read_x];
        end

        if (!line_draining && !clear_active)
            O_column_count <= (column_read_word[8] == frame_tag) ?
                              column_read_word[7:0] : 8'd0;

        if (drain_issue) begin
            line_read_bit <= line_memory[drain_x];
            line_read_x <= drain_x;
            line_read_y <= drain_y;
        end
        end
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            frame_tag <= 1'b0;
            row_sum <= 9'd0;
            row_accept <= 1'b0;
            clear_active <= 1'b0;
            clear_x <= 9'd0;
            drain_issue <= 1'b0;
            drain_x <= 9'd0;
            drain_y <= 8'd0;
            line_read_valid <= 1'b0;
            O_frame_ready <= 1'b0;
            O_overrun <= 1'b0;
            O_mask_valid <= 1'b0;
            O_mask_pixel <= 1'b0;
            O_mask_x <= 9'd0;
            O_mask_y <= 8'd0;
        end else if (I_frame_start) begin
            frame_tag <= ~frame_tag;
            row_sum <= 9'd0;
            drain_issue <= 1'b0;
            line_read_valid <= 1'b0;
            clear_active <= 1'b1;
            clear_x <= 9'd0;
            O_frame_ready <= 1'b0;
            O_overrun <= 1'b0;
            O_mask_valid <= 1'b0;
        end else begin
            O_mask_valid <= 1'b0;

            if (clear_active) begin
                if (clear_x == 9'd319)
                    clear_active <= 1'b0;
                else
                    clear_x <= clear_x + 9'd1;
            end

            // Consume the registered line-memory response. Coordinates stay
            // paired with their mask bit, so foreground_mask_store receives
            // exactly the same 320 pixels as in v15.
            if (line_read_valid) begin
                O_mask_valid <= 1'b1;
                O_mask_pixel <= row_accept && line_read_bit;
                O_mask_x <= line_read_x;
                O_mask_y <= line_read_y;
                if (line_read_x == 9'd319) begin
                    line_read_valid <= 1'b0;
                    if (line_read_y == 8'd179)
                        O_frame_ready <= 1'b1;
                end
            end

            // Issue the next synchronous read. The final response remains
            // valid for one further clock and is consumed above.
            if (drain_issue) begin
                line_read_valid <= 1'b1;
                if (drain_x == 9'd319)
                    drain_issue <= 1'b0;
                else
                    drain_x <= drain_x + 9'd1;
            end

            if (I_valid && I_y >= 8'd8 && I_y <= 8'd179 && I_x < 9'd320) begin
                if (line_draining) begin
                    O_overrun <= 1'b1;
                end else begin
                    line_memory[I_x] <= I_foreground;
                    if (I_x == 9'd0)
                        row_sum <= {8'd0, I_foreground};
                    else
                        row_sum <= row_sum + {8'd0, I_foreground};
                    if (I_x == 9'd319) begin
                        row_accept <= (row_sum + {8'd0, I_foreground}) <= 9'd208;
                        drain_y <= I_y;
                        drain_x <= 9'd0;
                        drain_issue <= 1'b1;
                    end
                end
            end
        end
    end
endmodule

// Debounced KEY4 night-mode selector. A stable press toggles the sensor
// preset and emits a one-cycle request for the next I2C exposure update.
module night_mode_toggle #(
    parameter [19:0] DEBOUNCE_CYCLES = 20'd500000
) (
    input  wire I_clk,
    input  wire I_rst_n,
    input  wire I_button_n,
    output reg  O_night_mode,
    output reg  O_mode_change
);
    reg [1:0]  S_button_sync;
    reg        S_button_stable;
    reg [19:0] S_debounce_count;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            S_button_sync    <= 2'b11;
            S_button_stable  <= 1'b1;
            S_debounce_count <= 20'd0;
            O_night_mode     <= 1'b0;
            O_mode_change    <= 1'b0;
        end else begin
            S_button_sync <= {S_button_sync[0], I_button_n};
            O_mode_change <= 1'b0;

            if (S_button_sync[1] == S_button_stable) begin
                S_debounce_count <= 20'd0;
            end else if (S_debounce_count == DEBOUNCE_CYCLES - 20'd1) begin
                S_debounce_count <= 20'd0;
                if (S_button_stable && !S_button_sync[1]) begin
                    O_night_mode  <= ~O_night_mode;
                    O_mode_change <= 1'b1;
                end
                S_button_stable <= S_button_sync[1];
            end else begin
                S_debounce_count <= S_debounce_count + 20'd1;
            end
        end
    end
endmodule

// Compact extension for the peer 16x16 Chinese font.  Indices 0..13
// delegate unchanged to cn_char_lib; 14..27 cover this project's new titles.
module cn_mode_ext_font(
    input wire [4:0] I_char,
    input wire [3:0] I_row,
    output reg [15:0] O_row_bits
);
    wire [15:0] base_bits;
    cn_char_lib u_base(.I_char(I_char[3:0]), .I_row(I_row), .O_row_bits(base_bits));
    always @(*) begin
        if(I_char <= 5'd13) O_row_bits = base_bits;
        else begin
            case(I_char)
            5'd14: case(I_row) // 锐
                0:O_row_bits=16'h2000;1:O_row_bits=16'h27FC;2:O_row_bits=16'h2444;3:O_row_bits=16'h27FC;
                4:O_row_bits=16'h2444;5:O_row_bits=16'h27FC;6:O_row_bits=16'h2000;7:O_row_bits=16'h1FF8;
                8:O_row_bits=16'h1040;9:O_row_bits=16'h3FFC;10:O_row_bits=16'h2444;11:O_row_bits=16'h3FFC;
                12:O_row_bits=16'h2084;13:O_row_bits=16'h3FF8;14:O_row_bits=16'h0000;default:O_row_bits=0; endcase
            5'd15: case(I_row) // 伽
                0:O_row_bits=16'h1000;1:O_row_bits=16'h1080;2:O_row_bits=16'h1080;3:O_row_bits=16'h17FC;
                4:O_row_bits=16'h1204;5:O_row_bits=16'h1204;6:O_row_bits=16'h1004;7:O_row_bits=16'h23F8;
                8:O_row_bits=16'h2208;9:O_row_bits=16'h23F8;10:O_row_bits=16'h2208;11:O_row_bits=16'h23F8;
                12:O_row_bits=16'h2000;13:O_row_bits=16'h3FFE;14:O_row_bits=16'h0000;default:O_row_bits=0; endcase
            5'd16: case(I_row) // 马
                0:O_row_bits=16'h7FFC;1:O_row_bits=16'h4004;2:O_row_bits=16'h4004;3:O_row_bits=16'h7FFC;
                4:O_row_bits=16'h0004;5:O_row_bits=16'h3FF8;6:O_row_bits=16'h2008;7:O_row_bits=16'h2008;
                8:O_row_bits=16'h3FF8;9:O_row_bits=16'h0008;10:O_row_bits=16'h0008;11:O_row_bits=16'h7FF0;
                12:O_row_bits=16'h4000;13:O_row_bits=16'h3FFC;14:O_row_bits=16'h0000;default:O_row_bits=0; endcase
            5'd17: case(I_row) // 校
                0:O_row_bits=16'h1000;1:O_row_bits=16'h13FC;2:O_row_bits=16'h1200;3:O_row_bits=16'h7FFE;
                4:O_row_bits=16'h1248;5:O_row_bits=16'h1248;6:O_row_bits=16'h1FFC;7:O_row_bits=16'h1080;
                8:O_row_bits=16'h2490;9:O_row_bits=16'h4488;10:O_row_bits=16'h8484;11:O_row_bits=16'h0480;
                12:O_row_bits=16'h0480;13:O_row_bits=16'h0FF0;14:O_row_bits=16'h0000;default:O_row_bits=0; endcase
            5'd18: case(I_row) // 正
                0:O_row_bits=16'h1FF8;1:O_row_bits=16'h0080;2:O_row_bits=16'h0080;3:O_row_bits=16'h0080;
                4:O_row_bits=16'h3FFE;5:O_row_bits=16'h0080;6:O_row_bits=16'h0080;7:O_row_bits=16'h0080;
                8:O_row_bits=16'h0080;9:O_row_bits=16'h0080;10:O_row_bits=16'h0080;11:O_row_bits=16'h0080;
                12:O_row_bits=16'h0080;13:O_row_bits=16'h7FFC;14:O_row_bits=16'h0000;default:O_row_bits=0; endcase
            5'd19: case(I_row) // 检
                0:O_row_bits=16'h1000;1:O_row_bits=16'h13FC;2:O_row_bits=16'h1200;3:O_row_bits=16'h7FFE;
                4:O_row_bits=16'h1210;5:O_row_bits=16'h1FF8;6:O_row_bits=16'h2404;7:O_row_bits=16'h47FE;
                8:O_row_bits=16'h8400;9:O_row_bits=16'h1FF8;10:O_row_bits=16'h1008;11:O_row_bits=16'h1008;
                12:O_row_bits=16'h1008;13:O_row_bits=16'h1FF8;14:O_row_bits=16'h0000;default:O_row_bits=0; endcase
            5'd20: case(I_row) // 测
                0:O_row_bits=16'h2040;1:O_row_bits=16'h1020;2:O_row_bits=16'h0020;3:O_row_bits=16'h23FC;
                4:O_row_bits=16'h2024;5:O_row_bits=16'h2024;6:O_row_bits=16'h2FF4;7:O_row_bits=16'h2000;
                8:O_row_bits=16'h27F8;9:O_row_bits=16'h2448;10:O_row_bits=16'h2448;11:O_row_bits=16'h2448;
                12:O_row_bits=16'h47F8;13:O_row_bits=16'h0000;14:O_row_bits=16'h0000;default:O_row_bits=0; endcase
            5'd21: case(I_row) // 漫
                0:O_row_bits=16'h2040;1:O_row_bits=16'h1020;2:O_row_bits=16'h0020;3:O_row_bits=16'h3FFC;
                4:O_row_bits=16'h2024;5:O_row_bits=16'h3FFC;6:O_row_bits=16'h2024;7:O_row_bits=16'h3FFC;
                8:O_row_bits=16'h2040;9:O_row_bits=16'h27F8;10:O_row_bits=16'h2448;11:O_row_bits=16'h27F8;
                12:O_row_bits=16'h2408;13:O_row_bits=16'h47F0;14:O_row_bits=16'h0000;default:O_row_bits=0; endcase
            5'd22: case(I_row) // 画
                0:O_row_bits=16'h7FFC;1:O_row_bits=16'h4004;2:O_row_bits=16'h4004;3:O_row_bits=16'h7FFC;
                4:O_row_bits=16'h0000;5:O_row_bits=16'h3FF8;6:O_row_bits=16'h2008;7:O_row_bits=16'h2FE8;
                8:O_row_bits=16'h2008;9:O_row_bits=16'h3FF8;10:O_row_bits=16'h0000;11:O_row_bits=16'h7FFE;
                12:O_row_bits=16'h0100;13:O_row_bits=16'h00F0;14:O_row_bits=16'h0000;default:O_row_bits=0; endcase
            5'd23: case(I_row) // 风
                0:O_row_bits=16'h3FF8;1:O_row_bits=16'h2008;2:O_row_bits=16'h2008;3:O_row_bits=16'h27E8;
                4:O_row_bits=16'h2428;5:O_row_bits=16'h2428;6:O_row_bits=16'h27E8;7:O_row_bits=16'h2048;
                8:O_row_bits=16'h2088;9:O_row_bits=16'h2110;10:O_row_bits=16'h2220;11:O_row_bits=16'h2440;
                12:O_row_bits=16'h2880;13:O_row_bits=16'h3000;14:O_row_bits=16'h0000;default:O_row_bits=0; endcase
            5'd24: case(I_row) // 浮
                0:O_row_bits=16'h2040;1:O_row_bits=16'h1020;2:O_row_bits=16'h0020;3:O_row_bits=16'h7FFC;
                4:O_row_bits=16'h0080;5:O_row_bits=16'h3FFC;6:O_row_bits=16'h2024;7:O_row_bits=16'h7FFC;
                8:O_row_bits=16'h2100;9:O_row_bits=16'h3FF8;10:O_row_bits=16'h2108;11:O_row_bits=16'h2108;
                12:O_row_bits=16'h2108;13:O_row_bits=16'h3FF8;14:O_row_bits=16'h0000;default:O_row_bits=0; endcase
            5'd25: case(I_row) // 雕
                0:O_row_bits=16'h7FFC;1:O_row_bits=16'h4444;2:O_row_bits=16'h7FFC;3:O_row_bits=16'h0400;
                4:O_row_bits=16'h3FF8;5:O_row_bits=16'h2448;6:O_row_bits=16'h3FF8;7:O_row_bits=16'h0400;
                8:O_row_bits=16'h1FF0;9:O_row_bits=16'h1040;10:O_row_bits=16'h1FF0;11:O_row_bits=16'h1040;
                12:O_row_bits=16'h1040;13:O_row_bits=16'h1FF0;14:O_row_bits=16'h0000;default:O_row_bits=0; endcase
            5'd26: case(I_row) // 预
                0:O_row_bits=16'h7FFC;1:O_row_bits=16'h4444;2:O_row_bits=16'h7FFC;3:O_row_bits=16'h0400;
                4:O_row_bits=16'h3FF8;5:O_row_bits=16'h2008;6:O_row_bits=16'h3FF8;7:O_row_bits=16'h0080;
                8:O_row_bits=16'h1FF0;9:O_row_bits=16'h1010;10:O_row_bits=16'h1FF0;11:O_row_bits=16'h1010;
                12:O_row_bits=16'h1010;13:O_row_bits=16'h1FF0;14:O_row_bits=16'h0000;default:O_row_bits=0; endcase
            5'd27: case(I_row) // 览
                0:O_row_bits=16'h3FF8;1:O_row_bits=16'h2008;2:O_row_bits=16'h3FF8;3:O_row_bits=16'h0080;
                4:O_row_bits=16'h7FFC;5:O_row_bits=16'h4404;6:O_row_bits=16'h7FFC;7:O_row_bits=16'h0400;
                8:O_row_bits=16'h1FF0;9:O_row_bits=16'h1010;10:O_row_bits=16'h1FF0;11:O_row_bits=16'h1010;
                12:O_row_bits=16'h1010;13:O_row_bits=16'h1FF0;14:O_row_bits=16'h0000;default:O_row_bits=0; endcase
            5'd28: case(I_row) // 模
                0:O_row_bits=16'h1000;1:O_row_bits=16'h13FC;2:O_row_bits=16'h1200;3:O_row_bits=16'h7FFE;
                4:O_row_bits=16'h1210;5:O_row_bits=16'h1FF8;6:O_row_bits=16'h2488;7:O_row_bits=16'h4488;
                8:O_row_bits=16'h0408;9:O_row_bits=16'h1FF8;10:O_row_bits=16'h1008;11:O_row_bits=16'h1008;
                12:O_row_bits=16'h1008;13:O_row_bits=16'h1FF8;14:O_row_bits=16'h0000;default:O_row_bits=0; endcase
            5'd29: case(I_row) // 式
                0:O_row_bits=16'h0040;1:O_row_bits=16'h7FFE;2:O_row_bits=16'h1040;3:O_row_bits=16'h1FF8;
                4:O_row_bits=16'h1040;5:O_row_bits=16'h3FFC;6:O_row_bits=16'h0040;7:O_row_bits=16'h1FF8;
                8:O_row_bits=16'h1040;9:O_row_bits=16'h2040;10:O_row_bits=16'h4040;11:O_row_bits=16'h0040;
                12:O_row_bits=16'h0040;13:O_row_bits=16'h0000;14:O_row_bits=16'h0000;default:O_row_bits=0; endcase
            default: O_row_bits=16'h0000;
            endcase
        end
    end
endmodule

module shape_classifier (
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire        I_frame_commit,

    input  wire        I_profile_row_commit,
    input  wire [9:0]  I_profile_y,
    input  wire [10:0] I_red_run_len,
    input  wire [10:0] I_green_run_len,
    input  wire [10:0] I_blue_run_len,
    input  wire [10:0] I_yellow_run_len,

    input  wire        I_red_valid,
    input  wire [10:0] I_red_xmin,
    input  wire [10:0] I_red_xmax,
    input  wire [9:0]  I_red_ymin,
    input  wire [9:0]  I_red_ymax,
    input  wire [19:0] I_red_area,
    input  wire        I_green_valid,
    input  wire [10:0] I_green_xmin,
    input  wire [10:0] I_green_xmax,
    input  wire [9:0]  I_green_ymin,
    input  wire [9:0]  I_green_ymax,
    input  wire [19:0] I_green_area,
    input  wire        I_blue_valid,
    input  wire [10:0] I_blue_xmin,
    input  wire [10:0] I_blue_xmax,
    input  wire [9:0]  I_blue_ymin,
    input  wire [9:0]  I_blue_ymax,
    input  wire [19:0] I_blue_area,
    input  wire        I_yellow_valid,
    input  wire [10:0] I_yellow_xmin,
    input  wire [10:0] I_yellow_xmax,
    input  wire [9:0]  I_yellow_ymin,
    input  wire [9:0]  I_yellow_ymax,
    input  wire [19:0] I_yellow_area,

    output reg         O_red_valid,
    output reg  [10:0] O_red_xmin,
    output reg  [10:0] O_red_xmax,
    output reg  [9:0]  O_red_ymin,
    output reg  [9:0]  O_red_ymax,
    output reg  [10:0] O_red_width,
    output reg  [9:0]  O_red_height,
    output reg  [19:0] O_red_area,
    output reg  [19:0] O_red_bbox_area,
    output reg  [2:0]  O_red_shape,
    output reg  [2:0]  O_red_raw_shape,
    output reg  [11:0] O_red_p1, O_red_p2, O_red_p3, O_red_p4, O_red_p5,
    output reg         O_green_valid,
    output reg  [10:0] O_green_xmin,
    output reg  [10:0] O_green_xmax,
    output reg  [9:0]  O_green_ymin,
    output reg  [9:0]  O_green_ymax,
    output reg  [10:0] O_green_width,
    output reg  [9:0]  O_green_height,
    output reg  [19:0] O_green_area,
    output reg  [19:0] O_green_bbox_area,
    output reg  [2:0]  O_green_shape,
    output reg  [2:0]  O_green_raw_shape,
    output reg  [11:0] O_green_p1, O_green_p2, O_green_p3, O_green_p4, O_green_p5,
    output reg         O_blue_valid,
    output reg  [10:0] O_blue_xmin,
    output reg  [10:0] O_blue_xmax,
    output reg  [9:0]  O_blue_ymin,
    output reg  [9:0]  O_blue_ymax,
    output reg  [10:0] O_blue_width,
    output reg  [9:0]  O_blue_height,
    output reg  [19:0] O_blue_area,
    output reg  [19:0] O_blue_bbox_area,
    output reg  [2:0]  O_blue_shape,
    output reg  [2:0]  O_blue_raw_shape,
    output reg  [11:0] O_blue_p1, O_blue_p2, O_blue_p3, O_blue_p4, O_blue_p5,
    output reg         O_yellow_valid,
    output reg  [10:0] O_yellow_xmin,
    output reg  [10:0] O_yellow_xmax,
    output reg  [9:0]  O_yellow_ymin,
    output reg  [9:0]  O_yellow_ymax,
    output reg  [10:0] O_yellow_width,
    output reg  [9:0]  O_yellow_height,
    output reg  [19:0] O_yellow_area,
    output reg  [19:0] O_yellow_bbox_area,
    output reg  [2:0]  O_yellow_shape,
    output reg  [2:0]  O_yellow_raw_shape,
    output reg  [11:0] O_yellow_p1, O_yellow_p2, O_yellow_p3, O_yellow_p4, O_yellow_p5,
    output reg         O_shape_result_toggle
);

    localparam [2:0] SHAPE_UNKNOWN   = 3'd0;
    localparam [2:0] SHAPE_CIRCLE    = 3'd1;
    localparam [2:0] SHAPE_RESERVED  = 3'd2;
    localparam [2:0] SHAPE_TRIANGLE  = 3'd3;
    localparam [2:0] SHAPE_RECTANGLE = 3'd4;

    localparam integer MIN_SHAPE_WIDTH  = 12;
    localparam integer MIN_SHAPE_HEIGHT = 12;
    localparam [19:0] MIN_TARGET_AREA = 20'd512;

    localparam [4:0] ST_IDLE          = 5'd0;
    localparam [4:0] ST_LOAD          = 5'd1;
    localparam [4:0] ST_MUL           = 5'd2;
    localparam [4:0] ST_PROFILE_REQ   = 5'd3;
    localparam [4:0] ST_PROFILE_WAIT  = 5'd4;
    localparam [4:0] ST_PROFILE_ADD   = 5'd5;
    localparam [4:0] ST_LOAD_WORK     = 5'd6;
    localparam [4:0] ST_MAX_A         = 5'd7;
    localparam [4:0] ST_MAX_B         = 5'd8;
    localparam [4:0] ST_FLAGS_A       = 5'd9;
    localparam [4:0] ST_FLAGS_B       = 5'd10;
    localparam [4:0] ST_TREND_A       = 5'd11;
    localparam [4:0] ST_TREND_B       = 5'd12;
    localparam [4:0] ST_CLASSIFY_RAW  = 5'd13;
    localparam [4:0] ST_HISTORY       = 5'd14;
    localparam [4:0] ST_VOTE          = 5'd15;
    localparam [4:0] ST_STORE         = 5'd16;
    localparam [4:0] ST_DONE          = 5'd17;

    reg [4:0] R_state;
    reg [1:0] R_color_index;

    /* Frame-locked BBox and area snapshots; the pixel path never reads these. */
    reg        R_red_valid;
    reg [10:0] R_red_xmin, R_red_xmax;
    reg [9:0]  R_red_ymin, R_red_ymax;
    reg [19:0] R_red_area;
    reg        R_green_valid;
    reg [10:0] R_green_xmin, R_green_xmax;
    reg [9:0]  R_green_ymin, R_green_ymax;
    reg [19:0] R_green_area;
    reg        R_blue_valid;
    reg [10:0] R_blue_xmin, R_blue_xmax;
    reg [9:0]  R_blue_ymin, R_blue_ymax;
    reg [19:0] R_blue_area;
    reg        R_yellow_valid;
    reg [10:0] R_yellow_xmin, R_yellow_xmax;
    reg [9:0]  R_yellow_ymin, R_yellow_ymax;
    reg [19:0] R_yellow_area;

    reg        S_selected_valid;
    reg [10:0] S_selected_xmin, S_selected_xmax;
    reg [9:0]  S_selected_ymin, S_selected_ymax;
    reg [19:0] S_selected_area;
    wire [10:0] S_selected_width;
    wire [9:0]  S_selected_height;

    reg        R_active_valid;
    reg [10:0] R_active_width;
    reg [9:0]  R_active_height;
    reg [19:0] R_active_area;
    reg [19:0] R_mul_product;
    reg [19:0] R_mul_multiplicand;
    reg [10:0] R_mul_multiplier;
    reg [3:0]  R_mul_count;
    reg [19:0] R_bbox_area;
    reg [2:0]  R_shape_eval;
    reg [2:0]  R_next_red_shape;
    reg [2:0]  R_next_green_shape;
    reg [2:0]  R_next_blue_shape;
    reg [2:0]  R_next_yellow_shape;
    reg        R_next_red_valid;
    reg [10:0] R_next_red_xmin, R_next_red_xmax;
    reg [9:0]  R_next_red_ymin, R_next_red_ymax;
    reg [10:0] R_next_red_width;
    reg [9:0]  R_next_red_height;
    reg [19:0] R_next_red_area;
    reg [19:0] R_next_red_bbox_area;
    reg        R_next_green_valid;
    reg [10:0] R_next_green_xmin, R_next_green_xmax;
    reg [9:0]  R_next_green_ymin, R_next_green_ymax;
    reg [10:0] R_next_green_width;
    reg [9:0]  R_next_green_height;
    reg [19:0] R_next_green_area;
    reg [19:0] R_next_green_bbox_area;
    reg        R_next_blue_valid;
    reg [10:0] R_next_blue_xmin, R_next_blue_xmax;
    reg [9:0]  R_next_blue_ymin, R_next_blue_ymax;
    reg [10:0] R_next_blue_width;
    reg [9:0]  R_next_blue_height;
    reg [19:0] R_next_blue_area;
    reg [19:0] R_next_blue_bbox_area;
    reg        R_next_yellow_valid;
    reg [10:0] R_next_yellow_xmin, R_next_yellow_xmax;
    reg [9:0]  R_next_yellow_ymin, R_next_yellow_ymax;
    reg [10:0] R_next_yellow_width;
    reg [9:0]  R_next_yellow_height;
    reg [19:0] R_next_yellow_area;
    reg [19:0] R_next_yellow_bbox_area;

    /* 360 x 44-bit, even-row profile RAM.  The write port observes only the
       registered accepted-run tap; the read port is used by this frame FSM. */
    (* ram_style = "block" *) reg [43:0] R_profile_ram [0:359];
    reg [8:0]  R_profile_read_addr;
    reg [43:0] R_profile_read_data;
    reg [2:0]  R_profile_point;
    reg [1:0]  R_profile_neighbor;
    reg [12:0] R_profile_sum;
    reg [8:0]  R_profile_base1, R_profile_base2, R_profile_base3, R_profile_base4, R_profile_base5;
    reg [11:0] R_profile_p1, R_profile_p2, R_profile_p3, R_profile_p4, R_profile_p5;
    /* Timing isolation: all classification stages consume only these shared
       work registers, never the profile-sum registers directly. */
    reg        R_work_valid;
    reg [10:0] R_work_width;
    reg [9:0]  R_work_height;
    reg [19:0] R_work_area, R_work_bbox_area;
    reg [1:0]  R_work_color;
    reg [11:0] R_work_p1, R_work_p2, R_work_p3, R_work_p4, R_work_p5;
    reg [11:0] R_max12, R_max34, R_min12, R_min34;
    reg [11:0] R_pmax, R_pmin, R_d15, R_d24, R_margin;
    reg R_sym15, R_sym24, R_center_high;
    reg R_p1_ge50, R_p5_ge50;
    reg R_p1_ge75, R_p2_ge75, R_p3_ge75, R_p4_ge75, R_p5_ge75;
    reg R_fill_ge60, R_fill_ge80;
    reg R_profile_symmetric, R_circle_like, R_diamond_rect_like;
    reg R_up01, R_up12, R_up23, R_up34, R_down01, R_down12, R_down23, R_down34;
    reg [2:0] R_wide_count, R_up_score, R_down_score;
    reg R_triangle_monotonic;
    reg [2:0]  R_next_red_raw, R_next_green_raw, R_next_blue_raw, R_next_yellow_raw;
    reg [11:0] R_next_red_p1, R_next_red_p2, R_next_red_p3, R_next_red_p4, R_next_red_p5;
    reg [11:0] R_next_green_p1, R_next_green_p2, R_next_green_p3, R_next_green_p4, R_next_green_p5;
    reg [11:0] R_next_blue_p1, R_next_blue_p2, R_next_blue_p3, R_next_blue_p4, R_next_blue_p5;
    reg [11:0] R_next_yellow_p1, R_next_yellow_p2, R_next_yellow_p3, R_next_yellow_p4, R_next_yellow_p5;

    reg [2:0] R_red_hist0, R_red_hist1, R_red_hist2, R_red_stable;
    reg [2:0] R_green_hist0, R_green_hist1, R_green_hist2, R_green_stable;
    reg [2:0] R_blue_hist0, R_blue_hist1, R_blue_hist2, R_blue_stable;
    reg [2:0] R_yellow_hist0, R_yellow_hist1, R_yellow_hist2, R_yellow_stable;
    reg [1:0] R_red_invalid_count, R_green_invalid_count, R_blue_invalid_count, R_yellow_invalid_count;
    reg [2:0] S_history0, S_history1, S_history2, S_stable_shape;
    reg [1:0] S_invalid_count;
    reg [8:0] S_profile_base;
    reg [11:0] S_profile_run;
    reg [11:0] S_pmax;
    reg [2:0] S_wide_count, S_up_score, S_down_score;
    reg [2:0] S_raw_shape;

    wire [19:0] S_mul_product_after;
    wire [10:0] S_dim_diff;
    wire [10:0] S_max_dim;
    wire [13:0] S_dim_diff_x8;
    wire        S_near_square;
    wire [23:0] S_area_ext;
    wire [23:0] S_bbox_area_ext;
    wire [23:0] S_area_x8;
    wire [23:0] S_bbox_area_x7;
    wire [23:0] S_area_x5;
    wire [23:0] S_bbox_area_x3;
    wire [12:0] S_pmax_x3;
    wire [14:0] S_pmax_x7;
    wire [14:0] S_p3_x8;
    wire [11:0] S_d15;
    wire [11:0] S_d24;
    wire        S_profile_symmetric;
    wire        S_center_high;
    wire        S_wide_p1, S_wide_p2, S_wide_p3, S_wide_p4, S_wide_p5;
    wire        S_circle_like, S_diamond_rect_like, S_triangle_monotonic;
    wire        S_fill_ge_60, S_fill_ge_80;
    wire [2:0]  S_voted_shape;
    wire [2:0]  S_next_stable_shape;
    wire [1:0]  S_next_invalid_count;

    function [8:0] profile_addr;
        input [9:0] value;
        begin
            profile_addr = (value >= 10'd719) ? 9'd359 : value[9:1];
        end
    endfunction

    function [8:0] profile_neighbor_addr;
        input [8:0] base;
        input [1:0] neighbor;
        begin
            case (neighbor)
                2'd0: profile_neighbor_addr = (base == 9'd0) ? 9'd0 : base - 1'b1;
                2'd1: profile_neighbor_addr = base;
                default: profile_neighbor_addr = (base >= 9'd359) ? 9'd359 : base + 1'b1;
            endcase
        end
    endfunction

    function [2:0] majority_shape;
        input [2:0] current;
        input [2:0] hist0;
        input [2:0] hist1;
        input [2:0] old_stable;
        begin
            if ((current != SHAPE_UNKNOWN) && ((current == hist0) || (current == hist1)))
                majority_shape = current;
            else if ((hist0 != SHAPE_UNKNOWN) && (hist0 == hist1))
                majority_shape = hist0;
            else
                majority_shape = old_stable;
        end
    endfunction

    always @(posedge I_clk) begin
        if (I_profile_row_commit && !I_profile_y[0])
            R_profile_ram[I_profile_y[9:1]] <= {I_red_run_len, I_green_run_len,
                                                  I_blue_run_len, I_yellow_run_len};
    end

    always @(posedge I_clk) begin
        R_profile_read_data <= R_profile_ram[R_profile_read_addr];
    end

    always @* begin
        S_selected_valid = 1'b0;
        S_selected_xmin  = 11'd0;
        S_selected_xmax  = 11'd0;
        S_selected_ymin  = 10'd0;
        S_selected_ymax  = 10'd0;
        S_selected_area  = 20'd0;
        case (R_color_index)
            2'd0: begin
                S_selected_valid = R_red_valid;
                S_selected_xmin  = R_red_xmin;
                S_selected_xmax  = R_red_xmax;
                S_selected_ymin  = R_red_ymin;
                S_selected_ymax  = R_red_ymax;
                S_selected_area  = R_red_area;
            end
            2'd1: begin
                S_selected_valid = R_green_valid;
                S_selected_xmin  = R_green_xmin;
                S_selected_xmax  = R_green_xmax;
                S_selected_ymin  = R_green_ymin;
                S_selected_ymax  = R_green_ymax;
                S_selected_area  = R_green_area;
            end
            2'd2: begin
                S_selected_valid = R_blue_valid;
                S_selected_xmin  = R_blue_xmin;
                S_selected_xmax  = R_blue_xmax;
                S_selected_ymin  = R_blue_ymin;
                S_selected_ymax  = R_blue_ymax;
                S_selected_area  = R_blue_area;
            end
            2'd3: begin
                S_selected_valid = R_yellow_valid;
                S_selected_xmin  = R_yellow_xmin;
                S_selected_xmax  = R_yellow_xmax;
                S_selected_ymin  = R_yellow_ymin;
                S_selected_ymax  = R_yellow_ymax;
                S_selected_area  = R_yellow_area;
            end
        endcase
    end

    assign S_selected_width = (S_selected_xmax >= S_selected_xmin) ?
                              (S_selected_xmax - S_selected_xmin + 11'd1) : 11'd0;
    assign S_selected_height = (S_selected_ymax >= S_selected_ymin) ?
                               (S_selected_ymax - S_selected_ymin + 10'd1) : 10'd0;
    assign S_mul_product_after = R_mul_multiplier[0] ?
                                 (R_mul_product + R_mul_multiplicand) : R_mul_product;
    assign S_dim_diff = (R_active_width >= {1'b0, R_active_height}) ?
                        (R_active_width - {1'b0, R_active_height}) :
                        ({1'b0, R_active_height} - R_active_width);
    assign S_max_dim = (R_active_width >= {1'b0, R_active_height}) ?
                       R_active_width : {1'b0, R_active_height};
    assign S_dim_diff_x8 = {S_dim_diff, 3'b000};
    assign S_near_square = (S_dim_diff_x8 <= {3'd0, S_max_dim});
    /* Explicit 24-bit ratio operands prevent shift/add truncation. */
    assign S_area_ext      = {4'd0, R_active_area};
    assign S_bbox_area_ext = {4'd0, R_bbox_area};
    assign S_area_x8       = S_area_ext << 3;
    assign S_bbox_area_x7  = (S_bbox_area_ext << 2) + (S_bbox_area_ext << 1) + S_bbox_area_ext;
    assign S_area_x5       = (S_area_ext << 2) + S_area_ext;
    assign S_bbox_area_x3  = (S_bbox_area_ext << 1) + S_bbox_area_ext;
    assign S_fill_ge_60 = S_area_x5 >= S_bbox_area_x3;
    assign S_fill_ge_80 = S_area_x5 >= (S_bbox_area_ext << 2);
    assign S_d15 = (R_profile_p1 >= R_profile_p5) ? (R_profile_p1 - R_profile_p5) : (R_profile_p5 - R_profile_p1);
    assign S_d24 = (R_profile_p2 >= R_profile_p4) ? (R_profile_p2 - R_profile_p4) : (R_profile_p4 - R_profile_p2);
    assign S_pmax_x3 = ({1'b0, S_pmax} << 1) + {1'b0, S_pmax};
    assign S_pmax_x7 = ({3'b000, S_pmax} << 2) + ({3'b000, S_pmax} << 1) + {3'b000, S_pmax};
    assign S_p3_x8 = {R_profile_p3, 3'b000};
    assign S_profile_symmetric = ({S_d15, 2'b00} <= {2'b00, S_pmax}) &&
                                 ({S_d24, 2'b00} <= {2'b00, S_pmax});
    assign S_center_high = S_p3_x8 >= S_pmax_x7;
    assign S_wide_p1 = ({R_profile_p1,2'b00} >= S_pmax_x3);
    assign S_wide_p2 = ({R_profile_p2,2'b00} >= S_pmax_x3);
    assign S_wide_p3 = ({R_profile_p3,2'b00} >= S_pmax_x3);
    assign S_wide_p4 = ({R_profile_p4,2'b00} >= S_pmax_x3);
    assign S_wide_p5 = ({R_profile_p5,2'b00} >= S_pmax_x3);
    assign S_circle_like = S_profile_symmetric && S_center_high && S_wide_p2 && S_wide_p4 &&
                           ({R_profile_p1,1'b0} >= {1'b0,S_pmax}) && ({R_profile_p5,1'b0} >= {1'b0,S_pmax}) &&
                           !S_wide_p1 && !S_wide_p5;
    assign S_diamond_rect_like = S_profile_symmetric && S_center_high &&
                                 ({R_profile_p1,1'b0} < {1'b0,S_pmax}) && ({R_profile_p5,1'b0} < {1'b0,S_pmax}) &&
                                 ({R_profile_p2,2'b00} <= S_pmax_x3) && ({R_profile_p4,2'b00} <= S_pmax_x3);
    assign S_triangle_monotonic = (S_up_score >= 3'd3) || (S_down_score >= 3'd3);
    assign S_voted_shape = majority_shape(S_history0, S_history1, S_history2, S_stable_shape);
    assign S_next_invalid_count = R_active_valid ? 2'd0 :
                                  ((S_invalid_count >= 2'd3) ? 2'd3 : S_invalid_count + 1'b1);
    assign S_next_stable_shape = R_active_valid ? S_voted_shape :
                                  ((S_invalid_count >= 2'd2) ? SHAPE_UNKNOWN : S_stable_shape);

    always @* begin
        S_history0 = SHAPE_UNKNOWN; S_history1 = SHAPE_UNKNOWN; S_history2 = SHAPE_UNKNOWN;
        S_stable_shape = SHAPE_UNKNOWN; S_invalid_count = 2'd0;
        case (R_color_index)
            2'd0: begin S_history0=R_red_hist0; S_history1=R_red_hist1; S_history2=R_red_hist2; S_stable_shape=R_red_stable; S_invalid_count=R_red_invalid_count; end
            2'd1: begin S_history0=R_green_hist0; S_history1=R_green_hist1; S_history2=R_green_hist2; S_stable_shape=R_green_stable; S_invalid_count=R_green_invalid_count; end
            2'd2: begin S_history0=R_blue_hist0; S_history1=R_blue_hist1; S_history2=R_blue_hist2; S_stable_shape=R_blue_stable; S_invalid_count=R_blue_invalid_count; end
            default: begin S_history0=R_yellow_hist0; S_history1=R_yellow_hist1; S_history2=R_yellow_hist2; S_stable_shape=R_yellow_stable; S_invalid_count=R_yellow_invalid_count; end
        endcase
        case (R_profile_point)
            3'd1: S_profile_base=R_profile_base2;
            3'd2: S_profile_base=R_profile_base3;
            3'd3: S_profile_base=R_profile_base4;
            3'd4: S_profile_base=R_profile_base5;
            default: S_profile_base=R_profile_base1;
        endcase
        case (R_color_index)
            2'd0: S_profile_run={1'b0,R_profile_read_data[43:33]};
            2'd1: S_profile_run={1'b0,R_profile_read_data[32:22]};
            2'd2: S_profile_run={1'b0,R_profile_read_data[21:11]};
            default: S_profile_run={1'b0,R_profile_read_data[10:0]};
        endcase
    end

    always @* begin
        S_pmax=R_profile_p1;
        if (R_profile_p2>S_pmax) S_pmax=R_profile_p2;
        if (R_profile_p3>S_pmax) S_pmax=R_profile_p3;
        if (R_profile_p4>S_pmax) S_pmax=R_profile_p4;
        if (R_profile_p5>S_pmax) S_pmax=R_profile_p5;
        S_wide_count={2'd0,S_wide_p1}+{2'd0,S_wide_p2}+{2'd0,S_wide_p3}+{2'd0,S_wide_p4}+{2'd0,S_wide_p5};
        S_up_score=0;
        if ({1'b0,R_profile_p2}>{1'b0,R_profile_p1}+{1'b0,(S_pmax>>4)}) S_up_score=S_up_score+1'b1;
        if ({1'b0,R_profile_p3}>{1'b0,R_profile_p2}+{1'b0,(S_pmax>>4)}) S_up_score=S_up_score+1'b1;
        if ({1'b0,R_profile_p4}>{1'b0,R_profile_p3}+{1'b0,(S_pmax>>4)}) S_up_score=S_up_score+1'b1;
        if ({1'b0,R_profile_p5}>{1'b0,R_profile_p4}+{1'b0,(S_pmax>>4)}) S_up_score=S_up_score+1'b1;
        S_down_score=0;
        if ({1'b0,R_profile_p1}>{1'b0,R_profile_p2}+{1'b0,(S_pmax>>4)}) S_down_score=S_down_score+1'b1;
        if ({1'b0,R_profile_p2}>{1'b0,R_profile_p3}+{1'b0,(S_pmax>>4)}) S_down_score=S_down_score+1'b1;
        if ({1'b0,R_profile_p3}>{1'b0,R_profile_p4}+{1'b0,(S_pmax>>4)}) S_down_score=S_down_score+1'b1;
        if ({1'b0,R_profile_p4}>{1'b0,R_profile_p5}+{1'b0,(S_pmax>>4)}) S_down_score=S_down_score+1'b1;
        if (!R_active_valid || (R_active_width<MIN_SHAPE_WIDTH) || (R_active_height<MIN_SHAPE_HEIGHT) ||
            (R_active_area<MIN_TARGET_AREA) || (R_bbox_area==0) || (S_pmax<12)) S_raw_shape=SHAPE_UNKNOWN;
        else if (S_fill_ge_80 || (S_wide_count>=4) || S_diamond_rect_like) S_raw_shape=SHAPE_RECTANGLE;
        else if (S_circle_like) S_raw_shape=SHAPE_CIRCLE;
        else if (S_triangle_monotonic) S_raw_shape=SHAPE_TRIANGLE;
        else if (!S_fill_ge_60 && !S_profile_symmetric) S_raw_shape=SHAPE_TRIANGLE;
        else S_raw_shape=SHAPE_UNKNOWN;
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            R_state              <= ST_IDLE;
            R_color_index        <= 2'd0;
            R_red_valid          <= 1'b0;
            R_red_xmin           <= 11'd0;
            R_red_xmax           <= 11'd0;
            R_red_ymin           <= 10'd0;
            R_red_ymax           <= 10'd0;
            R_red_area           <= 20'd0;
            R_green_valid        <= 1'b0;
            R_green_xmin         <= 11'd0;
            R_green_xmax         <= 11'd0;
            R_green_ymin         <= 10'd0;
            R_green_ymax         <= 10'd0;
            R_green_area         <= 20'd0;
            R_blue_valid         <= 1'b0;
            R_blue_xmin          <= 11'd0;
            R_blue_xmax          <= 11'd0;
            R_blue_ymin          <= 10'd0;
            R_blue_ymax          <= 10'd0;
            R_blue_area          <= 20'd0;
            R_yellow_valid       <= 1'b0;
            R_yellow_xmin        <= 11'd0;
            R_yellow_xmax        <= 11'd0;
            R_yellow_ymin        <= 10'd0;
            R_yellow_ymax        <= 10'd0;
            R_yellow_area        <= 20'd0;
            R_active_valid       <= 1'b0;
            R_active_width       <= 11'd0;
            R_active_height      <= 10'd0;
            R_active_area        <= 20'd0;
            R_mul_product        <= 20'd0;
            R_mul_multiplicand   <= 20'd0;
            R_mul_multiplier     <= 11'd0;
            R_mul_count          <= 4'd0;
            R_bbox_area          <= 20'd0;
            R_shape_eval         <= SHAPE_UNKNOWN;
            R_profile_read_addr  <= 9'd0;
            R_profile_point      <= 3'd0;
            R_profile_neighbor   <= 2'd0;
            R_profile_sum        <= 13'd0;
            R_profile_base1<=0; R_profile_base2<=0; R_profile_base3<=0; R_profile_base4<=0; R_profile_base5<=0;
            R_profile_p1<=0; R_profile_p2<=0; R_profile_p3<=0; R_profile_p4<=0; R_profile_p5<=0;
            R_work_valid<=0; R_work_width<=0; R_work_height<=0; R_work_area<=0; R_work_bbox_area<=0; R_work_color<=0;
            R_work_p1<=0; R_work_p2<=0; R_work_p3<=0; R_work_p4<=0; R_work_p5<=0;
            R_max12<=0; R_max34<=0; R_min12<=0; R_min34<=0; R_pmax<=0; R_pmin<=0; R_d15<=0; R_d24<=0; R_margin<=0;
            R_sym15<=0; R_sym24<=0; R_center_high<=0; R_p1_ge50<=0; R_p5_ge50<=0;
            R_p1_ge75<=0; R_p2_ge75<=0; R_p3_ge75<=0; R_p4_ge75<=0; R_p5_ge75<=0; R_fill_ge60<=0; R_fill_ge80<=0;
            R_profile_symmetric<=0; R_circle_like<=0; R_diamond_rect_like<=0;
            R_up01<=0; R_up12<=0; R_up23<=0; R_up34<=0; R_down01<=0; R_down12<=0; R_down23<=0; R_down34<=0;
            R_wide_count<=0; R_up_score<=0; R_down_score<=0; R_triangle_monotonic<=0;
            R_red_hist0<=0; R_red_hist1<=0; R_red_hist2<=0; R_red_stable<=0; R_green_hist0<=0; R_green_hist1<=0; R_green_hist2<=0; R_green_stable<=0;
            R_blue_hist0<=0; R_blue_hist1<=0; R_blue_hist2<=0; R_blue_stable<=0; R_yellow_hist0<=0; R_yellow_hist1<=0; R_yellow_hist2<=0; R_yellow_stable<=0;
            R_red_invalid_count<=0; R_green_invalid_count<=0; R_blue_invalid_count<=0; R_yellow_invalid_count<=0;
            R_next_red_shape     <= SHAPE_UNKNOWN;
            R_next_green_shape   <= SHAPE_UNKNOWN;
            R_next_blue_shape    <= SHAPE_UNKNOWN;
            R_next_yellow_shape  <= SHAPE_UNKNOWN;
            R_next_red_raw<=0; R_next_green_raw<=0; R_next_blue_raw<=0; R_next_yellow_raw<=0;
            R_next_red_p1<=0; R_next_red_p2<=0; R_next_red_p3<=0; R_next_red_p4<=0; R_next_red_p5<=0;
            R_next_green_p1<=0; R_next_green_p2<=0; R_next_green_p3<=0; R_next_green_p4<=0; R_next_green_p5<=0;
            R_next_blue_p1<=0; R_next_blue_p2<=0; R_next_blue_p3<=0; R_next_blue_p4<=0; R_next_blue_p5<=0;
            R_next_yellow_p1<=0; R_next_yellow_p2<=0; R_next_yellow_p3<=0; R_next_yellow_p4<=0; R_next_yellow_p5<=0;
            R_next_red_valid     <= 1'b0;
            R_next_red_xmin      <= 11'd0;
            R_next_red_xmax      <= 11'd0;
            R_next_red_ymin      <= 10'd0;
            R_next_red_ymax      <= 10'd0;
            R_next_red_width     <= 11'd0;
            R_next_red_height    <= 10'd0;
            R_next_red_area      <= 20'd0;
            R_next_red_bbox_area <= 20'd0;
            R_next_green_valid     <= 1'b0;
            R_next_green_xmin      <= 11'd0;
            R_next_green_xmax      <= 11'd0;
            R_next_green_ymin      <= 10'd0;
            R_next_green_ymax      <= 10'd0;
            R_next_green_width     <= 11'd0;
            R_next_green_height    <= 10'd0;
            R_next_green_area      <= 20'd0;
            R_next_green_bbox_area <= 20'd0;
            R_next_blue_valid     <= 1'b0;
            R_next_blue_xmin      <= 11'd0;
            R_next_blue_xmax      <= 11'd0;
            R_next_blue_ymin      <= 10'd0;
            R_next_blue_ymax      <= 10'd0;
            R_next_blue_width     <= 11'd0;
            R_next_blue_height    <= 10'd0;
            R_next_blue_area      <= 20'd0;
            R_next_blue_bbox_area <= 20'd0;
            R_next_yellow_valid     <= 1'b0;
            R_next_yellow_xmin      <= 11'd0;
            R_next_yellow_xmax      <= 11'd0;
            R_next_yellow_ymin      <= 10'd0;
            R_next_yellow_ymax      <= 10'd0;
            R_next_yellow_width     <= 11'd0;
            R_next_yellow_height    <= 10'd0;
            R_next_yellow_area      <= 20'd0;
            R_next_yellow_bbox_area <= 20'd0;
            O_red_valid          <= 1'b0;
            O_red_xmin           <= 11'd0;
            O_red_xmax           <= 11'd0;
            O_red_ymin           <= 10'd0;
            O_red_ymax           <= 10'd0;
            O_red_width          <= 11'd0;
            O_red_height         <= 10'd0;
            O_red_area           <= 20'd0;
            O_red_bbox_area      <= 20'd0;
            O_red_shape          <= SHAPE_UNKNOWN;
            O_red_raw_shape      <= SHAPE_UNKNOWN;
            O_red_p1<=0; O_red_p2<=0; O_red_p3<=0; O_red_p4<=0; O_red_p5<=0;
            O_green_valid        <= 1'b0;
            O_green_xmin         <= 11'd0;
            O_green_xmax         <= 11'd0;
            O_green_ymin         <= 10'd0;
            O_green_ymax         <= 10'd0;
            O_green_width        <= 11'd0;
            O_green_height       <= 10'd0;
            O_green_area         <= 20'd0;
            O_green_bbox_area    <= 20'd0;
            O_green_shape        <= SHAPE_UNKNOWN;
            O_green_raw_shape    <= SHAPE_UNKNOWN;
            O_green_p1<=0; O_green_p2<=0; O_green_p3<=0; O_green_p4<=0; O_green_p5<=0;
            O_blue_valid         <= 1'b0;
            O_blue_xmin          <= 11'd0;
            O_blue_xmax          <= 11'd0;
            O_blue_ymin          <= 10'd0;
            O_blue_ymax          <= 10'd0;
            O_blue_width         <= 11'd0;
            O_blue_height        <= 10'd0;
            O_blue_area          <= 20'd0;
            O_blue_bbox_area     <= 20'd0;
            O_blue_shape         <= SHAPE_UNKNOWN;
            O_blue_raw_shape     <= SHAPE_UNKNOWN;
            O_blue_p1<=0; O_blue_p2<=0; O_blue_p3<=0; O_blue_p4<=0; O_blue_p5<=0;
            O_yellow_valid       <= 1'b0;
            O_yellow_xmin        <= 11'd0;
            O_yellow_xmax        <= 11'd0;
            O_yellow_ymin        <= 10'd0;
            O_yellow_ymax        <= 10'd0;
            O_yellow_width       <= 11'd0;
            O_yellow_height      <= 10'd0;
            O_yellow_area        <= 20'd0;
            O_yellow_bbox_area   <= 20'd0;
            O_yellow_shape       <= SHAPE_UNKNOWN;
            O_yellow_raw_shape   <= SHAPE_UNKNOWN;
            O_yellow_p1<=0; O_yellow_p2<=0; O_yellow_p3<=0; O_yellow_p4<=0; O_yellow_p5<=0;
            O_shape_result_toggle <= 1'b0;
        end else begin
            case (R_state)
                ST_IDLE: begin
                    if (I_frame_commit) begin
                        R_red_valid    <= I_red_valid;
                        R_red_xmin     <= I_red_xmin;
                        R_red_xmax     <= I_red_xmax;
                        R_red_ymin     <= I_red_ymin;
                        R_red_ymax     <= I_red_ymax;
                        R_red_area     <= I_red_area;
                        R_green_valid  <= I_green_valid;
                        R_green_xmin   <= I_green_xmin;
                        R_green_xmax   <= I_green_xmax;
                        R_green_ymin   <= I_green_ymin;
                        R_green_ymax   <= I_green_ymax;
                        R_green_area   <= I_green_area;
                        R_blue_valid   <= I_blue_valid;
                        R_blue_xmin    <= I_blue_xmin;
                        R_blue_xmax    <= I_blue_xmax;
                        R_blue_ymin    <= I_blue_ymin;
                        R_blue_ymax    <= I_blue_ymax;
                        R_blue_area    <= I_blue_area;
                        R_yellow_valid <= I_yellow_valid;
                        R_yellow_xmin  <= I_yellow_xmin;
                        R_yellow_xmax  <= I_yellow_xmax;
                        R_yellow_ymin  <= I_yellow_ymin;
                        R_yellow_ymax  <= I_yellow_ymax;
                        R_yellow_area  <= I_yellow_area;
                        R_color_index       <= 2'd0;
                        R_next_red_shape    <= SHAPE_UNKNOWN;
                        R_next_green_shape  <= SHAPE_UNKNOWN;
                        R_next_blue_shape   <= SHAPE_UNKNOWN;
                        R_next_yellow_shape <= SHAPE_UNKNOWN;
                        R_next_red_valid     <= 1'b0;
                        R_next_red_xmin      <= 11'd0;
                        R_next_red_xmax      <= 11'd0;
                        R_next_red_ymin      <= 10'd0;
                        R_next_red_ymax      <= 10'd0;
                        R_next_red_width     <= 11'd0;
                        R_next_red_height    <= 10'd0;
                        R_next_red_area      <= 20'd0;
                        R_next_red_bbox_area <= 20'd0;
                        R_next_green_valid     <= 1'b0;
                        R_next_green_xmin      <= 11'd0;
                        R_next_green_xmax      <= 11'd0;
                        R_next_green_ymin      <= 10'd0;
                        R_next_green_ymax      <= 10'd0;
                        R_next_green_width     <= 11'd0;
                        R_next_green_height    <= 10'd0;
                        R_next_green_area      <= 20'd0;
                        R_next_green_bbox_area <= 20'd0;
                        R_next_blue_valid     <= 1'b0;
                        R_next_blue_xmin      <= 11'd0;
                        R_next_blue_xmax      <= 11'd0;
                        R_next_blue_ymin      <= 10'd0;
                        R_next_blue_ymax      <= 10'd0;
                        R_next_blue_width     <= 11'd0;
                        R_next_blue_height    <= 10'd0;
                        R_next_blue_area      <= 20'd0;
                        R_next_blue_bbox_area <= 20'd0;
                        R_next_yellow_valid     <= 1'b0;
                        R_next_yellow_xmin      <= 11'd0;
                        R_next_yellow_xmax      <= 11'd0;
                        R_next_yellow_ymin      <= 10'd0;
                        R_next_yellow_ymax      <= 10'd0;
                        R_next_yellow_width     <= 11'd0;
                        R_next_yellow_height    <= 10'd0;
                        R_next_yellow_area      <= 20'd0;
                        R_next_yellow_bbox_area <= 20'd0;
                        R_state <= ST_LOAD;
                    end
                end

                ST_LOAD: begin
                    R_active_valid  <= S_selected_valid;
                    R_active_width  <= S_selected_width;
                    R_active_height <= S_selected_height;
                    R_active_area   <= S_selected_area;
                    R_profile_p1 <= 12'd0; R_profile_p2 <= 12'd0; R_profile_p3 <= 12'd0;
                    R_profile_p4 <= 12'd0; R_profile_p5 <= 12'd0;
                    if (S_selected_valid) begin
                        R_mul_product      <= 20'd0;
                        R_mul_multiplicand <= {10'd0, S_selected_height};
                        R_mul_multiplier   <= S_selected_width;
                        R_mul_count        <= 4'd0;
                        R_profile_base1 <= profile_addr(S_selected_ymin + (S_selected_height >> 3));
                        R_profile_base2 <= profile_addr(S_selected_ymin + (S_selected_height >> 2));
                        R_profile_base3 <= profile_addr(S_selected_ymin + (S_selected_height >> 1));
                        R_profile_base4 <= profile_addr(S_selected_ymin + (S_selected_height >> 1) + (S_selected_height >> 2));
                        R_profile_base5 <= profile_addr(S_selected_ymin + (S_selected_height >> 1) + (S_selected_height >> 2) + (S_selected_height >> 3));
                        R_state            <= ST_MUL;
                    end else begin
                        R_shape_eval <= SHAPE_UNKNOWN;
                        R_state      <= ST_HISTORY;
                    end
                end

                ST_MUL: begin
                    if (R_mul_count == 4'd10) begin
                        R_bbox_area <= S_mul_product_after;
                        R_profile_point <= 3'd0;
                        R_profile_neighbor <= 2'd0;
                        R_profile_sum <= 13'd0;
                        R_state     <= ST_PROFILE_REQ;
                    end else begin
                        R_mul_product      <= S_mul_product_after;
                        R_mul_multiplicand <= R_mul_multiplicand << 1;
                        R_mul_multiplier   <= R_mul_multiplier >> 1;
                        R_mul_count        <= R_mul_count + 1'b1;
                    end
                end

                ST_PROFILE_REQ: begin
                    R_profile_read_addr <= profile_neighbor_addr(S_profile_base, R_profile_neighbor);
                    R_state <= ST_PROFILE_WAIT;
                end

                ST_PROFILE_WAIT: R_state <= ST_PROFILE_ADD;

                ST_PROFILE_ADD: begin
                    if (R_profile_neighbor == 2'd2) begin
                        case (R_profile_point)
                            3'd0: R_profile_p1 <= R_profile_sum + S_profile_run;
                            3'd1: R_profile_p2 <= R_profile_sum + S_profile_run;
                            3'd2: R_profile_p3 <= R_profile_sum + S_profile_run;
                            3'd3: R_profile_p4 <= R_profile_sum + S_profile_run;
                            default: R_profile_p5 <= R_profile_sum + S_profile_run;
                        endcase
                        R_profile_sum <= 13'd0;
                        R_profile_neighbor <= 2'd0;
                        if (R_profile_point == 3'd4)
                            R_state <= ST_LOAD_WORK;
                        else begin
                            R_profile_point <= R_profile_point + 1'b1;
                            R_state <= ST_PROFILE_REQ;
                        end
                    end else begin
                        R_profile_sum <= R_profile_sum + S_profile_run;
                        R_profile_neighbor <= R_profile_neighbor + 1'b1;
                        R_state <= ST_PROFILE_REQ;
                    end
                end

                ST_LOAD_WORK: begin
                    R_work_valid<=R_active_valid; R_work_width<=R_active_width; R_work_height<=R_active_height;
                    R_work_area<=R_active_area; R_work_bbox_area<=R_bbox_area; R_work_color<=R_color_index;
                    R_work_p1<=R_profile_p1; R_work_p2<=R_profile_p2; R_work_p3<=R_profile_p3; R_work_p4<=R_profile_p4; R_work_p5<=R_profile_p5;
                    R_state<=ST_MAX_A;
                end

                ST_MAX_A: begin
                    R_max12 <= (R_work_p1>=R_work_p2) ? R_work_p1 : R_work_p2;
                    R_max34 <= (R_work_p3>=R_work_p4) ? R_work_p3 : R_work_p4;
                    R_min12 <= (R_work_p1<=R_work_p2) ? R_work_p1 : R_work_p2;
                    R_min34 <= (R_work_p3<=R_work_p4) ? R_work_p3 : R_work_p4;
                    R_state<=ST_MAX_B;
                end

                ST_MAX_B: begin
                    R_pmax <= (R_work_p5 > ((R_max12>=R_max34)?R_max12:R_max34)) ? R_work_p5 : ((R_max12>=R_max34)?R_max12:R_max34);
                    R_pmin <= (R_work_p5 < ((R_min12<=R_min34)?R_min12:R_min34)) ? R_work_p5 : ((R_min12<=R_min34)?R_min12:R_min34);
                    R_d15 <= (R_work_p1>=R_work_p5) ? (R_work_p1-R_work_p5) : (R_work_p5-R_work_p1);
                    R_d24 <= (R_work_p2>=R_work_p4) ? (R_work_p2-R_work_p4) : (R_work_p4-R_work_p2);
                    R_state<=ST_FLAGS_A;
                end

                ST_FLAGS_A: begin
                    R_margin<=R_pmax>>4;
                    R_sym15<=({R_d15,2'b00}<={2'b00,R_pmax}); R_sym24<=({R_d24,2'b00}<={2'b00,R_pmax});
                    R_center_high<=({R_work_p3,3'b000} >= (({3'b000,R_pmax}<<2)+({3'b000,R_pmax}<<1)+{3'b000,R_pmax}));
                    R_p1_ge50<=({R_work_p1,1'b0}>={1'b0,R_pmax}); R_p5_ge50<=({R_work_p5,1'b0}>={1'b0,R_pmax});
                    R_p1_ge75 <= ({R_work_p1, 2'b00} >= (({2'b00, R_pmax} << 1) + {2'b00, R_pmax}));
                    R_p2_ge75 <= ({R_work_p2, 2'b00} >= (({2'b00, R_pmax} << 1) + {2'b00, R_pmax}));
                    R_p3_ge75 <= ({R_work_p3, 2'b00} >= (({2'b00, R_pmax} << 1) + {2'b00, R_pmax}));
                    R_p4_ge75 <= ({R_work_p4, 2'b00} >= (({2'b00, R_pmax} << 1) + {2'b00, R_pmax}));
                    R_p5_ge75 <= ({R_work_p5, 2'b00} >= (({2'b00, R_pmax} << 1) + {2'b00, R_pmax}));
                    R_fill_ge60<=(({3'b000,R_work_area}<<2)+{3'b000,R_work_area} >= (({3'b000,R_work_bbox_area}<<1)+{3'b000,R_work_bbox_area}));
                    R_fill_ge80<=(({3'b000,R_work_area}<<2)+{3'b000,R_work_area} >= ({3'b000,R_work_bbox_area}<<2));
                    R_state<=ST_FLAGS_B;
                end

                ST_FLAGS_B: begin
                    R_profile_symmetric<=R_sym15 && R_sym24;
                    R_wide_count<={2'd0,R_p1_ge75}+{2'd0,R_p2_ge75}+{2'd0,R_p3_ge75}+{2'd0,R_p4_ge75}+{2'd0,R_p5_ge75};
                    R_circle_like<=(R_sym15 && R_sym24 && R_center_high && R_p2_ge75 && R_p4_ge75 && R_p1_ge50 && R_p5_ge50 && !R_p1_ge75 && !R_p5_ge75);
                    R_diamond_rect_like<=(R_sym15 && R_sym24 && R_center_high && !R_p1_ge50 && !R_p5_ge50 && !R_p2_ge75 && !R_p4_ge75);
                    R_state<=ST_TREND_A;
                end

                ST_TREND_A: begin
                    R_up01<=({1'b0,R_work_p2}>{1'b0,R_work_p1}+{1'b0,R_margin}); R_up12<=({1'b0,R_work_p3}>{1'b0,R_work_p2}+{1'b0,R_margin});
                    R_up23<=({1'b0,R_work_p4}>{1'b0,R_work_p3}+{1'b0,R_margin}); R_up34<=({1'b0,R_work_p5}>{1'b0,R_work_p4}+{1'b0,R_margin});
                    R_down01<=({1'b0,R_work_p1}>{1'b0,R_work_p2}+{1'b0,R_margin}); R_down12<=({1'b0,R_work_p2}>{1'b0,R_work_p3}+{1'b0,R_margin});
                    R_down23<=({1'b0,R_work_p3}>{1'b0,R_work_p4}+{1'b0,R_margin}); R_down34<=({1'b0,R_work_p4}>{1'b0,R_work_p5}+{1'b0,R_margin});
                    R_state<=ST_TREND_B;
                end

                ST_TREND_B: begin
                    R_up_score<={2'd0,R_up01}+{2'd0,R_up12}+{2'd0,R_up23}+{2'd0,R_up34};
                    R_down_score<={2'd0,R_down01}+{2'd0,R_down12}+{2'd0,R_down23}+{2'd0,R_down34};
                    R_triangle_monotonic<=(({2'd0,R_up01}+{2'd0,R_up12}+{2'd0,R_up23}+{2'd0,R_up34})>=3) ||
                                          (({2'd0,R_down01}+{2'd0,R_down12}+{2'd0,R_down23}+{2'd0,R_down34})>=3);
                    R_state<=ST_CLASSIFY_RAW;
                end

                ST_CLASSIFY_RAW: begin
                    if (!R_work_valid || (R_work_width<MIN_SHAPE_WIDTH) || (R_work_height<MIN_SHAPE_HEIGHT) ||
                        (R_work_area<MIN_TARGET_AREA) || (R_work_bbox_area==0) || (R_pmax<12)) R_shape_eval<=SHAPE_UNKNOWN;
                    else if (R_fill_ge80 || (R_wide_count>=4) || R_diamond_rect_like) R_shape_eval<=SHAPE_RECTANGLE;
                    else if (R_circle_like) R_shape_eval<=SHAPE_CIRCLE;
                    else if (R_triangle_monotonic) R_shape_eval<=SHAPE_TRIANGLE;
                    else if (!R_fill_ge60 && !R_profile_symmetric) R_shape_eval<=SHAPE_TRIANGLE;
                    else R_shape_eval<=SHAPE_UNKNOWN;
                    R_state<=ST_HISTORY;
                end

                ST_HISTORY: begin
                    case (R_color_index)
                        2'd0: begin
                            R_red_invalid_count<=S_next_invalid_count;
                            if (!R_active_valid && (S_invalid_count>=2)) begin R_red_hist0<=0; R_red_hist1<=0; R_red_hist2<=0; end
                            else begin R_red_hist2<=R_red_hist1; R_red_hist1<=R_red_hist0; R_red_hist0<=R_active_valid ? R_shape_eval : SHAPE_UNKNOWN; end
                        end
                        2'd1: begin
                            R_green_invalid_count<=S_next_invalid_count;
                            if (!R_active_valid && (S_invalid_count>=2)) begin R_green_hist0<=0; R_green_hist1<=0; R_green_hist2<=0; end
                            else begin R_green_hist2<=R_green_hist1; R_green_hist1<=R_green_hist0; R_green_hist0<=R_active_valid ? R_shape_eval : SHAPE_UNKNOWN; end
                        end
                        2'd2: begin
                            R_blue_invalid_count<=S_next_invalid_count;
                            if (!R_active_valid && (S_invalid_count>=2)) begin R_blue_hist0<=0; R_blue_hist1<=0; R_blue_hist2<=0; end
                            else begin R_blue_hist2<=R_blue_hist1; R_blue_hist1<=R_blue_hist0; R_blue_hist0<=R_active_valid ? R_shape_eval : SHAPE_UNKNOWN; end
                        end
                        default: begin
                            R_yellow_invalid_count<=S_next_invalid_count;
                            if (!R_active_valid && (S_invalid_count>=2)) begin R_yellow_hist0<=0; R_yellow_hist1<=0; R_yellow_hist2<=0; end
                            else begin R_yellow_hist2<=R_yellow_hist1; R_yellow_hist1<=R_yellow_hist0; R_yellow_hist0<=R_active_valid ? R_shape_eval : SHAPE_UNKNOWN; end
                        end
                    endcase
                    R_state<=ST_VOTE;
                end

                ST_VOTE: begin
                    case (R_color_index)
                        2'd0: R_red_stable<=S_next_stable_shape;
                        2'd1: R_green_stable<=S_next_stable_shape;
                        2'd2: R_blue_stable<=S_next_stable_shape;
                        default: R_yellow_stable<=S_next_stable_shape;
                    endcase
                    R_state<=ST_STORE;
                end

                ST_STORE: begin
                    case (R_color_index)
                        2'd0: begin
                            R_next_red_valid     <= R_active_valid;
                            R_next_red_xmin      <= R_active_valid ? S_selected_xmin : 11'd0;
                            R_next_red_xmax      <= R_active_valid ? S_selected_xmax : 11'd0;
                            R_next_red_ymin      <= R_active_valid ? S_selected_ymin : 10'd0;
                            R_next_red_ymax      <= R_active_valid ? S_selected_ymax : 10'd0;
                            R_next_red_width     <= R_active_valid ? R_active_width : 11'd0;
                            R_next_red_height    <= R_active_valid ? R_active_height : 10'd0;
                            R_next_red_area      <= R_active_valid ? R_active_area : 20'd0;
                            R_next_red_bbox_area <= R_active_valid ? R_bbox_area : 20'd0;
                            R_next_red_shape     <= S_next_stable_shape;
                            R_next_red_raw       <= R_shape_eval;
                            R_next_red_p1<=R_profile_p1; R_next_red_p2<=R_profile_p2; R_next_red_p3<=R_profile_p3; R_next_red_p4<=R_profile_p4; R_next_red_p5<=R_profile_p5;
                        end
                        2'd1: begin
                            R_next_green_valid     <= R_active_valid;
                            R_next_green_xmin      <= R_active_valid ? S_selected_xmin : 11'd0;
                            R_next_green_xmax      <= R_active_valid ? S_selected_xmax : 11'd0;
                            R_next_green_ymin      <= R_active_valid ? S_selected_ymin : 10'd0;
                            R_next_green_ymax      <= R_active_valid ? S_selected_ymax : 10'd0;
                            R_next_green_width     <= R_active_valid ? R_active_width : 11'd0;
                            R_next_green_height    <= R_active_valid ? R_active_height : 10'd0;
                            R_next_green_area      <= R_active_valid ? R_active_area : 20'd0;
                            R_next_green_bbox_area <= R_active_valid ? R_bbox_area : 20'd0;
                            R_next_green_shape     <= S_next_stable_shape;
                            R_next_green_raw       <= R_shape_eval;
                            R_next_green_p1<=R_profile_p1; R_next_green_p2<=R_profile_p2; R_next_green_p3<=R_profile_p3; R_next_green_p4<=R_profile_p4; R_next_green_p5<=R_profile_p5;
                        end
                        2'd2: begin
                            R_next_blue_valid     <= R_active_valid;
                            R_next_blue_xmin      <= R_active_valid ? S_selected_xmin : 11'd0;
                            R_next_blue_xmax      <= R_active_valid ? S_selected_xmax : 11'd0;
                            R_next_blue_ymin      <= R_active_valid ? S_selected_ymin : 10'd0;
                            R_next_blue_ymax      <= R_active_valid ? S_selected_ymax : 10'd0;
                            R_next_blue_width     <= R_active_valid ? R_active_width : 11'd0;
                            R_next_blue_height    <= R_active_valid ? R_active_height : 10'd0;
                            R_next_blue_area      <= R_active_valid ? R_active_area : 20'd0;
                            R_next_blue_bbox_area <= R_active_valid ? R_bbox_area : 20'd0;
                            R_next_blue_shape     <= S_next_stable_shape;
                            R_next_blue_raw       <= R_shape_eval;
                            R_next_blue_p1<=R_profile_p1; R_next_blue_p2<=R_profile_p2; R_next_blue_p3<=R_profile_p3; R_next_blue_p4<=R_profile_p4; R_next_blue_p5<=R_profile_p5;
                        end
                        2'd3: begin
                            R_next_yellow_valid     <= R_active_valid;
                            R_next_yellow_xmin      <= R_active_valid ? S_selected_xmin : 11'd0;
                            R_next_yellow_xmax      <= R_active_valid ? S_selected_xmax : 11'd0;
                            R_next_yellow_ymin      <= R_active_valid ? S_selected_ymin : 10'd0;
                            R_next_yellow_ymax      <= R_active_valid ? S_selected_ymax : 10'd0;
                            R_next_yellow_width     <= R_active_valid ? R_active_width : 11'd0;
                            R_next_yellow_height    <= R_active_valid ? R_active_height : 10'd0;
                            R_next_yellow_area      <= R_active_valid ? R_active_area : 20'd0;
                            R_next_yellow_bbox_area <= R_active_valid ? R_bbox_area : 20'd0;
                            R_next_yellow_shape     <= S_next_stable_shape;
                            R_next_yellow_raw       <= R_shape_eval;
                            R_next_yellow_p1<=R_profile_p1; R_next_yellow_p2<=R_profile_p2; R_next_yellow_p3<=R_profile_p3; R_next_yellow_p4<=R_profile_p4; R_next_yellow_p5<=R_profile_p5;
                        end
                    endcase
                    if (R_color_index == 2'd3)
                        R_state <= ST_DONE;
                    else begin
                        R_color_index <= R_color_index + 1'b1;
                        R_state       <= ST_LOAD;
                    end
                end

                ST_DONE: begin
                    O_red_valid    <= R_next_red_valid;
                    O_red_xmin     <= R_next_red_xmin;
                    O_red_xmax     <= R_next_red_xmax;
                    O_red_ymin     <= R_next_red_ymin;
                    O_red_ymax     <= R_next_red_ymax;
                    O_red_width    <= R_next_red_width;
                    O_red_height   <= R_next_red_height;
                    O_red_area     <= R_next_red_area;
                    O_red_bbox_area <= R_next_red_bbox_area;
                    O_red_shape    <= R_next_red_shape;
                    O_red_raw_shape<=R_next_red_raw;
                    O_red_p1<=R_next_red_p1; O_red_p2<=R_next_red_p2; O_red_p3<=R_next_red_p3; O_red_p4<=R_next_red_p4; O_red_p5<=R_next_red_p5;
                    O_green_valid    <= R_next_green_valid;
                    O_green_xmin     <= R_next_green_xmin;
                    O_green_xmax     <= R_next_green_xmax;
                    O_green_ymin     <= R_next_green_ymin;
                    O_green_ymax     <= R_next_green_ymax;
                    O_green_width    <= R_next_green_width;
                    O_green_height   <= R_next_green_height;
                    O_green_area     <= R_next_green_area;
                    O_green_bbox_area <= R_next_green_bbox_area;
                    O_green_shape  <= R_next_green_shape;
                    O_green_raw_shape<=R_next_green_raw;
                    O_green_p1<=R_next_green_p1; O_green_p2<=R_next_green_p2; O_green_p3<=R_next_green_p3; O_green_p4<=R_next_green_p4; O_green_p5<=R_next_green_p5;
                    O_blue_valid    <= R_next_blue_valid;
                    O_blue_xmin     <= R_next_blue_xmin;
                    O_blue_xmax     <= R_next_blue_xmax;
                    O_blue_ymin     <= R_next_blue_ymin;
                    O_blue_ymax     <= R_next_blue_ymax;
                    O_blue_width    <= R_next_blue_width;
                    O_blue_height   <= R_next_blue_height;
                    O_blue_area     <= R_next_blue_area;
                    O_blue_bbox_area <= R_next_blue_bbox_area;
                    O_blue_shape   <= R_next_blue_shape;
                    O_blue_raw_shape<=R_next_blue_raw;
                    O_blue_p1<=R_next_blue_p1; O_blue_p2<=R_next_blue_p2; O_blue_p3<=R_next_blue_p3; O_blue_p4<=R_next_blue_p4; O_blue_p5<=R_next_blue_p5;
                    O_yellow_valid    <= R_next_yellow_valid;
                    O_yellow_xmin     <= R_next_yellow_xmin;
                    O_yellow_xmax     <= R_next_yellow_xmax;
                    O_yellow_ymin     <= R_next_yellow_ymin;
                    O_yellow_ymax     <= R_next_yellow_ymax;
                    O_yellow_width    <= R_next_yellow_width;
                    O_yellow_height   <= R_next_yellow_height;
                    O_yellow_area     <= R_next_yellow_area;
                    O_yellow_bbox_area <= R_next_yellow_bbox_area;
                    O_yellow_shape <= R_next_yellow_shape;
                    O_yellow_raw_shape<=R_next_yellow_raw;
                    O_yellow_p1<=R_next_yellow_p1; O_yellow_p2<=R_next_yellow_p2; O_yellow_p3<=R_next_yellow_p3; O_yellow_p4<=R_next_yellow_p4; O_yellow_p5<=R_next_yellow_p5;
                    O_shape_result_toggle <= ~O_shape_result_toggle;
                    R_state        <= ST_IDLE;
                end

                default: R_state <= ST_IDLE;
            endcase
        end
    end

endmodule

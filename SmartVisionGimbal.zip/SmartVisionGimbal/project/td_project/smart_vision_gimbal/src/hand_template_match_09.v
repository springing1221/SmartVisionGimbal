// Static 0/9 template matcher for the 320x180 light-hand detector stream.
//
// TEMPLATE_0 and TEMPLATE_9 were generated from sim/template/0.png and
// sim/template/9.png. The PNG conversion uses red dominance (R >= 64,
// 2R >= 3G and 2R >= 3B); green-dominant display border pixels are background.
// Neither image was cropped: original black ROI padding and the closed hole
// in the 0 reference are retained.
//
// Runtime normalization follows exactly the same rule: the long ROI axis
// occupies 32 cells and the short axis occupies floor(32*short/long) centered
// cells. Add/compare/subtract DDA mapping avoids a variable divider.
module hand_template_match_09 #(
    parameter [7:0] MATCH_SCORE_NUM  = 8'd50,
    parameter [7:0] MATCH_SCORE_DEN  = 8'd100,
    parameter [7:0] MATCH_MARGIN_NUM = 8'd8
) (
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire        I_frame_start,
    input  wire        I_sample_valid,
    input  wire [8:0]  I_sample_x,
    input  wire [7:0]  I_sample_y,
    input  wire        I_fg,
    // Detector bbox in the 320x180 analysis-coordinate system.
    input  wire        I_roi_valid,
    input  wire [8:0]  I_roi_xmin,
    input  wire [8:0]  I_roi_xmax,
    input  wire [7:0]  I_roi_ymin,
    input  wire [7:0]  I_roi_ymax,
    output wire        O_busy,
    // Score = numerator / denominator; raw values avoid a debug divider.
    output reg [10:0]  O_score_0_num,
    output reg [10:0]  O_score_0_den,
    output reg [10:0]  O_score_9_num,
    output reg [10:0]  O_score_9_den,
    output reg         O_decision_valid,
    output reg [3:0]   O_decision_code,
    output reg         O_result_toggle
);
    localparam [3:0] CODE_0       = 4'd0,
                     CODE_9       = 4'd9,
                     CODE_UNKNOWN = 4'hf;

    localparam [3:0] ST_IDLE           = 4'd0,
                     ST_DIM_INIT       = 4'd1,
                     ST_DIM_ACCUM      = 4'd2,
                     ST_CLEAR          = 4'd3,
                     ST_WAIT_FRAME     = 4'd4,
                     ST_CAPTURE        = 4'd5,
                     ST_MATCH_INIT     = 4'd6,
                     ST_MATCH_BIT_LOAD = 4'd7,
                     ST_MATCH_BIT_STORE= 4'd8,
                     ST_MATCH_BYTE     = 4'd9,
                     ST_MATCH_MATH_LOAD= 4'd10,
                     ST_MATCH_MATH_STORE=4'd11,
                     ST_MATCH_DECIDE   = 4'd12;

    reg [3:0] S_state;
    reg [8:0] S_roi_xmin, S_roi_xmax, S_roi_width;
    reg [7:0] S_roi_ymin, S_roi_ymax, S_roi_height;
    reg       S_long_is_x;
    reg [8:0] S_long_size, S_short_size;
    reg [5:0] S_dim_step, S_short_cells;
    reg [9:0] S_dim_accum;
    reg [5:0] S_dest_width, S_dest_height, S_x_offset, S_y_offset;

    // 32x32 working image.  This is deliberately a one-bit inferred ERAM,
    // rather than 1024 flip-flops plus a 32x32 dynamic bit-write decoder.
    // Capture and match are serialized by the FSM, so its single clocked
    // access is sufficient and the normalized image is still cleared before
    // every ROI frame exactly as before.
    reg        S_norm_bit [0:1023];  /* fehdl force_ram=1, ram_style="bram_fast" */
    reg [9:0]  S_clear_index;
    reg        S_capture_armed;
    reg [5:0]  S_map_x, S_map_y;
    reg [9:0]  S_x_accum, S_y_accum;

    reg [4:0]  S_match_row;
    reg [1:0]  S_match_byte;
    reg [2:0]  S_match_bit_index;
    reg        S_match_bit_q;
    reg [7:0]  S_match_byte_data;
    reg [10:0] S_intersection_0, S_union_0, S_intersection_9, S_union_9;
    reg [18:0] S_score0_lhs, S_score0_rhs, S_score9_lhs, S_score9_rhs;
    reg [21:0] S_cross_0, S_cross_9;
    reg [29:0] S_margin0_lhs, S_margin0_rhs, S_margin9_lhs, S_margin9_rhs;
    // The four score products, two cross products and four margin products
    // are not on the pixel path.  Time-multiplexing them through one
    // multiplier avoids reserving ten DSPs for a result used once per ROI.
    reg [3:0]  S_math_step;
    reg [21:0] S_mul_a;
    reg [8:0]  S_mul_b;

    // Rows are top-to-bottom. Pixel x=0 occupies bit 0, matching live writes.
    function [31:0] F_template_0_row;
        input [4:0] F_row;
        begin
            case(F_row)
                5'd0:  F_template_0_row = 32'h007FFC00;
                5'd1:  F_template_0_row = 32'h00FFFF80;
                5'd2:  F_template_0_row = 32'h0FFFFF80;
                5'd3:  F_template_0_row = 32'h1FFFFFC0;
                5'd4:  F_template_0_row = 32'h1FFFFFC0;
                5'd5:  F_template_0_row = 32'h1FFFFFE0;
                5'd6:  F_template_0_row = 32'h1FFFFFE0;
                5'd7:  F_template_0_row = 32'h1FCFFFF0;
                5'd8:  F_template_0_row = 32'h1FC0FFF0;
                5'd9:  F_template_0_row = 32'h1FC0FFF0;
                5'd10: F_template_0_row = 32'h1FC07FF8;
                5'd11: F_template_0_row = 32'h1FE07FF8;
                5'd12: F_template_0_row = 32'h1FE07FFC;
                5'd13: F_template_0_row = 32'h1FE07FFC;
                5'd14: F_template_0_row = 32'h1FF03FFC;
                5'd15: F_template_0_row = 32'h1FF07FFC;
                5'd16: F_template_0_row = 32'h1FFFFFFC;
                5'd17: F_template_0_row = 32'h1FFFFFFC;
                5'd18: F_template_0_row = 32'h1FFFFFFC;
                5'd19: F_template_0_row = 32'h0FFFFFFC;
                5'd20: F_template_0_row = 32'h0FFFFFFC;
                5'd21: F_template_0_row = 32'h0FFFFFFC;
                5'd22: F_template_0_row = 32'h07FFFFFC;
                5'd23: F_template_0_row = 32'h07FFFFF8;
                5'd24: F_template_0_row = 32'h07FFFFF8;
                5'd25: F_template_0_row = 32'h03FFFFF0;
                5'd26: F_template_0_row = 32'h03FFFFF0;
                5'd27: F_template_0_row = 32'h03FFFFF0;
                5'd28: F_template_0_row = 32'h01FFFFE0;
                5'd29: F_template_0_row = 32'h01FFFFE0;
                5'd30: F_template_0_row = 32'h01FFFFE0;
                default:F_template_0_row = 32'h01FFFFC0;
            endcase
        end
    endfunction

    function [31:0] F_template_9_row;
        input [4:0] F_row;
        begin
            case(F_row)
                5'd0:  F_template_9_row = 32'h0007FF00;
                5'd1:  F_template_9_row = 32'h000FFF80;
                5'd2:  F_template_9_row = 32'h000FFF80;
                5'd3:  F_template_9_row = 32'h000FFF80;
                5'd4:  F_template_9_row = 32'h00073F80;
                5'd5:  F_template_9_row = 32'h00003F80;
                5'd6:  F_template_9_row = 32'h00003F80;
                5'd7:  F_template_9_row = 32'h00003F80;
                5'd8:  F_template_9_row = 32'h00FE3F80;
                5'd9:  F_template_9_row = 32'h00FFBF80;
                5'd10: F_template_9_row = 32'h00FFFF80;
                5'd11: F_template_9_row = 32'h00FFFF80;
                5'd12: F_template_9_row = 32'h01FFFF80;
                5'd13: F_template_9_row = 32'h01FFFF80;
                5'd14: F_template_9_row = 32'h01FFFF80;
                5'd15: F_template_9_row = 32'h01FFFF80;
                5'd16: F_template_9_row = 32'h01FFFF80;
                5'd17: F_template_9_row = 32'h01FFFF80;
                5'd18: F_template_9_row = 32'h01FFFF80;
                5'd19: F_template_9_row = 32'h01FFFF80;
                5'd20: F_template_9_row = 32'h01FFFF80;
                5'd21: F_template_9_row = 32'h01FFFF80;
                5'd22: F_template_9_row = 32'h01FFFF80;
                5'd23: F_template_9_row = 32'h01FFFF80;
                5'd24: F_template_9_row = 32'h01FFFF80;
                5'd25: F_template_9_row = 32'h00FFFF80;
                5'd26: F_template_9_row = 32'h003FFF80;
                5'd27: F_template_9_row = 32'h001FFF80;
                5'd28: F_template_9_row = 32'h001FFF80;
                5'd29: F_template_9_row = 32'h000FFF80;
                5'd30: F_template_9_row = 32'h000FFF80;
                default:F_template_9_row = 32'h000FFF80;
            endcase
        end
    endfunction

    function [3:0] F_popcount8;
        input [7:0] F_bits;
        integer F_i;
        begin
            F_popcount8 = 4'd0;
            for(F_i = 0; F_i < 8; F_i = F_i + 1)
                F_popcount8 = F_popcount8 + F_bits[F_i];
        end
    endfunction

    wire [10:0] S_dim_sum = {1'b0, S_dim_accum} + {2'b00, S_short_size};
    wire        S_dim_take = (S_dim_sum >= {2'b00, S_long_size});
    wire [5:0]  S_short_cells_next = S_dim_take ? (S_short_cells + 6'd1) : S_short_cells;
    wire [5:0]  S_short_cells_final = (S_short_cells_next == 6'd0) ? 6'd1 : S_short_cells_next;
    wire [5:0]  S_capture_map_x = S_map_x + S_x_offset;
    wire [5:0]  S_capture_map_y = S_map_y + S_y_offset;
    wire [9:0]  S_capture_norm_addr = {S_capture_map_y[4:0], S_capture_map_x[4:0]};
    wire [9:0]  S_match_norm_addr = {S_match_row, S_match_byte, S_match_bit_index};
    wire [31:0] S_template_0_row_value = F_template_0_row(S_match_row);
    wire [31:0] S_template_9_row_value = F_template_9_row(S_match_row);
    wire [7:0]  S_template_0_byte = (S_match_byte == 2'd0) ? S_template_0_row_value[7:0] :
                                     (S_match_byte == 2'd1) ? S_template_0_row_value[15:8] :
                                     (S_match_byte == 2'd2) ? S_template_0_row_value[23:16] :
                                                               S_template_0_row_value[31:24];
    wire [7:0]  S_template_9_byte = (S_match_byte == 2'd0) ? S_template_9_row_value[7:0] :
                                     (S_match_byte == 2'd1) ? S_template_9_row_value[15:8] :
                                     (S_match_byte == 2'd2) ? S_template_9_row_value[23:16] :
                                                               S_template_9_row_value[31:24];
    wire [7:0]  S_margin_factor = MATCH_SCORE_DEN + MATCH_MARGIN_NUM;
    wire [30:0] S_mul_product = S_mul_a * S_mul_b;
    assign O_busy = (S_state != ST_IDLE);

    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            S_state <= ST_IDLE;
            S_roi_xmin <= 9'd0; S_roi_xmax <= 9'd0; S_roi_width <= 9'd0;
            S_roi_ymin <= 8'd0; S_roi_ymax <= 8'd0; S_roi_height <= 8'd0;
            S_long_is_x <= 1'b1; S_long_size <= 9'd0; S_short_size <= 9'd0;
            S_dim_step <= 6'd0; S_dim_accum <= 10'd0; S_short_cells <= 6'd0;
            S_dest_width <= 6'd0; S_dest_height <= 6'd0;
            S_x_offset <= 6'd0; S_y_offset <= 6'd0;
            S_clear_index <= 10'd0; S_capture_armed <= 1'b0;
            S_map_x <= 6'd0; S_map_y <= 6'd0;
            S_x_accum <= 10'd0; S_y_accum <= 10'd0;
            S_match_row <= 5'd0; S_match_byte <= 2'd0;
            S_match_bit_index <= 3'd0; S_match_bit_q <= 1'b0;
            S_match_byte_data <= 8'd0;
            S_intersection_0 <= 11'd0; S_union_0 <= 11'd0;
            S_intersection_9 <= 11'd0; S_union_9 <= 11'd0;
            S_score0_lhs <= 19'd0; S_score0_rhs <= 19'd0;
            S_score9_lhs <= 19'd0; S_score9_rhs <= 19'd0;
            S_cross_0 <= 22'd0; S_cross_9 <= 22'd0;
            S_margin0_lhs <= 30'd0; S_margin0_rhs <= 30'd0;
            S_margin9_lhs <= 30'd0; S_margin9_rhs <= 30'd0;
            S_math_step <= 4'd0; S_mul_a <= 22'd0; S_mul_b <= 9'd0;
            O_score_0_num <= 11'd0; O_score_0_den <= 11'd0;
            O_score_9_num <= 11'd0; O_score_9_den <= 11'd0;
            O_decision_valid <= 1'b0; O_decision_code <= CODE_UNKNOWN;
            O_result_toggle <= 1'b0;
        end else begin
            case(S_state)
                ST_IDLE: begin
                    if(I_roi_valid && (I_roi_xmin <= I_roi_xmax) && (I_roi_ymin <= I_roi_ymax)) begin
                        S_roi_xmin <= I_roi_xmin; S_roi_xmax <= I_roi_xmax;
                        S_roi_ymin <= I_roi_ymin; S_roi_ymax <= I_roi_ymax;
                        S_roi_width <= I_roi_xmax - I_roi_xmin + 9'd1;
                        S_roi_height <= I_roi_ymax - I_roi_ymin + 8'd1;
                        S_state <= ST_DIM_INIT;
                    end
                end
                ST_DIM_INIT: begin
                    if(S_roi_width >= {1'b0, S_roi_height}) begin
                        S_long_is_x <= 1'b1; S_long_size <= S_roi_width; S_short_size <= {1'b0, S_roi_height};
                    end else begin
                        S_long_is_x <= 1'b0; S_long_size <= {1'b0, S_roi_height}; S_short_size <= S_roi_width;
                    end
                    S_dim_step <= 6'd0; S_dim_accum <= 10'd0; S_short_cells <= 6'd0;
                    S_state <= ST_DIM_ACCUM;
                end
                ST_DIM_ACCUM: begin
                    if(S_dim_step == 6'd31) begin
                        if(S_long_is_x) begin
                            S_dest_width <= 6'd32; S_dest_height <= S_short_cells_final;
                            S_x_offset <= 6'd0; S_y_offset <= (6'd32 - S_short_cells_final) >> 1;
                        end else begin
                            S_dest_width <= S_short_cells_final; S_dest_height <= 6'd32;
                            S_x_offset <= (6'd32 - S_short_cells_final) >> 1; S_y_offset <= 6'd0;
                        end
                        S_clear_index <= 10'd0; S_state <= ST_CLEAR;
                    end else begin
                        if(S_dim_take) S_dim_accum <= S_dim_sum - {2'b00, S_long_size};
                        else S_dim_accum <= S_dim_sum;
                        if(S_dim_take) S_short_cells <= S_short_cells + 6'd1;
                        S_dim_step <= S_dim_step + 6'd1;
                    end
                end
                ST_CLEAR: begin
                    S_norm_bit[S_clear_index] <= 1'b0;
                    if(S_clear_index == 10'd1023) begin
                        S_capture_armed <= 1'b0; S_state <= ST_WAIT_FRAME;
                    end else S_clear_index <= S_clear_index + 10'd1;
                end
                ST_WAIT_FRAME: begin
                    if(!I_roi_valid) S_state <= ST_IDLE;
                    else if(I_frame_start) S_capture_armed <= 1'b1;
                    if(I_roi_valid && S_capture_armed && I_sample_valid &&
                       (I_sample_x == S_roi_xmin) && (I_sample_y == S_roi_ymin)) begin
                        if(I_fg) S_norm_bit[{S_y_offset[4:0], S_x_offset[4:0]}] <= 1'b1;
                        S_map_x <= 6'd0; S_map_y <= 6'd0;
                        S_x_accum <= S_dest_width; S_y_accum <= 10'd0;
                        if(S_roi_xmin == S_roi_xmax) begin
                            if(S_roi_ymin == S_roi_ymax) S_state <= ST_MATCH_INIT;
                            else begin
                                if({4'd0,S_dest_height} >= {1'b0,S_roi_height}) begin
                                    S_map_y <= 6'd1; S_y_accum <= {4'd0,S_dest_height} - {1'b0,S_roi_height};
                                end
                                S_state <= ST_CAPTURE;
                            end
                        end else begin
                            if({4'd0,S_dest_width} >= {1'b0,S_roi_width}) begin
                                S_map_x <= 6'd1; S_x_accum <= {4'd0,S_dest_width} - {1'b0,S_roi_width};
                            end
                            S_state <= ST_CAPTURE;
                        end
                    end
                end
                ST_CAPTURE: begin
                    if(!I_roi_valid) S_state <= ST_IDLE;
                    else if(I_sample_valid && (I_sample_x >= S_roi_xmin) && (I_sample_x <= S_roi_xmax) &&
                            (I_sample_y >= S_roi_ymin) && (I_sample_y <= S_roi_ymax)) begin
                        if(I_fg && (S_capture_map_x < 6'd32) && (S_capture_map_y < 6'd32))
                            S_norm_bit[S_capture_norm_addr] <= 1'b1;
                        if((I_sample_x == S_roi_xmax) && (I_sample_y == S_roi_ymax)) S_state <= ST_MATCH_INIT;
                        else if(I_sample_x == S_roi_xmax) begin
                            S_map_x <= 6'd0; S_x_accum <= 10'd0;
                            if((S_y_accum + {4'd0,S_dest_height}) >= {1'b0,S_roi_height}) begin
                                S_y_accum <= S_y_accum + {4'd0,S_dest_height} - {1'b0,S_roi_height}; S_map_y <= S_map_y + 6'd1;
                            end else S_y_accum <= S_y_accum + {4'd0,S_dest_height};
                        end else begin
                            if((S_x_accum + {4'd0,S_dest_width}) >= {1'b0,S_roi_width}) begin
                                S_x_accum <= S_x_accum + {4'd0,S_dest_width} - {1'b0,S_roi_width}; S_map_x <= S_map_x + 6'd1;
                            end else S_x_accum <= S_x_accum + {4'd0,S_dest_width};
                        end
                    end
                end
                ST_MATCH_INIT: begin
                    S_intersection_0 <= 11'd0; S_union_0 <= 11'd0;
                    S_intersection_9 <= 11'd0; S_union_9 <= 11'd0;
                    S_match_row <= 5'd0; S_match_byte <= 2'd0;
                    S_match_bit_index <= 3'd0; S_match_byte_data <= 8'd0;
                    S_state <= ST_MATCH_BIT_LOAD;
                end
                ST_MATCH_BIT_LOAD: begin
                    // The inferred ERAM is read only from this clocked state.
                    // A byte is assembled bit-by-bit before its IoU update;
                    // bit 0 remains the left-most normalized pixel.
                    S_match_bit_q <= S_norm_bit[S_match_norm_addr];
                    S_state <= ST_MATCH_BIT_STORE;
                end
                ST_MATCH_BIT_STORE: begin
                    S_match_byte_data[S_match_bit_index] <= S_match_bit_q;
                    if(S_match_bit_index == 3'd7) begin
                        S_state <= ST_MATCH_BYTE;
                    end else begin
                        S_match_bit_index <= S_match_bit_index + 3'd1;
                        S_state <= ST_MATCH_BIT_LOAD;
                    end
                end
                ST_MATCH_BYTE: begin
                    S_intersection_0 <= S_intersection_0 + F_popcount8(S_match_byte_data & S_template_0_byte);
                    S_union_0 <= S_union_0 + F_popcount8(S_match_byte_data | S_template_0_byte);
                    S_intersection_9 <= S_intersection_9 + F_popcount8(S_match_byte_data & S_template_9_byte);
                    S_union_9 <= S_union_9 + F_popcount8(S_match_byte_data | S_template_9_byte);
                    if(S_match_byte == 2'd3) begin
                        if(S_match_row == 5'd31) begin
                            S_math_step <= 4'd0;
                            S_state <= ST_MATCH_MATH_LOAD;
                        end
                        else begin
                            S_match_row <= S_match_row + 5'd1;
                            S_match_byte <= 2'd0;
                            S_match_bit_index <= 3'd0;
                            S_match_byte_data <= 8'd0;
                            S_state <= ST_MATCH_BIT_LOAD;
                        end
                    end else begin
                        S_match_byte <= S_match_byte + 2'd1;
                        S_match_bit_index <= 3'd0;
                        S_match_byte_data <= 8'd0;
                        S_state <= ST_MATCH_BIT_LOAD;
                    end
                end
                ST_MATCH_MATH_LOAD: begin
                    // Preserve the former product order and operands exactly;
                    // only the hardware resource is shared across cycles.
                    if(S_math_step == 4'd0) begin
                        O_score_0_num <= S_intersection_0; O_score_0_den <= S_union_0;
                        O_score_9_num <= S_intersection_9; O_score_9_den <= S_union_9;
                    end
                    case(S_math_step)
                        4'd0: begin S_mul_a <= {11'd0, S_intersection_0}; S_mul_b <= {1'b0, MATCH_SCORE_DEN}; end
                        4'd1: begin S_mul_a <= {11'd0, S_union_0};        S_mul_b <= {1'b0, MATCH_SCORE_NUM}; end
                        4'd2: begin S_mul_a <= {11'd0, S_intersection_9}; S_mul_b <= {1'b0, MATCH_SCORE_DEN}; end
                        4'd3: begin S_mul_a <= {11'd0, S_union_9};        S_mul_b <= {1'b0, MATCH_SCORE_NUM}; end
                        4'd4: begin S_mul_a <= {11'd0, S_intersection_0}; S_mul_b <= {1'b0, S_union_9}; end
                        4'd5: begin S_mul_a <= {11'd0, S_intersection_9}; S_mul_b <= {1'b0, S_union_0}; end
                        4'd6: begin S_mul_a <= S_cross_0;                 S_mul_b <= {1'b0, MATCH_SCORE_DEN}; end
                        4'd7: begin S_mul_a <= S_cross_9;                 S_mul_b <= {1'b0, S_margin_factor}; end
                        4'd8: begin S_mul_a <= S_cross_9;                 S_mul_b <= {1'b0, MATCH_SCORE_DEN}; end
                        default: begin S_mul_a <= S_cross_0;              S_mul_b <= {1'b0, S_margin_factor}; end
                    endcase
                    S_state <= ST_MATCH_MATH_STORE;
                end
                ST_MATCH_MATH_STORE: begin
                    case(S_math_step)
                        4'd0: S_score0_lhs  <= S_mul_product[18:0];
                        4'd1: S_score0_rhs  <= S_mul_product[18:0];
                        4'd2: S_score9_lhs  <= S_mul_product[18:0];
                        4'd3: S_score9_rhs  <= S_mul_product[18:0];
                        4'd4: S_cross_0     <= S_mul_product[21:0];
                        4'd5: S_cross_9     <= S_mul_product[21:0];
                        4'd6: S_margin0_lhs <= S_mul_product[29:0];
                        4'd7: S_margin0_rhs <= S_mul_product[29:0];
                        4'd8: S_margin9_lhs <= S_mul_product[29:0];
                        default: S_margin9_rhs <= S_mul_product[29:0];
                    endcase
                    if(S_math_step == 4'd9)
                        S_state <= ST_MATCH_DECIDE;
                    else begin
                        S_math_step <= S_math_step + 4'd1;
                        S_state <= ST_MATCH_MATH_LOAD;
                    end
                end
                ST_MATCH_DECIDE: begin
                    O_decision_code <= CODE_UNKNOWN; O_decision_valid <= 1'b0;
                    if((S_union_0 != 11'd0) && (S_union_9 != 11'd0) &&
                       (S_score0_lhs >= S_score0_rhs) && (S_margin0_lhs >= S_margin0_rhs)) begin
                        O_decision_code <= CODE_0; O_decision_valid <= 1'b1;
                    end else if((S_union_0 != 11'd0) && (S_union_9 != 11'd0) &&
                                (S_score9_lhs >= S_score9_rhs) && (S_margin9_lhs >= S_margin9_rhs)) begin
                        O_decision_code <= CODE_9; O_decision_valid <= 1'b1;
                    end
                    O_result_toggle <= ~O_result_toggle; S_state <= ST_IDLE;
                end
                default: S_state <= ST_IDLE;
            endcase
        end
    end
endmodule

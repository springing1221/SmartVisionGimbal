module clock_display_cdc #(
    parameter [25:0] RESET_DATA = {2'b00, 24'h175500}
) (
    input wire I_src_clk,
    input wire I_src_rst_n,
    input wire [25:0] I_src_data,
    input wire I_dst_clk,
    input wire I_dst_rst_n,
    input wire I_dst_frame_start,
    output reg [25:0] O_dst_data
);
    reg [25:0] source_hold;
    reg request_toggle;
    reg ack_sync1, ack_sync2;
    reg request_sync1, request_sync2, request_seen;
    reg ack_toggle;

    always @(posedge I_src_clk or negedge I_src_rst_n) begin
        if (!I_src_rst_n) begin
            source_hold <= RESET_DATA;
            request_toggle <= 1'b0;
            ack_sync1 <= 1'b0;
            ack_sync2 <= 1'b0;
        end else begin
            ack_sync1 <= ack_toggle;
            ack_sync2 <= ack_sync1;
            if (request_toggle == ack_sync2 && source_hold != I_src_data) begin
                source_hold <= I_src_data;
                request_toggle <= ~request_toggle;
            end
        end
    end

    always @(posedge I_dst_clk or negedge I_dst_rst_n) begin
        if (!I_dst_rst_n) begin
            request_sync1 <= 1'b0;
            request_sync2 <= 1'b0;
            request_seen <= 1'b0;
            ack_toggle <= 1'b0;
            O_dst_data <= RESET_DATA;
        end else begin
            request_sync1 <= request_toggle;
            request_sync2 <= request_sync1;
            if (I_dst_frame_start && request_sync2 != request_seen) begin
                O_dst_data <= source_hold;
                request_seen <= request_sync2;
                ack_toggle <= request_sync2;
            end
        end
    end
endmodule

module color_classify_96 (
    input  wire [95:0] I_tdata,
    output wire [3:0]  O_red_mask,
    output wire [3:0]  O_green_mask,
    output wire [3:0]  O_blue_mask,
    output wire [3:0]  O_yellow_mask,
    output wire [95:0] O_debug_tdata
);

    localparam [2:0] CLASS_NONE   = 3'd0;
    localparam [2:0] CLASS_RED    = 3'd1;
    localparam [2:0] CLASS_GREEN  = 3'd2;
    localparam [2:0] CLASS_BLUE   = 3'd3;
    localparam [2:0] CLASS_YELLOW = 3'd4;

    wire [2:0] S_class0;
    wire [2:0] S_class1;
    wire [2:0] S_class2;
    wire [2:0] S_class3;

    function [2:0] classify_pixel;
        input [7:0] r;
        input [7:0] g;
        input [7:0] b;
        reg [8:0] r_ext;
        reg [8:0] g_ext;
        reg [8:0] b_ext;
        reg [7:0] rg_diff;
        begin
            r_ext = {1'b0, r};
            g_ext = {1'b0, g};
            b_ext = {1'b0, b};
            if (r >= g)
                rg_diff = r - g;
            else
                rg_diff = g - r;

            /* Priority is yellow, red, green, blue, then background/none. */
            if ((r > 8'd100) && (g > 8'd100) && (rg_diff < 8'd30) &&
                (r_ext > (b_ext + 9'd25)) && (g_ext > (b_ext + 9'd25)))
                classify_pixel = CLASS_YELLOW;
            else if ((r > 8'd70) && (r_ext > (g_ext + 9'd25)) &&
                     (r_ext > (b_ext + 9'd35)))
                classify_pixel = CLASS_RED;
            else if ((g > 8'd70) && (g_ext > (r_ext + 9'd25)) &&
                     (g_ext > (b_ext + 9'd25)))
                classify_pixel = CLASS_GREEN;
            else if ((b > 8'd70) && (b_ext > (r_ext + 9'd35)) &&
                     (b_ext > (g_ext + 9'd20)))
                classify_pixel = CLASS_BLUE;
            else
                classify_pixel = CLASS_NONE;
        end
    endfunction

    function [23:0] debug_pixel;
        input [2:0] pixel_class;
        begin
            case (pixel_class)
                CLASS_RED:    debug_pixel = 24'hff0000;
                CLASS_GREEN:  debug_pixel = 24'h00ff00;
                CLASS_BLUE:   debug_pixel = 24'h0000ff;
                CLASS_YELLOW: debug_pixel = 24'hffff00;
                default:      debug_pixel = 24'h000000;
            endcase
        end
    endfunction

    /* RGB96 lane order: P0 is bits [23:0], P3 is bits [95:72]. */
    assign S_class0 = classify_pixel(I_tdata[23:16], I_tdata[15:8],  I_tdata[7:0]);
    assign S_class1 = classify_pixel(I_tdata[47:40], I_tdata[39:32], I_tdata[31:24]);
    assign S_class2 = classify_pixel(I_tdata[71:64], I_tdata[63:56], I_tdata[55:48]);
    assign S_class3 = classify_pixel(I_tdata[95:88], I_tdata[87:80], I_tdata[79:72]);

    assign O_red_mask    = {(S_class3 == CLASS_RED),    (S_class2 == CLASS_RED),
                            (S_class1 == CLASS_RED),    (S_class0 == CLASS_RED)};
    assign O_green_mask  = {(S_class3 == CLASS_GREEN),  (S_class2 == CLASS_GREEN),
                            (S_class1 == CLASS_GREEN),  (S_class0 == CLASS_GREEN)};
    assign O_blue_mask   = {(S_class3 == CLASS_BLUE),   (S_class2 == CLASS_BLUE),
                            (S_class1 == CLASS_BLUE),   (S_class0 == CLASS_BLUE)};
    assign O_yellow_mask = {(S_class3 == CLASS_YELLOW), (S_class2 == CLASS_YELLOW),
                            (S_class1 == CLASS_YELLOW), (S_class0 == CLASS_YELLOW)};

    assign O_debug_tdata = {debug_pixel(S_class3), debug_pixel(S_class2),
                            debug_pixel(S_class1), debug_pixel(S_class0)};

endmodule

module hdmi_mixer #(
    parameter H_OFFSET = 0,
    parameter V_OFFSET = 0,
    parameter IMG_WIDTH = 1600,
    parameter IMG_HEIGHT = 900,
    parameter integer DEBUG_MODE = 0
)(
    input wire        I_clk,
    input wire        I_rst_n,

    input wire        I_video_vsync,
    input wire        I_video_hsync,
    input wire        I_video_de,
    input wire        I_video_user,
    input wire        I_video_last,

    input wire[3:0]   I_debug_status,
    input wire        I_night_mode,
    input wire        I_time_setting,
    input wire [23:0] I_time_bcd,
    input wire        I_latency_valid,
    input wire [7:0]  I_latency_frames,
    input wire        I_fps_valid,
    input wire [9:0]  I_fps_tenths,
    input wire [2:0]  I_track_status,
    input wire        I_box_valid,
    input wire [10:0] I_box_x0,
    input wire [9:0]  I_box_y0,
    input wire [10:0] I_box_x1,
    input wire [9:0]  I_box_y1,

    output wire       O_video_rd_en,
    input wire[23:0]  I_video_rd_data,

    output reg        O_hdmi_vsync,
    output reg        O_hdmi_hsync,
    output reg        O_hdmi_de,
    output reg[23:0]  O_hdmi_data,
    output reg        O_roi_valid,
    output reg        O_roi_frame_start,
    output reg[10:0]  O_roi_x,
    output reg[9:0]   O_roi_y,
    output reg[23:0]  O_roi_rgb
);

    reg        S_video_vsync_1d;
    reg        S_video_vsync_2d;
    reg        S_video_hsync_1d;
    reg        S_video_hsync_2d;
    reg        S_video_de_1d;
    reg        S_video_de_2d;
    reg [23:0] S_video_data_1d;
    reg [23:0] S_video_data_2d;
    reg        S_window_active_1d;
    reg        S_window_active_2d;
    reg        S_roi_frame_pending;
    reg [11:0] S_x;
    reg [11:0] S_y;
    reg [11:0] S_x_1d, S_x_2d, S_y_1d, S_y_2d;
    reg [15:0] S_box_x_bcd, S_box_y_bcd;
    reg [15:0] S_box_x_work, S_box_y_work;
    reg [10:0] S_box_x_shift, S_box_y_shift;
    reg [3:0] S_bcd_steps;

    function [15:0] bcd_step;
        input [15:0] previous;
        input next_bit;
        integer digit_index;
        reg [15:0] value;
        begin
            value = previous;
            for (digit_index = 0; digit_index < 4; digit_index = digit_index + 1)
                if (value[digit_index*4 +: 4] >= 4'd5)
                    value[digit_index*4 +: 4] = value[digit_index*4 +: 4] + 4'd3;
            bcd_step = {value[14:0], next_bit};
        end
    endfunction

    function [4:0] glyph_row;
        input [5:0] glyph;
        input [2:0] row;
        begin
            glyph_row = 5'b00000;
            case (glyph)
                4'd0: case (row)
                    0: glyph_row=5'b01110; 1: glyph_row=5'b10001;
                    2: glyph_row=5'b10011; 3: glyph_row=5'b10101;
                    4: glyph_row=5'b11001; 5: glyph_row=5'b10001;
                    6: glyph_row=5'b01110;
                endcase
                4'd1: case (row)
                    0: glyph_row=5'b00100; 1: glyph_row=5'b01100;
                    2: glyph_row=5'b00100; 3: glyph_row=5'b00100;
                    4: glyph_row=5'b00100; 5: glyph_row=5'b00100;
                    6: glyph_row=5'b01110;
                endcase
                4'd2: case (row)
                    0: glyph_row=5'b01110; 1: glyph_row=5'b10001;
                    2: glyph_row=5'b00001; 3: glyph_row=5'b00010;
                    4: glyph_row=5'b00100; 5: glyph_row=5'b01000;
                    6: glyph_row=5'b11111;
                endcase
                4'd3: case (row)
                    0: glyph_row=5'b11110; 1: glyph_row=5'b00001;
                    2: glyph_row=5'b00001; 3: glyph_row=5'b01110;
                    4: glyph_row=5'b00001; 5: glyph_row=5'b00001;
                    6: glyph_row=5'b11110;
                endcase
                4'd4: case (row)
                    0: glyph_row=5'b00010; 1: glyph_row=5'b00110;
                    2: glyph_row=5'b01010; 3: glyph_row=5'b10010;
                    4: glyph_row=5'b11111; 5: glyph_row=5'b00010;
                    6: glyph_row=5'b00010;
                endcase
                4'd5: case (row)
                    0: glyph_row=5'b11111; 1: glyph_row=5'b10000;
                    2: glyph_row=5'b11110; 3: glyph_row=5'b00001;
                    4: glyph_row=5'b00001; 5: glyph_row=5'b10001;
                    6: glyph_row=5'b01110;
                endcase
                4'd6: case (row)
                    0: glyph_row=5'b01110; 1: glyph_row=5'b10000;
                    2: glyph_row=5'b10000; 3: glyph_row=5'b11110;
                    4: glyph_row=5'b10001; 5: glyph_row=5'b10001;
                    6: glyph_row=5'b01110;
                endcase
                4'd7: case (row)
                    0: glyph_row=5'b11111; 1: glyph_row=5'b00001;
                    2: glyph_row=5'b00010; 3: glyph_row=5'b00100;
                    4: glyph_row=5'b01000; 5: glyph_row=5'b01000;
                    6: glyph_row=5'b01000;
                endcase
                4'd8: case (row)
                    0: glyph_row=5'b01110; 1: glyph_row=5'b10001;
                    2: glyph_row=5'b10001; 3: glyph_row=5'b01110;
                    4: glyph_row=5'b10001; 5: glyph_row=5'b10001;
                    6: glyph_row=5'b01110;
                endcase
                4'd9: case (row)
                    0: glyph_row=5'b01110; 1: glyph_row=5'b10001;
                    2: glyph_row=5'b10001; 3: glyph_row=5'b01111;
                    4: glyph_row=5'b00001; 5: glyph_row=5'b00001;
                    6: glyph_row=5'b01110;
                endcase
                4'd10: case (row)
                    0: glyph_row=5'b10001; 1: glyph_row=5'b10001;
                    2: glyph_row=5'b01010; 3: glyph_row=5'b00100;
                    4: glyph_row=5'b01010; 5: glyph_row=5'b10001;
                    6: glyph_row=5'b10001;
                endcase
                4'd11: case (row)
                    0: glyph_row=5'b10001; 1: glyph_row=5'b10001;
                    2: glyph_row=5'b01010; 3: glyph_row=5'b00100;
                    4: glyph_row=5'b00100; 5: glyph_row=5'b00100;
                    6: glyph_row=5'b00100;
                endcase
                4'd12: case (row)
                    2: glyph_row=5'b00100; 5: glyph_row=5'b00100;
                endcase
                // Status text glyphs (IDs 16..31).  IDs 0..12 above are
                // retained for the existing coordinate overlay.
                6'd16: case (row) // D
                    0: glyph_row=5'b11110; 1: glyph_row=5'b10001;
                    2: glyph_row=5'b10001; 3: glyph_row=5'b10001;
                    4: glyph_row=5'b10001; 5: glyph_row=5'b10001;
                    6: glyph_row=5'b11110;
                endcase
                6'd17: case (row) // Y
                    0: glyph_row=5'b10001; 1: glyph_row=5'b10001;
                    2: glyph_row=5'b01010; 3: glyph_row=5'b00100;
                    4: glyph_row=5'b00100; 5: glyph_row=5'b00100;
                    6: glyph_row=5'b00100;
                endcase
                6'd18: case (row) // N
                    0: glyph_row=5'b10001; 1: glyph_row=5'b11001;
                    2: glyph_row=5'b10101; 3: glyph_row=5'b10011;
                    4: glyph_row=5'b10001; 5: glyph_row=5'b10001;
                    6: glyph_row=5'b10001;
                endcase
                6'd19: case (row) // I
                    0: glyph_row=5'b11111; 1: glyph_row=5'b00100;
                    2: glyph_row=5'b00100; 3: glyph_row=5'b00100;
                    4: glyph_row=5'b00100; 5: glyph_row=5'b00100;
                    6: glyph_row=5'b11111;
                endcase
                6'd20: case (row) // G
                    0: glyph_row=5'b01110; 1: glyph_row=5'b10001;
                    2: glyph_row=5'b10000; 3: glyph_row=5'b10111;
                    4: glyph_row=5'b10001; 5: glyph_row=5'b10001;
                    6: glyph_row=5'b01110;
                endcase
                6'd21: case (row) // H
                    0: glyph_row=5'b10001; 1: glyph_row=5'b10001;
                    2: glyph_row=5'b10001; 3: glyph_row=5'b11111;
                    4: glyph_row=5'b10001; 5: glyph_row=5'b10001;
                    6: glyph_row=5'b10001;
                endcase
                6'd22: case (row) // T
                    0: glyph_row=5'b11111; 1: glyph_row=5'b00100;
                    2: glyph_row=5'b00100; 3: glyph_row=5'b00100;
                    4: glyph_row=5'b00100; 5: glyph_row=5'b00100;
                    6: glyph_row=5'b00100;
                endcase
                6'd23: case (row) // W
                    0: glyph_row=5'b10001; 1: glyph_row=5'b10001;
                    2: glyph_row=5'b10001; 3: glyph_row=5'b10101;
                    4: glyph_row=5'b10101; 5: glyph_row=5'b11011;
                    6: glyph_row=5'b10001;
                endcase
                6'd24: case (row) // S
                    0: glyph_row=5'b01111; 1: glyph_row=5'b10000;
                    2: glyph_row=5'b10000; 3: glyph_row=5'b01110;
                    4: glyph_row=5'b00001; 5: glyph_row=5'b00001;
                    6: glyph_row=5'b11110;
                endcase
                6'd25: case (row) // E
                    0: glyph_row=5'b11111; 1: glyph_row=5'b10000;
                    2: glyph_row=5'b10000; 3: glyph_row=5'b11110;
                    4: glyph_row=5'b10000; 5: glyph_row=5'b10000;
                    6: glyph_row=5'b11111;
                endcase
                6'd26: case (row) // A
                    0: glyph_row=5'b01110; 1: glyph_row=5'b10001;
                    2: glyph_row=5'b10001; 3: glyph_row=5'b11111;
                    4: glyph_row=5'b10001; 5: glyph_row=5'b10001;
                    6: glyph_row=5'b10001;
                endcase
                6'd27: case (row) // R
                    0: glyph_row=5'b11110; 1: glyph_row=5'b10001;
                    2: glyph_row=5'b10001; 3: glyph_row=5'b11110;
                    4: glyph_row=5'b10100; 5: glyph_row=5'b10010;
                    6: glyph_row=5'b10001;
                endcase
                6'd28: case (row) // C
                    0: glyph_row=5'b01110; 1: glyph_row=5'b10001;
                    2: glyph_row=5'b10000; 3: glyph_row=5'b10000;
                    4: glyph_row=5'b10000; 5: glyph_row=5'b10001;
                    6: glyph_row=5'b01110;
                endcase
                6'd29: case (row) // L
                    0: glyph_row=5'b10000; 1: glyph_row=5'b10000;
                    2: glyph_row=5'b10000; 3: glyph_row=5'b10000;
                    4: glyph_row=5'b10000; 5: glyph_row=5'b10000;
                    6: glyph_row=5'b11111;
                endcase
                6'd30: case (row) // O
                    0: glyph_row=5'b01110; 1: glyph_row=5'b10001;
                    2: glyph_row=5'b10001; 3: glyph_row=5'b10001;
                    4: glyph_row=5'b10001; 5: glyph_row=5'b10001;
                    6: glyph_row=5'b01110;
                endcase
                6'd31: case (row) // K
                    0: glyph_row=5'b10001; 1: glyph_row=5'b10010;
                    2: glyph_row=5'b10100; 3: glyph_row=5'b11000;
                    4: glyph_row=5'b10100; 5: glyph_row=5'b10010;
                    6: glyph_row=5'b10001;
                endcase
                6'd32: case (row) // (
                    0: glyph_row=5'b00010; 1: glyph_row=5'b00100;
                    2: glyph_row=5'b01000; 3: glyph_row=5'b01000;
                    4: glyph_row=5'b01000; 5: glyph_row=5'b00100;
                    6: glyph_row=5'b00010;
                endcase
                6'd33: case (row) // )
                    0: glyph_row=5'b01000; 1: glyph_row=5'b00100;
                    2: glyph_row=5'b00010; 3: glyph_row=5'b00010;
                    4: glyph_row=5'b00010; 5: glyph_row=5'b00100;
                    6: glyph_row=5'b01000;
                endcase
                6'd34: case (row) // comma
                    4: glyph_row=5'b00110; 5: glyph_row=5'b00100;
                    6: glyph_row=5'b01000;
                endcase
                6'd35: case (row) // F
                    0: glyph_row=5'b11111; 1: glyph_row=5'b10000;
                    2: glyph_row=5'b10000; 3: glyph_row=5'b11110;
                    4: glyph_row=5'b10000; 5: glyph_row=5'b10000;
                    6: glyph_row=5'b10000;
                endcase
                6'd36: if (row == 3) glyph_row=5'b01110; // -
                6'd37: case (row) // M
                    0: glyph_row=5'b10001; 1: glyph_row=5'b11011;
                    2: glyph_row=5'b10101; 3: glyph_row=5'b10101;
                    4: glyph_row=5'b10001; 5: glyph_row=5'b10001;
                    6: glyph_row=5'b10001;
                endcase
                6'd38: case (row) // P
                    0: glyph_row=5'b11110; 1: glyph_row=5'b10001;
                    2: glyph_row=5'b10001; 3: glyph_row=5'b11110;
                    4: glyph_row=5'b10000; 5: glyph_row=5'b10000;
                    6: glyph_row=5'b10000;
                endcase
                6'd39: case (row) // V
                    0: glyph_row=5'b10001; 1: glyph_row=5'b10001;
                    2: glyph_row=5'b10001; 3: glyph_row=5'b10001;
                    4: glyph_row=5'b10001; 5: glyph_row=5'b01010;
                    6: glyph_row=5'b00100;
                endcase
                6'd40: if (row == 6) glyph_row=5'b00100; // .
            endcase
        end
    endfunction

    wire [11:0] label_x = I_box_x0 > 11'd1104 ? 12'd1104 : {1'b0, I_box_x0};
    wire [11:0] label_y = I_box_y0 >= 10'd16 ? {2'b0, I_box_y0} - 12'd16 :
                                                    {2'b0, I_box_y0} + 12'd2;
    wire [11:0] text_dx = S_x_2d - label_x;
    wire [11:0] text_dy = S_y_2d - label_y;
    wire text_on = I_box_valid && S_x_2d >= label_x && text_dx < 12'd176 &&
                   S_y_2d >= label_y && text_dy < 12'd14;
    wire [3:0] text_slot = text_dx[7:4];
    wire [2:0] text_col = text_dx[3:1];
    wire [2:0] text_row = text_dy[3:1];
    reg [5:0] text_glyph;
    always @* begin
        case (text_slot)
            0: text_glyph = 6'd32;
            1: text_glyph = {2'b0,S_box_x_bcd[15:12]};
            2: text_glyph = {2'b0,S_box_x_bcd[11:8]};
            3: text_glyph = {2'b0,S_box_x_bcd[7:4]};
            4: text_glyph = {2'b0,S_box_x_bcd[3:0]};
            5: text_glyph = 6'd34;
            6: text_glyph = {2'b0,S_box_y_bcd[15:12]};
            7: text_glyph = {2'b0,S_box_y_bcd[11:8]};
            8: text_glyph = {2'b0,S_box_y_bcd[7:4]};
            9: text_glyph = {2'b0,S_box_y_bcd[3:0]};
            10: text_glyph = 6'd33;
            default: text_glyph = 6'd63;
        endcase
    end
    wire [4:0] text_pattern = glyph_row(text_glyph, text_row);
    wire text_pixel = text_on && text_col < 3'd5 &&
                      text_pattern[4-text_col];

    function [7:0] frame_bcd;
        input [7:0] value;
        reg [11:0] digits;
        integer n;
        begin
            digits = 0;
            for (n=7; n>=0; n=n-1) begin
                if (digits[3:0] >= 5) digits[3:0] = digits[3:0] + 3;
                if (digits[7:4] >= 5) digits[7:4] = digits[7:4] + 3;
                if (digits[11:8] >= 5) digits[11:8] = digits[11:8] + 3;
                digits = {digits[10:0], value[n]};
            end
            frame_bcd = digits[7:0];
        end
    endfunction
    wire [7:0] latency_bcd = frame_bcd(I_latency_frames);
    // Restore V12's lower-left mode/time and tracking-state layout.
    wire [11:0] status_dx = S_x_2d - 12'd16;
    wire [11:0] status_dy = S_y_2d - 12'd664;
    wire status_line1 = status_dy < 12'd14;
    wire status_on = S_x_2d >= 12'd16 && S_x_2d < 12'd256 &&
                     S_y_2d >= 12'd664 && S_y_2d < 12'd698 &&
                     (status_line1 || (status_dy >= 12'd20 && status_dy < 12'd34));
    wire [3:0] status_slot = status_dx[7:4];
    wire [2:0] status_col = status_dx[3:1];
    wire [2:0] status_row = (status_line1 ? status_dy : status_dy - 12'd20) >> 1;
    reg [5:0] status_glyph;
    always @* begin
        status_glyph = 6'd63;
        if (status_line1) begin
            case (status_slot)
                4'd0: status_glyph = I_time_setting ? 6'd24 :
                                      I_night_mode ? 6'd18 : 6'd16;
                4'd1: status_glyph = I_time_setting ? 6'd25 :
                                      I_night_mode ? 6'd19 : 6'd26;
                4'd2: status_glyph = I_time_setting ? 6'd22 :
                                      I_night_mode ? 6'd20 : 6'd17;
                4'd3: if (!I_time_setting && I_night_mode)
                          status_glyph = 6'd21;
                4'd4: if (!I_time_setting && I_night_mode)
                          status_glyph = 6'd22;
                4'd7: status_glyph = {2'b00, I_time_bcd[23:20]};
                4'd8: status_glyph = {2'b00, I_time_bcd[19:16]};
                4'd9: status_glyph = 6'd12;
                4'd10: status_glyph = {2'b00, I_time_bcd[15:12]};
                4'd11: status_glyph = {2'b00, I_time_bcd[11:8]};
                4'd12: status_glyph = 6'd12;
                4'd13: status_glyph = {2'b00, I_time_bcd[7:4]};
                4'd14: status_glyph = {2'b00, I_time_bcd[3:0]};
                default: status_glyph = 6'd63;
            endcase
        end else if (I_track_status >= 3'd3) begin
            case (status_slot)
                4'd0: status_glyph = 6'd19;
                4'd1: status_glyph = 6'd18;
                4'd2: status_glyph = 6'd19;
                4'd3: status_glyph = 6'd22;
            endcase
        end else if (I_track_status == 3'd2) begin
            case (status_slot)
                4'd0: status_glyph = 6'd29;
                4'd1: status_glyph = 6'd30;
                4'd2: status_glyph = 6'd28;
                4'd3: status_glyph = 6'd31;
            endcase
        end else if (I_track_status == 3'd1) begin
            case (status_slot)
                4'd0: status_glyph = 6'd24;
                4'd1: status_glyph = 6'd25;
                4'd2: status_glyph = 6'd26;
                4'd3: status_glyph = 6'd27;
                4'd4: status_glyph = 6'd28;
                4'd5: status_glyph = 6'd21;
            endcase
        end else begin
            case (status_slot)
                4'd0: status_glyph = 6'd23;
                4'd1: status_glyph = 6'd26;
                4'd2: status_glyph = 6'd19;
                4'd3: status_glyph = 6'd22;
            endcase
        end
    end
    wire [4:0] status_pattern = glyph_row(status_glyph, status_row);
    wire status_pixel = status_on && status_col < 3'd5 &&
                        status_pattern[4-status_col];
    wire box_pixel = I_box_valid &&
                     S_x_2d >= {1'b0, I_box_x0} && S_x_2d <= {1'b0, I_box_x1} &&
                     S_y_2d >= {2'b0, I_box_y0} && S_y_2d <= {2'b0, I_box_y1} &&
                     ((S_x_2d - {1'b0,I_box_x0} < 12'd2) ||
                      ({1'b0,I_box_x1} - S_x_2d < 12'd2) ||
                      (S_y_2d - {2'b0,I_box_y0} < 12'd2) ||
                      ({2'b0,I_box_y1} - S_y_2d < 12'd2));

    wire logo_pre_on = S_x_1d < 12'd160 && S_y_1d < 12'd160;
    wire [14:0] logo_addr = logo_pre_on ?
        (({3'd0,S_y_1d} << 7) + ({3'd0,S_y_1d} << 5) + {3'd0,S_x_1d}) : 15'd0;
    wire [24:0] logo_pixel;
    anlogic_logo_packed u_logo(.I_clk(I_clk), .I_addr(logo_addr), .O_pixel(logo_pixel));
    wire logo_on = S_x_2d < 12'd160 && S_y_2d < 12'd160 && logo_pixel[24];
    wire original_count_pixel;
    original_count_osd u_original_count (
        .I_clk(I_clk), .I_rst_n(I_rst_n), .I_frame_start(I_video_user),
        .I_x(S_x_2d), .I_y(S_y_2d), .O_pixel(original_count_pixel)
    );
    function [11:0] fps_bcd_convert;
        input [9:0] value;
        reg [11:0] digits;
        integer n;
        begin
            digits=0;
            for (n=9; n>=0; n=n-1) begin
                if (digits[3:0]>=5) digits[3:0]=digits[3:0]+3;
                if (digits[7:4]>=5) digits[7:4]=digits[7:4]+3;
                if (digits[11:8]>=5) digits[11:8]=digits[11:8]+3;
                digits={digits[10:0],value[n]};
            end
            fps_bcd_convert=digits;
        end
    endfunction
    wire [11:0] fps_digits = fps_bcd_convert(I_fps_tenths);
    wire info_on = S_x_2d >= 12'd992 && S_x_2d < 12'd1264 &&
                   ((S_y_2d >= 12'd16 && S_y_2d < 12'd32) ||
                    (S_y_2d >= 12'd36 && S_y_2d < 12'd52));
    wire info_top = S_y_2d < 12'd32;
    wire [11:0] info_x = S_x_2d - 12'd992;
    wire [4:0] info_slot = info_x[8:4];
    wire [2:0] info_col = info_x[3:1];
    wire [3:0] info_y = info_top ? S_y_2d - 12'd16 : S_y_2d - 12'd36;
    wire [2:0] info_row = info_y[3:1];
    reg [5:0] info_glyph;
    always @* begin
        info_glyph=6'd63;
        if (info_top) begin
            case (info_slot)
                0:info_glyph=6'd28; 1:info_glyph=6'd26; 2:info_glyph=6'd37;
                3:info_glyph=6'd25; 4:info_glyph=6'd27; 5:info_glyph=6'd26;
                7:info_glyph=6'd35; 8:info_glyph=6'd38; 9:info_glyph=6'd24; 10:info_glyph=6'd12;
                12:info_glyph=I_fps_valid ? {2'b0,fps_digits[11:8]} : 6'd36;
                13:info_glyph=I_fps_valid ? {2'b0,fps_digits[7:4]} : 6'd36;
                14:info_glyph=6'd40;
                15:info_glyph=I_fps_valid ? {2'b0,fps_digits[3:0]} : 6'd36;
            endcase
        end else begin
            case (info_slot)
                0:info_glyph=6'd39; 1:info_glyph=6'd19; 2:info_glyph=6'd16;
                3:info_glyph=6'd25; 4:info_glyph=6'd30;
                6:info_glyph=6'd16; 7:info_glyph=6'd25; 8:info_glyph=6'd29;
                9:info_glyph=6'd26; 10:info_glyph=6'd17; 11:info_glyph=6'd12;
                13:info_glyph=I_latency_valid ? {2'b0,latency_bcd[7:4]} : 6'd36;
                14:info_glyph=I_latency_valid ? {2'b0,latency_bcd[3:0]} : 6'd36;
                16:info_glyph=6'd35;
            endcase
        end
    end
    wire [4:0] info_pattern = glyph_row(info_glyph, info_row);
    wire info_pixel = info_on && info_y < 4'd14 && info_col < 3'd5 &&
                      info_pattern[4-info_col];

    wire S_window_active;
    assign S_window_active = I_video_de &&
                             (S_x >= H_OFFSET) &&
                             (S_x < (H_OFFSET + IMG_WIDTH)) &&
                             (S_y >= V_OFFSET) &&
                             (S_y < (V_OFFSET + IMG_HEIGHT));

    // Read exactly IMG_WIDTH pixels on each of IMG_HEIGHT lines.  The HDMI
    // active area may be larger than the stored frame, in which case remaining
    // pixels are emitted as black borders without consuming DDR data.
    assign O_video_rd_en = S_window_active;

    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            S_x <= 12'd0;
            S_y <= 12'd0;
            S_x_1d <= 12'd0; S_x_2d <= 12'd0;
            S_y_1d <= 12'd0; S_y_2d <= 12'd0;
            S_box_x_bcd <= 16'd0; S_box_y_bcd <= 16'd0;
            S_box_x_work <= 16'd0; S_box_y_work <= 16'd0;
            S_box_x_shift <= 11'd0; S_box_y_shift <= 11'd0;
            S_bcd_steps <= 4'd11;
        end
        else begin
            S_x_1d <= S_x; S_x_2d <= S_x_1d;
            S_y_1d <= S_y; S_y_2d <= S_y_1d;
            if (I_video_user) begin
                S_box_x_work <= 16'd0;
                S_box_y_work <= 16'd0;
                S_box_x_shift <= ({1'b0, I_box_x0} + {1'b0, I_box_x1}) >> 1;
                S_box_y_shift <= ({1'b0, I_box_y0} + {1'b0, I_box_y1}) >> 1;
                S_bcd_steps <= 4'd0;
            end else if (S_bcd_steps < 4'd11) begin
                S_box_x_work <= bcd_step(S_box_x_work, S_box_x_shift[10]);
                S_box_y_work <= bcd_step(S_box_y_work, S_box_y_shift[10]);
                S_box_x_shift <= {S_box_x_shift[9:0], 1'b0};
                S_box_y_shift <= {S_box_y_shift[9:0], 1'b0};
                S_bcd_steps <= S_bcd_steps + 4'd1;
                if (S_bcd_steps == 4'd10) begin
                    S_box_x_bcd <= bcd_step(S_box_x_work, S_box_x_shift[10]);
                    S_box_y_bcd <= bcd_step(S_box_y_work, S_box_y_shift[10]);
                end
            end
            if(I_video_user)
                S_y <= 12'd0;
            else if(I_video_de && I_video_last)
                S_y <= S_y + 12'd1;

            if(!I_video_de || I_video_last)
                S_x <= 12'd0;
            else
                S_x <= S_x + 12'd1;
        end
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            S_video_vsync_1d <= 1'b0;
            S_video_vsync_2d <= 1'b0;
            S_video_hsync_1d <= 1'b0;
            S_video_hsync_2d <= 1'b0;
            S_video_de_1d    <= 1'b0;
            S_video_de_2d    <= 1'b0;
            S_window_active_1d <= 1'b0;
            S_window_active_2d <= 1'b0;
            O_hdmi_vsync     <= 1'b0;
            O_hdmi_hsync     <= 1'b0;
            O_hdmi_de        <= 1'b0;
            O_hdmi_data      <= 24'd0;
            O_roi_valid      <= 1'b0;
            O_roi_frame_start<= 1'b0;
            O_roi_x          <= 11'd0;
            O_roi_y          <= 10'd0;
            O_roi_rgb        <= 24'd0;
            S_roi_frame_pending <= 1'b0;
        end
        else begin
            S_video_vsync_1d <= I_video_vsync;
            S_video_vsync_2d <= S_video_vsync_1d;
            O_hdmi_vsync     <= S_video_vsync_2d;

            S_video_hsync_1d <= I_video_hsync;
            S_video_hsync_2d <= S_video_hsync_1d;
            O_hdmi_hsync     <= S_video_hsync_2d;

            S_video_de_1d    <= I_video_de;
            S_video_de_2d    <= S_video_de_1d;
            S_window_active_1d <= S_window_active;
            S_window_active_2d <= S_window_active_1d;
            O_hdmi_de        <= S_video_de_2d;
            S_video_data_1d  <= I_video_rd_data;
            S_video_data_2d  <= S_video_data_1d;
            O_roi_valid      <= S_window_active_2d;
            O_roi_x          <= S_x_2d[10:0];
            O_roi_y          <= S_y_2d[9:0];
            O_roi_rgb        <= S_video_data_2d;

            // Preserve the HDMI frame event until the first stored-image
            // pixel reaches the output pipeline.
            O_roi_frame_start <= S_window_active_2d && S_roi_frame_pending;
            if (I_video_user)
                S_roi_frame_pending <= 1'b1;
            else if (S_window_active_2d && S_roi_frame_pending)
                S_roi_frame_pending <= 1'b0;

            if(DEBUG_MODE == 1) begin
                if(S_video_de_2d) begin
                    if(S_x < 12'd128)
                        O_hdmi_data <= 24'hff0000;
                    else if(S_x < 12'd256)
                        O_hdmi_data <= 24'h00ff00;
                    else if(S_x < 12'd384)
                        O_hdmi_data <= 24'h0000ff;
                    else if(S_x < 12'd512)
                        O_hdmi_data <= 24'hffff00;
                    else if(S_x < 12'd640)
                        O_hdmi_data <= 24'h00ffff;
                    else if(S_x < 12'd768)
                        O_hdmi_data <= 24'hff00ff;
                    else if(S_x < 12'd896)
                        O_hdmi_data <= 24'hffffff;
                    else
                        O_hdmi_data <= 24'h202020;
                end
                else begin
                    O_hdmi_data <= 24'd0;
                end
            end
            else if(DEBUG_MODE == 2) begin
                if(S_video_de_2d) begin
                    case (I_debug_status)
                        4'b0000: O_hdmi_data <= 24'h000000;
                        4'b0001: O_hdmi_data <= 24'hff0000;
                        4'b0011: O_hdmi_data <= 24'hffff00;
                        4'b0111: O_hdmi_data <= 24'h00ff00;
                        4'b1111: O_hdmi_data <= I_video_rd_data;
                        default: O_hdmi_data <= 24'h0000ff;
                    endcase
                end
                else begin
                    O_hdmi_data <= 24'd0;
                end
            end
            else if(DEBUG_MODE == 3) begin
                if(S_video_de_2d) begin
                    if(S_x < 12'd256)
                        O_hdmi_data <= I_debug_status[0] ? 24'hff8000 : 24'h201000;
                    else if(S_x < 12'd512)
                        O_hdmi_data <= I_debug_status[1] ? 24'hffff00 : 24'h202000;
                    else if(S_x < 12'd768)
                        O_hdmi_data <= I_debug_status[2] ? 24'hff0000 : 24'h200000;
                    else
                        O_hdmi_data <= I_debug_status[3] ? 24'h00ffff : 24'h002020;
                end
                else begin
                    O_hdmi_data <= 24'd0;
                end
            end
            else if(DEBUG_MODE == 4) begin
                // Full-screen MIPI receive diagnostic.  The status is
                // generated and synchronized in design_top_wrapper.
                if(S_video_de_2d) begin
                    case (I_debug_status)
                        4'd0: O_hdmi_data <= 24'h000080; // blue: sensor config incomplete
                        4'd1: O_hdmi_data <= 24'h000000; // black: no MIPI HS traffic
                        4'd2: O_hdmi_data <= 24'h00ffff; // cyan: HS present, no complete frame
                        4'd3: O_hdmi_data <= 24'hff0000; // red: D-PHY lane error
                        4'd4: O_hdmi_data <= 24'hff00ff; // magenta: RAW10 line length error
                        4'd5: O_hdmi_data <= 24'hffff00; // yellow: not 720 lines per frame
                        4'd6: O_hdmi_data <= 24'h00ff00; // green: MIPI frame structure passed
                        4'd7: O_hdmi_data <= 24'hff8000; // orange: sensor I2C transaction error
                        default: O_hdmi_data <= 24'hffffff;
                    endcase
                end
                else begin
                    O_hdmi_data <= 24'd0;
                end
            end
            else begin
                O_hdmi_data <= !S_window_active_2d ? 24'd0 :
               (box_pixel || text_pixel) ? 24'h00ff40 :
               status_pixel ? 24'hffff00 :
               info_pixel ? 24'hffff00 :
               original_count_pixel ? 24'hfff200 :
               logo_on ? logo_pixel[23:0] :
                               S_video_data_2d;
            end
        end
    end

endmodule

// Debug-only true dual-port foreground mask store.
// Port A receives the already-aligned 320x180 decision stream in the camera
// clock domain.  Port B is a synchronous HDMI-clock reader.  It does not feed
// the detector and is enabled only for visual diagnosis of the background
// subtraction result.
module foreground_mask_debug_ram (
    input  wire        I_wr_clk,
    input  wire        I_wr_en,
    input  wire [15:0] I_wr_addr,
    input  wire        I_wr_data,
    input  wire        I_rd_clk,
    input  wire [15:0] I_rd_addr,
    output reg         O_rd_data
);
    reg S_mask [0:57599];  /* fehdl force_ram=1, ram_style="bram_fast" */

    always @(posedge I_wr_clk) begin
        if(I_wr_en)
            S_mask[I_wr_addr] <= I_wr_data;
    end

    always @(posedge I_rd_clk) begin
        O_rd_data <= S_mask[I_rd_addr];
    end
endmodule

// Four-frame background smoothing in the existing single grayscale RAM.
// Subsequent frames use (old + new + 1)/2, not an equal-weight average.
module background_sample #(
    parameter integer SAMPLE_WIDTH = 320,
    parameter integer IMAGE_HEIGHT = 720,
    parameter integer CAPTURE_FRAMES = 4
)(
    input wire I_clk, I_rst_n, I_capture, I_frame_start, I_line_end, I_valid,
    input wire [31:0] I_gray,
    output reg O_valid,
    output reg [7:0] O_gray, O_background,
    output reg [8:0] O_x,
    output reg [7:0] O_y,
    output reg O_background_ready
);
    localparam integer PIXELS = SAMPLE_WIDTH * ((IMAGE_HEIGHT+3)/4);
    reg [7:0] background [0:PIXELS-1];
    reg [8:0] beat_x;
    reg [9:0] line_y;
    reg [15:0] address, captured_count;
    reg capture_pending, capturing;
    reg [2:0] capture_pass;
    reg write_pending, write_first;
    reg [15:0] write_address;
    reg [7:0] write_gray, read_background;
    wire [8:0] x = I_frame_start ? 9'd0 : beat_x;
    wire [9:0] y = I_frame_start ? 10'd0 : line_y;
    wire [15:0] addr = I_frame_start ? 16'd0 : address;
    wire start_capture = I_frame_start && (capture_pending || I_capture);
    wire continue_capture = I_frame_start && capturing && !start_capture &&
                            captured_count == PIXELS && capture_pass < CAPTURE_FRAMES-1;
    wire capture_at_start = start_capture || continue_capture;
    wire capture_pixel = capture_at_start || (capturing && !I_frame_start);
    wire sample_pixel = I_valid && y[1:0] == 0 && x < SAMPLE_WIDTH && y < IMAGE_HEIGHT;
    wire [8:0] smooth_sum = {1'b0, read_background} + {1'b0, write_gray} + 9'd1;

    // Keep the RAM read/write process free of reset for block RAM inference.
    always @(posedge I_clk) begin
        if (sample_pixel) begin
            read_background <= background[addr];
            O_background <= background[addr];
        end
        if (write_pending)
            background[write_address] <= write_first ? write_gray : smooth_sum[8:1];
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            beat_x <= 0; line_y <= 0; address <= 0; captured_count <= 0;
            capture_pending <= 0; capturing <= 0; capture_pass <= 0;
            write_pending <= 0; write_first <= 0; write_address <= 0; write_gray <= 0;
            O_valid <= 0; O_gray <= 0; O_x <= 0; O_y <= 0;
            O_background_ready <= 0;
        end else begin
            O_valid <= 0;
            write_pending <= 0;
            if (I_capture) begin
                capture_pending <= 1;
                O_background_ready <= 0;
            end
            if (I_frame_start) begin
                beat_x <= 0; line_y <= 0; address <= 0;
                if (capture_at_start) begin
                    capture_pending <= 0;
                    capturing <= 1;
                    captured_count <= 0;
                    capture_pass <= start_capture ? 0 : capture_pass + 1'b1;
                    O_background_ready <= 0;
                end else if (capturing) begin
                    capturing <= 0;
                    O_background_ready <= captured_count == PIXELS;
                    if (captured_count != PIXELS)
                        capture_pending <= 1;
                end
            end
            if (I_line_end) begin
                beat_x <= 0;
                if (y < IMAGE_HEIGHT) line_y <= y + 1'b1;
            end else if (I_valid && x < SAMPLE_WIDTH)
                beat_x <= x + 1'b1;

            if (sample_pixel) begin
                if (capture_pixel) begin
                    write_pending <= 1;
                    write_first <= start_capture || (!I_frame_start && capture_pass == 0);
                    write_address <= addr;
                    write_gray <= I_gray[7:0];
                    captured_count <= capture_at_start ? 16'd1 : captured_count + 1'b1;
                end else if (!I_capture && !capture_pending &&
                             (O_background_ready ||
                              (I_frame_start && capturing && captured_count == PIXELS))) begin
                    O_valid <= 1;
                    O_gray <= I_gray[7:0];
                    O_x <= x;
                    O_y <= y[9:2];
                end
                address <= addr + 1'b1;
            end
        end
    end
endmodule

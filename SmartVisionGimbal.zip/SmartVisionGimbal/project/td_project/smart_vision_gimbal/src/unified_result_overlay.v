// Final HDMI-domain overlay for the unified vision system.  It deliberately
// sits after hdmi_mixer so the original tracking/status screen is bit-for-bit
// untouched outside the two new application modes.
module unified_result_overlay(
    input wire I_clk, I_rst_n, I_de, I_user, I_last,
    input wire [23:0] I_rgb,
    input wire I_gesture_enable,
    input wire I_hand_valid,
    input wire [8:0] I_hand_xmin, I_hand_xmax,
    input wire [7:0] I_hand_ymin, I_hand_ymax,
    input wire [3:0] I_gesture_code,
    input wire I_color_enable,
    input wire I_red_valid, I_green_valid, I_blue_valid, I_yellow_valid,
    input wire [10:0] I_red_xmin, I_red_xmax, I_green_xmin, I_green_xmax,
    input wire [10:0] I_blue_xmin, I_blue_xmax, I_yellow_xmin, I_yellow_xmax,
    input wire [9:0] I_red_ymin, I_red_ymax, I_green_ymin, I_green_ymax,
    input wire [9:0] I_blue_ymin, I_blue_ymax, I_yellow_ymin, I_yellow_ymax,
    input wire [2:0] I_red_shape, I_green_shape, I_blue_shape, I_yellow_shape,
    output wire [23:0] O_rgb
);
    reg [10:0] x;
    reg [9:0] y;
    wire hand_edge = I_hand_valid &&
        (((x[10:2] == I_hand_xmin) || (x[10:2] == I_hand_xmax)) &&
         (y[9:2] >= I_hand_ymin) && (y[9:2] <= I_hand_ymax) ||
         ((y[9:2] == I_hand_ymin) || (y[9:2] == I_hand_ymax)) &&
         (x[10:2] >= I_hand_xmin) && (x[10:2] <= I_hand_xmax));
    function box_edge;
        input valid;
        input [10:0] x0, x1;
        input [9:0] y0, y1;
        begin
            box_edge = valid && (((x == x0) || (x == x1)) && y >= y0 && y <= y1 ||
                                 ((y == y0) || (y == y1)) && x >= x0 && x <= x1);
        end
    endfunction
    wire red_edge = box_edge(I_red_valid,I_red_xmin,I_red_xmax,I_red_ymin,I_red_ymax);
    wire green_edge = box_edge(I_green_valid,I_green_xmin,I_green_xmax,I_green_ymin,I_green_ymax);
    wire blue_edge = box_edge(I_blue_valid,I_blue_xmin,I_blue_xmax,I_blue_ymin,I_blue_ymax);
    wire yellow_edge = box_edge(I_yellow_valid,I_yellow_xmin,I_yellow_xmax,I_yellow_ymin,I_yellow_ymax);
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin x <= 0; y <= 0; end
        else begin
            if (I_user) begin x <= 0; y <= 0; end
            else if (I_de && I_last) begin x <= 0; y <= y + 1'b1; end
            else if (I_de) x <= x + 1'b1;
        end
    end
    assign O_rgb = I_gesture_enable && hand_edge ? 24'h00ffff :
                   I_color_enable && red_edge ? 24'hff0000 :
                   I_color_enable && green_edge ? 24'h00ff00 :
                   I_color_enable && blue_edge ? 24'h0000ff :
                   I_color_enable && yellow_edge ? 24'hffff00 : I_rgb;
endmodule

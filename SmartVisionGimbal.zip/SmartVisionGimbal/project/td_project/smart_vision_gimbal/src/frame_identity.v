// Associate camera-frame sequence numbers with the existing DDR frame banks.
module frame_identity (
    input wire I_csi_clk, I_ddr_clk, I_rst_n,
    input wire I_camera_start, I_isp_start,
    input wire I_store_start, input wire [1:0] I_store_slot,
    input wire I_read_start, input wire [1:0] I_read_slot,
    output reg [15:0] O_camera_gray,
    output reg [15:0] O_read_sequence,
    output reg O_read_valid,
    output reg O_read_toggle
);
    reg [15:0] camera_sequence;
    reg [15:0] tags [0:7];
    reg [2:0] wr_ptr, rd_ptr;
    reg [3:0] queued;
    reg [15:0] isp_tag;
    reg isp_tag_valid;
    reg association_ok;
    reg [15:0] bank_tag [0:3];
    reg [3:0] bank_valid;
    (* ASYNC_REG = "TRUE" *) reg [1:0] association_sync;
    wire bypass = I_camera_start && I_isp_start && queued == 0;
    wire pop = I_isp_start && queued != 0;
    wire push = I_camera_start && !bypass && (queued < 8 || pop);
    wire [15:0] next_sequence = camera_sequence + 1'b1;
    always @(posedge I_csi_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            camera_sequence<=0; O_camera_gray<=0; wr_ptr<=0; rd_ptr<=0;
            queued<=0; isp_tag<=0; isp_tag_valid<=0; association_ok<=1;
        end else begin
            if ((I_camera_start && !push && !bypass) || (I_isp_start && !pop && !bypass))
                association_ok<=0;
            if (I_camera_start) begin
                camera_sequence<=next_sequence;
                O_camera_gray<=next_sequence ^ (next_sequence >> 1);
            end
            if (push) begin tags[wr_ptr]<=next_sequence; wr_ptr<=wr_ptr+1'b1; end
            if (I_isp_start) begin
                isp_tag_valid<=association_ok && (pop || bypass);
                if (bypass) isp_tag<=next_sequence;
                else if (pop) begin isp_tag<=tags[rd_ptr]; rd_ptr<=rd_ptr+1'b1; end
            end
            case ({push,pop})
                2'b10: queued<=queued+1'b1;
                2'b01: queued<=queued-1'b1;
            endcase
        end
    end
    // isp_tag stays stable for the frame; store_start is the synchronized ISP start.
    always @(posedge I_ddr_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            bank_valid<=0; O_read_sequence<=0; O_read_valid<=0; O_read_toggle<=0;
            association_sync<=0;
        end else begin
            association_sync<={association_sync[0],association_ok};
            if (!association_sync[1]) bank_valid<=0;
            else if (I_store_start) begin
                bank_tag[I_store_slot]<=isp_tag;
                bank_valid[I_store_slot]<=isp_tag_valid;
            end
            if (I_read_start) begin
                O_read_sequence<=bank_tag[I_read_slot];
                O_read_valid<=association_sync[1] && bank_valid[I_read_slot] &&
                    !(I_store_start && I_store_slot == I_read_slot);
                O_read_toggle<=~O_read_toggle;
            end
        end
    end
endmodule

// Original example's yellow "an-lu CNT: xxxxxx" overlay, 200 x 24 pixels.
module original_count_osd (
    input wire I_clk, I_rst_n, I_frame_start,
    input wire [11:0] I_x, I_y,
    output wire O_pixel
);
    reg [3:0] digit [0:5];
    integer i;
    reg carry;
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            for (i=0; i<6; i=i+1) digit[i] <= 0;
        end else if (I_frame_start) begin
            carry = 1;
            for (i=0; i<6; i=i+1) begin
                if (carry) begin
                    if (digit[i] == 9) digit[i] <= 0;
                    else begin digit[i] <= digit[i] + 1'b1; carry = 0; end
                end
            end
        end
    end
    wire active = I_x >= 375 && I_x < 575 && I_y >= 120 && I_y < 144;
    wire [7:0] dx = I_x - 375;
    wire [4:0] dy = I_y - 120;
    reg [7:0] char_code;
    reg [4:0] local_x, local_y;
    reg [3:0] col, row;
    wire [15:0] row_bits;
    reg char_valid;
    osd_char_lib u_font (.I_char(char_code), .I_row(row), .O_row_bits(row_bits));
    always @* begin
        char_code=0; local_x=0; local_y=0; col=0; row=0; char_valid=0;
        if (active && dx < 48 && dy >= 2 && dy < 24) begin
            char_code = dx < 24 ? 8'h80 : 8'h81;
            local_x = dx < 24 ? dx : dx - 24;
            local_y = dy - 2;
            col = (local_x * 16) / 24;
            row = (local_y * 16) / 24;
            char_valid=1;
        end else if (active && dx >= 52 && dx < 100 && dy >= 4 && dy < 20) begin
            if (dx < 68) begin char_code=8'h43; local_x=dx-52; end
            else if (dx < 84) begin char_code=8'h4e; local_x=dx-68; end
            else begin char_code=8'h54; local_x=dx-84; end
            local_y=dy-4; col=local_x; row=local_y; char_valid=1;
        end else if (active && dx >= 100 && dx < 108 && dy >= 4 && dy < 20) begin
            char_code=8'h3a; local_x=dx-100; local_y=dy-4;
            col=local_x * 2; row=local_y; char_valid=1;
        end else if (active && dx >= 110 && dx < 200) begin
            if (dx < 125) begin char_code=8'h30+digit[5]; local_x=dx-110; end
            else if (dx < 140) begin char_code=8'h30+digit[4]; local_x=dx-125; end
            else if (dx < 155) begin char_code=8'h30+digit[3]; local_x=dx-140; end
            else if (dx < 170) begin char_code=8'h30+digit[2]; local_x=dx-155; end
            else if (dx < 185) begin char_code=8'h30+digit[1]; local_x=dx-170; end
            else begin char_code=8'h30+digit[0]; local_x=dx-185; end
            col=(local_x * 16) / 15; row=(dy * 16) / 24; char_valid=1;
        end
    end
    assign O_pixel = char_valid && row_bits[15-col];
endmodule

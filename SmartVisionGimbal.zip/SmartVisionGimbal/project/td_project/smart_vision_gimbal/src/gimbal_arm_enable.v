// One-shot arming input for automatic gimbal movement.
// A stable released state must be observed after reset before a stable low
// press can arm tracking. This rejects a low level or a transient on KEY3
// while the FPGA and its I/O are starting.
module gimbal_arm_enable #(
    parameter [19:0] DEBOUNCE_CYCLES = 20'd1000000
) (
    input  wire I_clk,
    input  wire I_rst_n,
    input  wire I_button_n,
    input  wire I_permit,
    output reg  O_armed
);
    reg [1:0]  S_button_sync;
    reg [19:0] S_debounce_count;
    reg        S_release_confirmed;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            S_button_sync    <= 2'b11;
            S_debounce_count <= 20'd0;
            S_release_confirmed <= 1'b0;
            O_armed          <= 1'b0;
        end else if (!I_permit) begin
            S_button_sync <= 2'b11;
            S_debounce_count <= 20'd0;
            S_release_confirmed <= 1'b0;
            O_armed <= 1'b0;
        end else begin
            S_button_sync <= {S_button_sync[0], I_button_n};

            if (!O_armed && !S_release_confirmed) begin
                // Ignore all low levels until KEY3 has first been observed
                // released continuously after reset.
                if (S_button_sync[1]) begin
                    if (S_debounce_count == DEBOUNCE_CYCLES - 20'd1) begin
                        S_release_confirmed <= 1'b1;
                        S_debounce_count    <= 20'd0;
                    end else begin
                        S_debounce_count <= S_debounce_count + 20'd1;
                    end
                end else begin
                    S_debounce_count <= 20'd0;
                end
            end else if (!O_armed) begin
                // A new, debounced press after release arms the tracker.
                if (!S_button_sync[1]) begin
                    if (S_debounce_count == DEBOUNCE_CYCLES - 20'd1) begin
                        O_armed          <= 1'b1;
                        S_debounce_count <= 20'd0;
                    end else begin
                        S_debounce_count <= S_debounce_count + 20'd1;
                    end
                end else begin
                    S_debounce_count <= 20'd0;
                end
            end
        end
    end
endmodule

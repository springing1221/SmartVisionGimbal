// Camera-clock side-band analysis.  This module never presents ready/back
// pressure and therefore cannot alter the capture, DDR, or HDMI data path.
module unified_analysis_tap(
    input wire I_clk, I_rst_n, I_tvalid, I_tuser, I_tlast,
    input wire [95:0] I_tdata,
    input wire I_gesture_rearm,
    output wire O_hand_valid, output wire [8:0] O_hand_xmin, O_hand_xmax,
    output wire [7:0] O_hand_ymin, O_hand_ymax, output wire [3:0] O_gesture_code,
    output wire O_red_valid, O_green_valid, O_blue_valid, O_yellow_valid,
    output wire [10:0] O_red_xmin, O_red_xmax, O_green_xmin, O_green_xmax,
    output wire [10:0] O_blue_xmin, O_blue_xmax, O_yellow_xmin, O_yellow_xmax,
    output wire [9:0] O_red_ymin, O_red_ymax, O_green_ymin, O_green_ymax,
    output wire [9:0] O_blue_ymin, O_blue_ymax, O_yellow_ymin, O_yellow_ymax,
    output wire [2:0] O_red_shape, O_green_shape, O_blue_shape, O_yellow_shape
);
    wire [3:0] red_mask, green_mask, blue_mask, yellow_mask;
    wire [19:0] red_area, green_area, blue_area, yellow_area;
    wire profile_commit, frame_commit;
    wire [9:0] profile_y;
    wire [10:0] red_run, green_run, blue_run, yellow_run;
    color_classify_96 u_classify(.I_tdata(I_tdata), .O_red_mask(red_mask),
        .O_green_mask(green_mask), .O_blue_mask(blue_mask), .O_yellow_mask(yellow_mask), .O_debug_tdata());
    color_bbox_96 u_bbox(.I_clk(I_clk), .I_rst_n(I_rst_n), .I_tvalid(I_tvalid), .I_tlast(I_tlast),
        .I_red_mask(red_mask), .I_green_mask(green_mask), .I_blue_mask(blue_mask), .I_yellow_mask(yellow_mask),
        .O_red_valid(O_red_valid), .O_red_xmin(O_red_xmin), .O_red_xmax(O_red_xmax), .O_red_ymin(O_red_ymin), .O_red_ymax(O_red_ymax), .O_red_area(red_area),
        .O_green_valid(O_green_valid), .O_green_xmin(O_green_xmin), .O_green_xmax(O_green_xmax), .O_green_ymin(O_green_ymin), .O_green_ymax(O_green_ymax), .O_green_area(green_area),
        .O_blue_valid(O_blue_valid), .O_blue_xmin(O_blue_xmin), .O_blue_xmax(O_blue_xmax), .O_blue_ymin(O_blue_ymin), .O_blue_ymax(O_blue_ymax), .O_blue_area(blue_area),
        .O_yellow_valid(O_yellow_valid), .O_yellow_xmin(O_yellow_xmin), .O_yellow_xmax(O_yellow_xmax), .O_yellow_ymin(O_yellow_ymin), .O_yellow_ymax(O_yellow_ymax), .O_yellow_area(yellow_area),
        .O_profile_row_commit(profile_commit), .O_profile_y(profile_y), .O_red_run_len(red_run), .O_green_run_len(green_run), .O_blue_run_len(blue_run), .O_yellow_run_len(yellow_run), .O_frame_commit(frame_commit));
    shape_classifier u_shape(.I_clk(I_clk), .I_rst_n(I_rst_n), .I_frame_commit(frame_commit), .I_profile_row_commit(profile_commit), .I_profile_y(profile_y),
        .I_red_run_len(red_run), .I_green_run_len(green_run), .I_blue_run_len(blue_run), .I_yellow_run_len(yellow_run),
        .I_red_valid(O_red_valid), .I_red_xmin(O_red_xmin), .I_red_xmax(O_red_xmax), .I_red_ymin(O_red_ymin), .I_red_ymax(O_red_ymax), .I_red_area(red_area),
        .I_green_valid(O_green_valid), .I_green_xmin(O_green_xmin), .I_green_xmax(O_green_xmax), .I_green_ymin(O_green_ymin), .I_green_ymax(O_green_ymax), .I_green_area(green_area),
        .I_blue_valid(O_blue_valid), .I_blue_xmin(O_blue_xmin), .I_blue_xmax(O_blue_xmax), .I_blue_ymin(O_blue_ymin), .I_blue_ymax(O_blue_ymax), .I_blue_area(blue_area),
        .I_yellow_valid(O_yellow_valid), .I_yellow_xmin(O_yellow_xmin), .I_yellow_xmax(O_yellow_xmax), .I_yellow_ymin(O_yellow_ymin), .I_yellow_ymax(O_yellow_ymax), .I_yellow_area(yellow_area),
        .O_red_shape(O_red_shape), .O_green_shape(O_green_shape), .O_blue_shape(O_blue_shape), .O_yellow_shape(O_yellow_shape), .O_shape_result_toggle());
    light_hand_detector u_hand(.I_clk(I_clk), .I_rst_n(I_rst_n), .I_frame_start(I_tuser), .I_line_last(I_tlast), .I_pixel_valid(I_tvalid), .I_rgb(I_tdata[23:0]),
        .I_bg_capture_toggle(I_gesture_rearm), .O_hand_valid(O_hand_valid), .O_bbox_xmin(O_hand_xmin), .O_bbox_xmax(O_hand_xmax), .O_bbox_ymin(O_hand_ymin), .O_bbox_ymax(O_hand_ymax),
        .O_gesture_code(O_gesture_code), .O_background_ready(), .O_bg_frame_count(), .O_bg_state(), .O_lock_valid(), .O_track_state(), .O_confirm_count(), .O_lost_count(), .O_candidate_valid(), .O_wrist_valid(), .O_wrist_y(), .O_finger_max_runs(), .O_foreground_area(), .O_fail_code(), .O_area_ok(), .O_aspect_ok(), .O_fill_ok(), .O_segment_ok(), .O_result_toggle(), .O_gesture_valid(), .O_gesture_candidate_code(), .O_gesture_best_streak_2(), .O_gesture_best_streak_3(), .O_gesture_best_streak_4(), .O_gesture_best_streak_5(), .O_gesture_narrow_best(), .O_fg_mask_wr_en(), .O_fg_mask_wr_addr(), .O_fg_mask_wr_data());
endmodule

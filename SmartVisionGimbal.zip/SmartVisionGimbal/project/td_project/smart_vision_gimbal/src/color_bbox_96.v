module color_bbox_96 (
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire        I_tvalid,
    input  wire        I_tlast,
    input  wire [3:0]  I_red_mask,
    input  wire [3:0]  I_green_mask,
    input  wire [3:0]  I_blue_mask,
    input  wire [3:0]  I_yellow_mask,

    output wire        O_red_valid,
    output wire [10:0] O_red_xmin,
    output wire [10:0] O_red_xmax,
    output wire [9:0]  O_red_ymin,
    output wire [9:0]  O_red_ymax,
    output wire        O_green_valid,
    output wire [10:0] O_green_xmin,
    output wire [10:0] O_green_xmax,
    output wire [9:0]  O_green_ymin,
    output wire [9:0]  O_green_ymax,
    output wire        O_blue_valid,
    output wire [10:0] O_blue_xmin,
    output wire [10:0] O_blue_xmax,
    output wire [9:0]  O_blue_ymin,
    output wire [9:0]  O_blue_ymax,
    output wire        O_yellow_valid,
    output wire [10:0] O_yellow_xmin,
    output wire [10:0] O_yellow_xmax,
    output wire [9:0]  O_yellow_ymin,
    output wire [9:0]  O_yellow_ymax,
    output wire [19:0] O_red_area,
    output wire [19:0] O_green_area,
    output wire [19:0] O_blue_area,
    output wire [19:0] O_yellow_area,
    output wire        O_profile_row_commit,
    output wire [9:0]  O_profile_y,
    output wire [10:0] O_red_run_len,
    output wire [10:0] O_green_run_len,
    output wire [10:0] O_blue_run_len,
    output wire [10:0] O_yellow_run_len,
    output wire        O_frame_commit
);

    reg [8:0]  R_beat_x;
    reg [9:0]  R_line_y;
    wire [10:0] S_x_base;
    wire        S_frame_end;

    assign S_x_base = {R_beat_x, 2'b00};
    assign S_frame_end = I_tvalid && I_tlast && (R_line_y == 10'd719);

    color_bbox_one u_red_bbox (
        .I_clk(I_clk), .I_rst_n(I_rst_n), .I_tvalid(I_tvalid), .I_tlast(I_tlast),
        .I_frame_end(S_frame_end), .I_line_y(R_line_y), .I_x_base(S_x_base), .I_mask(I_red_mask),
        .O_valid(O_red_valid), .O_xmin(O_red_xmin), .O_xmax(O_red_xmax), .O_ymin(O_red_ymin), .O_ymax(O_red_ymax),
        .O_area(O_red_area), .O_profile_row_commit(O_profile_row_commit), .O_profile_y(O_profile_y),
        .O_profile_run_len(O_red_run_len), .O_frame_commit(O_frame_commit)
    );

    color_bbox_one u_green_bbox (
        .I_clk(I_clk), .I_rst_n(I_rst_n), .I_tvalid(I_tvalid), .I_tlast(I_tlast),
        .I_frame_end(S_frame_end), .I_line_y(R_line_y), .I_x_base(S_x_base), .I_mask(I_green_mask),
        .O_valid(O_green_valid), .O_xmin(O_green_xmin), .O_xmax(O_green_xmax), .O_ymin(O_green_ymin), .O_ymax(O_green_ymax),
        .O_area(O_green_area), .O_profile_run_len(O_green_run_len)
    );

    color_bbox_one u_blue_bbox (
        .I_clk(I_clk), .I_rst_n(I_rst_n), .I_tvalid(I_tvalid), .I_tlast(I_tlast),
        .I_frame_end(S_frame_end), .I_line_y(R_line_y), .I_x_base(S_x_base), .I_mask(I_blue_mask),
        .O_valid(O_blue_valid), .O_xmin(O_blue_xmin), .O_xmax(O_blue_xmax), .O_ymin(O_blue_ymin), .O_ymax(O_blue_ymax),
        .O_area(O_blue_area), .O_profile_run_len(O_blue_run_len)
    );

    color_bbox_one u_yellow_bbox (
        .I_clk(I_clk), .I_rst_n(I_rst_n), .I_tvalid(I_tvalid), .I_tlast(I_tlast),
        .I_frame_end(S_frame_end), .I_line_y(R_line_y), .I_x_base(S_x_base), .I_mask(I_yellow_mask),
        .O_valid(O_yellow_valid), .O_xmin(O_yellow_xmin), .O_xmax(O_yellow_xmax), .O_ymin(O_yellow_ymin), .O_ymax(O_yellow_ymax),
        .O_area(O_yellow_area), .O_profile_run_len(O_yellow_run_len)
    );

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            R_beat_x <= 9'd0;
            R_line_y <= 10'd0;
        end else if (I_tvalid) begin
            if (I_tlast) begin
                R_beat_x <= 9'd0;
                if (R_line_y == 10'd719)
                    R_line_y <= 10'd0;
                else
                    R_line_y <= R_line_y + 1'b1;
            end else if (R_beat_x == 9'd319) begin
                R_beat_x <= 9'd0;
            end else begin
                R_beat_x <= R_beat_x + 1'b1;
            end
        end
    end

endmodule


module color_bbox_one (
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire        I_tvalid,
    input  wire        I_tlast,
    input  wire        I_frame_end,
    input  wire [9:0]  I_line_y,
    input  wire [10:0] I_x_base,
    input  wire [3:0]  I_mask,
    output reg         O_valid,
    output reg  [10:0] O_xmin,
    output reg  [10:0] O_xmax,
    output reg  [9:0]  O_ymin,
    output reg  [9:0]  O_ymax,
    output reg  [19:0] O_area,
    output reg         O_profile_row_commit,
    output reg  [9:0]  O_profile_y,
    output reg  [10:0] O_profile_run_len,
    output reg         O_frame_commit
);

    localparam integer MIN_RUN_LEN    = 12;
    localparam integer X_MARGIN       = 16;
    localparam integer MAX_MISS_LINES = 3;

    /* Stage A: register one RGB96 mask beat with its BBox coordinates. */
    reg [3:0]  R_s1_mask;
    reg [10:0] R_s1_x_base;
    reg [9:0]  R_s1_line_y;
    reg        R_s1_valid;
    reg        R_s1_last;
    reg        R_s1_frame_end;

    /* Stage B state: run extending from the prior beat and row best run. */
    reg [10:0] R_carry_run_len;
    reg [10:0] R_carry_run_start;
    reg [10:0] R_best_run_len;
    reg [10:0] R_best_run_start;
    reg [10:0] R_best_run_end;

    /* Stage C input: complete row result, registered before continuity tests. */
    reg        R_row_result_pending;
    reg        R_row_result_frame_end;
    reg [10:0] R_row_result_len;
    reg [10:0] R_row_result_start;
    reg [10:0] R_row_result_end;
    reg [9:0]  R_row_result_y;

    reg [10:0] R_prev_run_start;
    reg [10:0] R_prev_run_end;
    reg        R_prev_run_valid;
    reg [2:0]  R_miss_line_count;
    reg [10:0] R_work_xmin;
    reg [10:0] R_work_xmax;
    reg [9:0]  R_work_ymin;
    reg [9:0]  R_work_ymax;
    reg [9:0]  R_valid_line_count;
    reg [19:0] R_work_area;
    reg        R_line_result_pending;
    reg        R_line_result_valid;
    reg        R_line_result_frame_end;
    reg [10:0] R_line_result_xmin;
    reg [10:0] R_line_result_xmax;
    reg [9:0]  R_line_result_y;
    reg [10:0] R_line_result_area;

    wire [10:0] S_work_xmin_commit;
    wire [10:0] S_work_xmax_commit;
    wire [9:0]  S_work_ymin_commit;
    wire [9:0]  S_work_ymax_commit;
    wire [9:0]  S_valid_line_count_commit;
    wire [19:0] S_work_area_commit;

    reg [2:0]   S_prefix_len;
    reg [2:0]   S_suffix_len;
    reg [2:0]   S_local_max_len;
    reg [1:0]   S_local_max_start;
    reg [1:0]   S_local_max_end;
    reg         S_all_one;
    reg [10:0]  S_cross_len;
    reg [10:0]  S_cross_start;
    reg [10:0]  S_cross_end;
    reg [10:0]  S_carry_run_len_after;
    reg [10:0]  S_carry_run_start_after;
    reg [10:0]  S_best_run_len_after;
    reg [10:0]  S_best_run_start_after;
    reg [10:0]  S_best_run_end_after;
    wire        S_row_has_valid_run;
    wire        S_row_position_continuous;
    wire        S_row_accept;

    function [10:0] add_x_margin;
        input [10:0] value;
        begin
            if (value > (11'd2047 - X_MARGIN))
                add_x_margin = 11'd2047;
            else
                add_x_margin = value + X_MARGIN;
        end
    endfunction

    function [10:0] sub_x_margin;
        input [10:0] value;
        begin
            if (value < X_MARGIN)
                sub_x_margin = 11'd0;
            else
                sub_x_margin = value - X_MARGIN;
        end
    endfunction

    /* Each possible 4-bit mask is reduced in parallel.  Bit 0 is lane0. */
    always @* begin
        S_prefix_len       = 3'd0;
        S_suffix_len       = 3'd0;
        S_local_max_len    = 3'd0;
        S_local_max_start  = 2'd0;
        S_local_max_end    = 2'd0;
        S_all_one          = 1'b0;
        case (R_s1_mask)
            4'b0000: begin end
            4'b0001: begin S_prefix_len=3'd1; S_local_max_len=3'd1; S_local_max_start=2'd0; S_local_max_end=2'd0; end
            4'b0010: begin S_local_max_len=3'd1; S_local_max_start=2'd1; S_local_max_end=2'd1; end
            4'b0011: begin S_prefix_len=3'd2; S_local_max_len=3'd2; S_local_max_start=2'd0; S_local_max_end=2'd1; end
            4'b0100: begin S_local_max_len=3'd1; S_local_max_start=2'd2; S_local_max_end=2'd2; end
            4'b0101: begin S_prefix_len=3'd1; S_local_max_len=3'd1; S_local_max_start=2'd0; S_local_max_end=2'd0; end
            4'b0110: begin S_local_max_len=3'd2; S_local_max_start=2'd1; S_local_max_end=2'd2; end
            4'b0111: begin S_prefix_len=3'd3; S_local_max_len=3'd3; S_local_max_start=2'd0; S_local_max_end=2'd2; end
            4'b1000: begin S_suffix_len=3'd1; S_local_max_len=3'd1; S_local_max_start=2'd3; S_local_max_end=2'd3; end
            4'b1001: begin S_prefix_len=3'd1; S_suffix_len=3'd1; S_local_max_len=3'd1; S_local_max_start=2'd0; S_local_max_end=2'd0; end
            4'b1010: begin S_suffix_len=3'd1; S_local_max_len=3'd1; S_local_max_start=2'd1; S_local_max_end=2'd1; end
            4'b1011: begin S_prefix_len=3'd2; S_suffix_len=3'd1; S_local_max_len=3'd2; S_local_max_start=2'd0; S_local_max_end=2'd1; end
            4'b1100: begin S_suffix_len=3'd2; S_local_max_len=3'd2; S_local_max_start=2'd2; S_local_max_end=2'd3; end
            4'b1101: begin S_prefix_len=3'd1; S_suffix_len=3'd2; S_local_max_len=3'd2; S_local_max_start=2'd2; S_local_max_end=2'd3; end
            4'b1110: begin S_suffix_len=3'd3; S_local_max_len=3'd3; S_local_max_start=2'd1; S_local_max_end=2'd3; end
            4'b1111: begin S_prefix_len=3'd4; S_suffix_len=3'd4; S_local_max_len=3'd4; S_local_max_start=2'd0; S_local_max_end=2'd3; S_all_one=1'b1; end
        endcase
    end

    /* Stage B contains no lane-to-lane feedback: one registered carry is
       combined with the parallel mask features, then written for next beat. */
    always @* begin
        S_cross_len   = 11'd0;
        S_cross_start = R_s1_x_base;
        S_cross_end   = R_s1_x_base;
        if (S_prefix_len != 3'd0) begin
            if (R_carry_run_len != 11'd0) begin
                S_cross_len   = R_carry_run_len + S_prefix_len;
                S_cross_start = R_carry_run_start;
            end else begin
                S_cross_len   = S_prefix_len;
                S_cross_start = R_s1_x_base;
            end
            S_cross_end = R_s1_x_base + S_prefix_len - 11'd1;
        end

        S_best_run_len_after   = R_best_run_len;
        S_best_run_start_after = R_best_run_start;
        S_best_run_end_after   = R_best_run_end;
        if (S_cross_len > S_best_run_len_after) begin
            S_best_run_len_after   = S_cross_len;
            S_best_run_start_after = S_cross_start;
            S_best_run_end_after   = S_cross_end;
        end
        if ({8'd0, S_local_max_len} > S_best_run_len_after) begin
            S_best_run_len_after   = {8'd0, S_local_max_len};
            S_best_run_start_after = R_s1_x_base + S_local_max_start;
            S_best_run_end_after   = R_s1_x_base + S_local_max_end;
        end

        if (S_all_one) begin
            if (R_carry_run_len != 11'd0) begin
                S_carry_run_len_after   = R_carry_run_len + 11'd4;
                S_carry_run_start_after = R_carry_run_start;
            end else begin
                S_carry_run_len_after   = 11'd4;
                S_carry_run_start_after = R_s1_x_base;
            end
        end else if (S_suffix_len != 3'd0) begin
            S_carry_run_len_after   = {8'd0, S_suffix_len};
            S_carry_run_start_after = R_s1_x_base + 11'd4 - S_suffix_len;
        end else begin
            S_carry_run_len_after   = 11'd0;
            S_carry_run_start_after = 11'd0;
        end
    end

    /* Stage C reads only the registered complete-row run result. */
    assign S_row_has_valid_run = (R_row_result_len >= MIN_RUN_LEN);
    assign S_row_position_continuous = !R_prev_run_valid ||
                                      ((R_row_result_start <= add_x_margin(R_prev_run_end)) &&
                                       (R_row_result_end >= sub_x_margin(R_prev_run_start)));
    assign S_row_accept = S_row_has_valid_run && S_row_position_continuous;

    /* A completed accepted run is committed to the frame accumulator one
       cycle later, keeping run selection separate from frame min/max updates. */
    assign S_work_xmin_commit = R_line_result_valid ?
                               ((R_line_result_xmin < R_work_xmin) ? R_line_result_xmin : R_work_xmin) : R_work_xmin;
    assign S_work_xmax_commit = R_line_result_valid ?
                               ((R_line_result_xmax > R_work_xmax) ? R_line_result_xmax : R_work_xmax) : R_work_xmax;
    assign S_work_ymin_commit = R_line_result_valid ?
                               ((R_line_result_y < R_work_ymin) ? R_line_result_y : R_work_ymin) : R_work_ymin;
    assign S_work_ymax_commit = R_line_result_valid ?
                               ((R_line_result_y > R_work_ymax) ? R_line_result_y : R_work_ymax) : R_work_ymax;
    assign S_valid_line_count_commit = R_valid_line_count + (R_line_result_valid ? 1'b1 : 1'b0);
    assign S_work_area_commit = R_work_area +
                                (R_line_result_valid ? {{9{1'b0}}, R_line_result_area} : 20'd0);

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            R_s1_mask            <= 4'd0;
            R_s1_x_base          <= 11'd0;
            R_s1_line_y          <= 10'd0;
            R_s1_valid           <= 1'b0;
            R_s1_last            <= 1'b0;
            R_s1_frame_end       <= 1'b0;
            R_carry_run_len      <= 11'd0;
            R_carry_run_start    <= 11'd0;
            R_best_run_len      <= 11'd0;
            R_best_run_start    <= 11'd0;
            R_best_run_end      <= 11'd0;
            R_row_result_pending   <= 1'b0;
            R_row_result_frame_end <= 1'b0;
            R_row_result_len       <= 11'd0;
            R_row_result_start     <= 11'd0;
            R_row_result_end       <= 11'd0;
            R_row_result_y         <= 10'd0;
            R_prev_run_start    <= 11'd0;
            R_prev_run_end      <= 11'd0;
            R_prev_run_valid    <= 1'b0;
            R_miss_line_count   <= 3'd0;
            R_work_xmin         <= 11'd1279;
            R_work_xmax         <= 11'd0;
            R_work_ymin         <= 10'd719;
            R_work_ymax         <= 10'd0;
            R_valid_line_count  <= 10'd0;
            R_work_area         <= 20'd0;
            R_line_result_pending   <= 1'b0;
            R_line_result_valid     <= 1'b0;
            R_line_result_frame_end <= 1'b0;
            R_line_result_xmin      <= 11'd1279;
            R_line_result_xmax      <= 11'd0;
            R_line_result_y         <= 10'd0;
            R_line_result_area      <= 11'd0;
            O_valid                 <= 1'b0;
            O_xmin                  <= 11'd0;
            O_xmax                  <= 11'd0;
            O_ymin                  <= 10'd0;
            O_ymax                  <= 10'd0;
            O_area                  <= 20'd0;
            O_profile_row_commit    <= 1'b0;
            O_profile_y             <= 10'd0;
            O_profile_run_len       <= 11'd0;
            O_frame_commit          <= 1'b0;
        end else begin
            O_frame_commit <= 1'b0;
            O_profile_row_commit <= 1'b0;
            /* Stage D: accepted row result updates the working frame BBox. */
            if (R_line_result_pending) begin
                if (R_line_result_frame_end) begin
                    if (S_valid_line_count_commit >= 10'd4) begin
                        O_valid <= 1'b1;
                        O_xmin  <= S_work_xmin_commit;
                        O_xmax  <= S_work_xmax_commit;
                        O_ymin  <= S_work_ymin_commit;
                        O_ymax  <= S_work_ymax_commit;
                        O_area  <= S_work_area_commit;
                    end else begin
                        O_valid <= 1'b0;
                        O_area  <= 20'd0;
                    end
                    O_frame_commit     <= 1'b1;

                    R_work_xmin        <= 11'd1279;
                    R_work_xmax        <= 11'd0;
                    R_work_ymin        <= 10'd719;
                    R_work_ymax        <= 10'd0;
                    R_valid_line_count <= 10'd0;
                    R_work_area        <= 20'd0;
                end else if (R_line_result_valid) begin
                    R_work_xmin        <= S_work_xmin_commit;
                    R_work_xmax        <= S_work_xmax_commit;
                    R_work_ymin        <= S_work_ymin_commit;
                    R_work_ymax        <= S_work_ymax_commit;
                    R_valid_line_count <= S_valid_line_count_commit;
                    R_work_area        <= S_work_area_commit;
                end
                R_line_result_pending <= 1'b0;
            end

            /* Stage C: evaluate the registered row against length and prior row. */
            if (R_row_result_pending) begin
                /* Registered observer tap: it is intentionally downstream of
                   the accepted-run/continuity decision and has no feedback. */
                O_profile_row_commit <= 1'b1;
                O_profile_y          <= R_row_result_y;
                O_profile_run_len    <= S_row_accept ? R_row_result_len : 11'd0;
                R_line_result_pending   <= 1'b1;
                R_line_result_valid     <= S_row_accept;
                R_line_result_frame_end <= R_row_result_frame_end;
                R_line_result_xmin      <= R_row_result_start;
                R_line_result_xmax      <= R_row_result_end;
                R_line_result_y         <= R_row_result_y;
                R_line_result_area      <= R_row_result_len;

                if (R_row_result_frame_end) begin
                    R_prev_run_valid  <= 1'b0;
                    R_miss_line_count <= 3'd0;
                end else if (S_row_accept) begin
                    R_prev_run_start  <= R_row_result_start;
                    R_prev_run_end    <= R_row_result_end;
                    R_prev_run_valid  <= 1'b1;
                    R_miss_line_count <= 3'd0;
                end else if (R_prev_run_valid) begin
                    if (R_miss_line_count >= MAX_MISS_LINES) begin
                        R_prev_run_valid  <= 1'b0;
                        R_miss_line_count <= 3'd0;
                    end else begin
                        R_miss_line_count <= R_miss_line_count + 1'b1;
                    end
                end else begin
                    R_miss_line_count <= 3'd0;
                end
                R_row_result_pending <= 1'b0;
            end

            /* Stage B: consume the registered mask beat and lock the row at EOL. */
            if (R_s1_valid) begin
                if (R_s1_last) begin
                    R_carry_run_len   <= 11'd0;
                    R_carry_run_start <= 11'd0;
                    R_best_run_len    <= 11'd0;
                    R_best_run_start  <= 11'd0;
                    R_best_run_end    <= 11'd0;

                    R_row_result_pending   <= 1'b1;
                    R_row_result_frame_end <= R_s1_frame_end;
                    R_row_result_len       <= S_best_run_len_after;
                    R_row_result_start     <= S_best_run_start_after;
                    R_row_result_end       <= S_best_run_end_after;
                    R_row_result_y         <= R_s1_line_y;
                end else begin
                    R_carry_run_len   <= S_carry_run_len_after;
                    R_carry_run_start <= S_carry_run_start_after;
                    R_best_run_len    <= S_best_run_len_after;
                    R_best_run_start  <= S_best_run_start_after;
                    R_best_run_end    <= S_best_run_end_after;
                end
            end

            /* Stage A: capture the already mask-pipelined BBox input beat. */
            if (I_tvalid) begin
                R_s1_mask      <= I_mask;
                R_s1_x_base    <= I_x_base;
                R_s1_line_y    <= I_line_y;
                R_s1_valid     <= 1'b1;
                R_s1_last      <= I_tlast;
                R_s1_frame_end <= I_frame_end;
            end else begin
                R_s1_valid <= 1'b0;
            end
        end
    end

endmodule

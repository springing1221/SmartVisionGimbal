// KEY3/KEY4 mode controller in the HDMI pixel-clock domain.
// Keys are active low. Selected mode changes only at a frame boundary;
// O_preview is a temporary, non-destructive raw-video override.
module image_mode_controller #(
    parameter integer DEBOUNCE_CYCLES    = 742500,  // 10 ms at 74.25 MHz
    parameter integer COMBO_GUARD_CYCLES = 1500000  // 20 ms dual-key window
)(
    input  wire       I_clk,
    input  wire       I_rst_n,
    input  wire       I_frame_start,
    input  wire       I_key_next_n,
    input  wire       I_key_prev_n,
    output reg  [3:0] O_mode,
    output reg        O_preview
);
    reg [1:0] key_next_sync, key_prev_sync;
    reg key_next_stable, key_prev_stable;
    reg [19:0] key_next_count, key_prev_count;
    reg key_next_press, key_prev_press;
    reg [21:0] combo_guard_count;
    reg single_pending, pending_next, combo_lock;
    reg [3:0] mode_request;

    wire both_pressed = !key_next_stable && !key_prev_stable;
    wire both_released = key_next_stable && key_prev_stable;

    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            key_next_sync <= 2'b11; key_prev_sync <= 2'b11;
            key_next_stable <= 1'b1; key_prev_stable <= 1'b1;
            key_next_count <= 20'd0; key_prev_count <= 20'd0;
            key_next_press <= 1'b0; key_prev_press <= 1'b0;
        end else begin
            key_next_sync <= {key_next_sync[0], I_key_next_n};
            key_prev_sync <= {key_prev_sync[0], I_key_prev_n};
            key_next_press <= 1'b0;
            key_prev_press <= 1'b0;
            if(key_next_sync[1] == key_next_stable)
                key_next_count <= 20'd0;
            else if(key_next_count == DEBOUNCE_CYCLES - 1) begin
                key_next_count <= 20'd0;
                if(key_next_stable && !key_next_sync[1])
                    key_next_press <= 1'b1;
                key_next_stable <= key_next_sync[1];
            end else
                key_next_count <= key_next_count + 1'b1;
            if(key_prev_sync[1] == key_prev_stable)
                key_prev_count <= 20'd0;
            else if(key_prev_count == DEBOUNCE_CYCLES - 1) begin
                key_prev_count <= 20'd0;
                if(key_prev_stable && !key_prev_sync[1])
                    key_prev_press <= 1'b1;
                key_prev_stable <= key_prev_sync[1];
            end else
                key_prev_count <= key_prev_count + 1'b1;
        end
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            mode_request <= 4'd0; O_mode <= 4'd0; O_preview <= 1'b0;
            combo_lock <= 1'b0; single_pending <= 1'b0;
            pending_next <= 1'b0; combo_guard_count <= 22'd0;
        end else begin
            if(both_pressed) begin
                combo_lock <= 1'b1; O_preview <= 1'b1;
                single_pending <= 1'b0; combo_guard_count <= 22'd0;
            end else if(combo_lock) begin
                O_preview <= 1'b0;
                if(both_released) combo_lock <= 1'b0;
            end else begin
                O_preview <= 1'b0;
                if(!single_pending && (key_next_press || key_prev_press)) begin
                    single_pending <= 1'b1;
                    pending_next <= key_next_press;
                    combo_guard_count <= 22'd0;
                end else if(single_pending) begin
                    if(both_pressed) begin
                        single_pending <= 1'b0; combo_lock <= 1'b1; O_preview <= 1'b1;
                    end else if(combo_guard_count == COMBO_GUARD_CYCLES - 1) begin
                        single_pending <= 1'b0;
                        if(pending_next)
                            mode_request <= (mode_request == 4'd13) ? 4'd0 :
                                            (mode_request == 4'd6) ? 4'd8 : mode_request + 1'b1;
                        else
                            mode_request <= (mode_request == 4'd0) ? 4'd13 :
                                            (mode_request == 4'd8) ? 4'd6 : mode_request - 1'b1;
                    end else
                        combo_guard_count <= combo_guard_count + 1'b1;
                end
            end
            if(I_frame_start) O_mode <= mode_request;
        end
    end
endmodule

// Tiny 5x7 ASCII debug OSD for the open-palm detector.  It intentionally
// contains no framebuffer or font RAM: glyph rows are a small combinational
// ROM and all displayed diagnostic data is already frame-stable.
module hand_debug_osd(
    input wire [11:0] I_x,
    input wire [11:0] I_y,
    input wire        I_background_ready,
    input wire [5:0]  I_bg_frame_count,
    input wire [1:0]  I_bg_state,
    input wire [15:0] I_exposure,
    input wire        I_hand_valid, // strict OPEN_PALM diagnostic only
    input wire        I_lock_valid,
    input wire        I_bbox_valid,
    input wire [1:0]  I_track_state,
    input wire [3:0]  I_confirm_count,
    input wire [3:0]  I_lost_count,
    input wire [16:0] I_foreground_area,
    input wire [3:0]  I_finger_segments,
    input wire        I_wrist_valid,
    input wire [3:0]  I_fail_code,
    input wire        I_gesture_valid,
    input wire [3:0]  I_gesture_code,
    input wire [3:0]  I_gesture_candidate_code,
    input wire [7:0]  I_gesture_best_streak_2,
    input wire [7:0]  I_gesture_best_streak_3,
    input wire [7:0]  I_gesture_best_streak_4,
    input wire [7:0]  I_gesture_best_streak_5,
    input wire [7:0]  I_gesture_narrow_best,
    output wire       O_panel,
    output reg        O_text
);
    localparam [3:0] FAIL_NONE   = 4'd0,
                     FAIL_NO_FG  = 4'd1,
                     FAIL_AREA   = 4'd2,
                     FAIL_ASPECT = 4'd3,
                     FAIL_FILL   = 4'd4,
                     FAIL_SEG    = 4'd5,
                     FAIL_WRIST  = 4'd6;

    // Compact operator OSD: two 16-pixel rows, 16 cells wide, placed at the
    // lower left of the active 1280x720 video.  The mixer retains the same
    // dark panel / green text treatment.
    localparam [11:0] OSD_Y = 12'd680;
    assign O_panel = (I_x < 12'd256) &&
                     (I_y >= OSD_Y) && (I_y < (OSD_Y + 12'd32));
    wire [4:0] S_col = I_x[8:4];
    wire [11:0] S_local_y = I_y - OSD_Y;
    wire [3:0] S_line = {1'b0, S_local_y[6:4]};
    wire [3:0] S_cell_x = I_x[3:0];
    wire [3:0] S_cell_y = S_local_y[3:0];
    wire S_glyph_window = O_panel && (S_col < 5'd16) &&
                           (S_line < 4'd2) &&
                          (S_cell_x >= 4'd2) && (S_cell_x <= 4'd11) &&
                          (S_cell_y >= 4'd1) && (S_cell_y <= 4'd14);
    wire [2:0] S_glyph_x = (S_cell_x - 4'd2) >> 1;
    wire [2:0] S_glyph_y = (S_cell_y - 4'd1) >> 1;

    function [7:0] F_hex;
        input [3:0] F_value;
        begin
            F_hex = (F_value < 4'd10) ? (8'd48 + F_value) :
                    (8'd65 + F_value - 4'd10);
        end
    endfunction

    function [7:0] F_dec_tens;
        input [5:0] F_value;
        begin
            if(F_value >= 6'd40) F_dec_tens = "4";
            else if(F_value >= 6'd30) F_dec_tens = "3";
            else if(F_value >= 6'd20) F_dec_tens = "2";
            else if(F_value >= 6'd10) F_dec_tens = "1";
            else F_dec_tens = "0";
        end
    endfunction

    function [7:0] F_dec_ones;
        input [5:0] F_value;
        begin
            if(F_value >= 6'd40) F_dec_ones = 8'd48 + F_value - 6'd40;
            else if(F_value >= 6'd30) F_dec_ones = 8'd48 + F_value - 6'd30;
            else if(F_value >= 6'd20) F_dec_ones = 8'd48 + F_value - 6'd20;
            else if(F_value >= 6'd10) F_dec_ones = 8'd48 + F_value - 6'd10;
            else F_dec_ones = 8'd48 + F_value;
        end
    endfunction

    function [7:0] F_fail_char;
        input [3:0] F_code;
        input [3:0] F_index;
        begin
            case(F_code)
                FAIL_NONE:   case(F_index) 0:F_fail_char="N"; 1:F_fail_char="O"; 2:F_fail_char="N"; 3:F_fail_char="E"; default:F_fail_char=" "; endcase
                FAIL_NO_FG:  case(F_index) 0:F_fail_char="N"; 1:F_fail_char="O"; 2:F_fail_char=" "; 3:F_fail_char="F"; 4:F_fail_char="G"; default:F_fail_char=" "; endcase
                FAIL_AREA:   case(F_index) 0:F_fail_char="A"; 1:F_fail_char="R"; 2:F_fail_char="E"; 3:F_fail_char="A"; default:F_fail_char=" "; endcase
                FAIL_ASPECT: case(F_index) 0:F_fail_char="A"; 1:F_fail_char="S"; 2:F_fail_char="P"; 3:F_fail_char="E"; 4:F_fail_char="C"; 5:F_fail_char="T"; default:F_fail_char=" "; endcase
                FAIL_FILL:   case(F_index) 0:F_fail_char="F"; 1:F_fail_char="I"; 2:F_fail_char="L"; 3:F_fail_char="L"; default:F_fail_char=" "; endcase
                FAIL_SEG:    case(F_index) 0:F_fail_char="R"; 1:F_fail_char="U"; 2:F_fail_char="N"; default:F_fail_char=" "; endcase
                FAIL_WRIST:  case(F_index) 0:F_fail_char="W"; 1:F_fail_char="R"; 2:F_fail_char="I"; 3:F_fail_char="S"; 4:F_fail_char="T"; default:F_fail_char=" "; endcase
                default:     case(F_index) 0:F_fail_char="O"; 1:F_fail_char="T"; 2:F_fail_char="H"; 3:F_fail_char="E"; 4:F_fail_char="R"; default:F_fail_char=" "; endcase
            endcase
        end
    endfunction

    // LOCKED is the only state in which the tracker has a current, locally
    // continuous hand target.  Do not use bbox-valid here: a box is merely a
    // drawing permission and may be true during initial confirmation.  Also
    // gate lock-valid with the state because lock-valid remains asserted while
    // the detector is in LOST pending its loss confirmation.
    wire S_display_hand = I_lock_valid && (I_track_state == 2'd2);
    wire S_display_number = S_display_hand && I_gesture_valid;

    function [7:0] F_char;
        input [2:0] F_line;
        input [4:0] F_col;
        begin
            F_char = " ";
            case(F_line)
                3'd0: begin
                    // STATE: HAND / STATE: NON-HAND
                    case(F_col)
                        0:F_char="S"; 1:F_char="T"; 2:F_char="A"; 3:F_char="T";
                        4:F_char="E"; 5:F_char=":"; 6:F_char=" ";
                        7:F_char=S_display_hand ? "H" : "N";
                        8:F_char=S_display_hand ? "A" : "O";
                        9:F_char=S_display_hand ? "N" : "N";
                        10:F_char=S_display_hand ? "D" : "-";
                        11:F_char=S_display_hand ? " " : "H";
                        12:F_char=S_display_hand ? " " : "A";
                        13:F_char=S_display_hand ? " " : "N";
                        14:F_char=S_display_hand ? " " : "D";
                        default:F_char=" ";
                    endcase
                end
                3'd1: begin
                    // NUMBER always consumes the stable, frame-confirmed code;
                    // no per-frame candidate is displayed.
                    case(F_col)
                        0:F_char="N"; 1:F_char="U"; 2:F_char="M"; 3:F_char="B";
                        4:F_char="E"; 5:F_char="R"; 6:F_char=":"; 7:F_char=" ";
                        // The stable valid flag is independent of the numeric
                        // encoding, so a legal fist code of zero prints as 0.
                        8:F_char=S_display_number ? F_hex(I_gesture_code) : "-";
                        9:F_char=S_display_number ? " " : "-";
                        default:F_char=" ";
                    endcase
                end
                default: F_char=" ";
            endcase
        end
    endfunction

    function [4:0] F_glyph_row;
        input [7:0] F_char_in;
        input [2:0] F_row;
        begin
            F_glyph_row = 5'b00000;
            case(F_char_in)
                "0":case(F_row)0,6:F_glyph_row=5'b01110; 1,2,3,4,5:F_glyph_row=5'b10001; endcase
                "1":case(F_row)0:F_glyph_row=5'b00100; 1:F_glyph_row=5'b01100; 2,3,4,5,6:F_glyph_row=5'b00100; endcase
                "2":case(F_row)0:F_glyph_row=5'b01110; 1:F_glyph_row=5'b10001; 2:F_glyph_row=5'b00010; 3:F_glyph_row=5'b00100; 4:F_glyph_row=5'b01000; 5,6:F_glyph_row=5'b11111; endcase
                "3":case(F_row)0,6:F_glyph_row=5'b01110; 1,5:F_glyph_row=5'b10001; 2,3,4:F_glyph_row=5'b00110; endcase
                "4":case(F_row)0:F_glyph_row=5'b00010; 1:F_glyph_row=5'b00110; 2:F_glyph_row=5'b01010; 3:F_glyph_row=5'b10010; 4,5:F_glyph_row=5'b11111; 6:F_glyph_row=5'b00010; endcase
                "5":case(F_row)0,1:F_glyph_row=5'b11111; 2:F_glyph_row=5'b10000; 3:F_glyph_row=5'b11110; 4,5:F_glyph_row=5'b00001; 6:F_glyph_row=5'b11110; endcase
                "6":case(F_row)0:F_glyph_row=5'b01110; 1:F_glyph_row=5'b10000; 2:F_glyph_row=5'b11110; 3,4,5:F_glyph_row=5'b10001; 6:F_glyph_row=5'b01110; endcase
                "7":case(F_row)0:F_glyph_row=5'b11111; 1:F_glyph_row=5'b00001; 2:F_glyph_row=5'b00010; 3:F_glyph_row=5'b00100; 4:F_glyph_row=5'b01000; 5,6:F_glyph_row=5'b01000; endcase
                "8":case(F_row)0,3,6:F_glyph_row=5'b01110; 1,2,4,5:F_glyph_row=5'b10001; endcase
                "9":case(F_row)0:F_glyph_row=5'b01110; 1,2:F_glyph_row=5'b10001; 3:F_glyph_row=5'b01111; 4,5:F_glyph_row=5'b00001; 6:F_glyph_row=5'b01110; endcase
                "A":case(F_row)0:F_glyph_row=5'b01110; 1,2:F_glyph_row=5'b10001; 3:F_glyph_row=5'b11111; 4,5,6:F_glyph_row=5'b10001; endcase
                "B":case(F_row)0,3,6:F_glyph_row=5'b11110; 1,2,4,5:F_glyph_row=5'b10001; endcase
                "C":case(F_row)0,6:F_glyph_row=5'b01111; 1,2,3,4,5:F_glyph_row=5'b10000; endcase
                "D":case(F_row)0,6:F_glyph_row=5'b11110; 1,2,3,4,5:F_glyph_row=5'b10001; endcase
                "E":case(F_row)0,3,6:F_glyph_row=5'b11111; 1,2,4,5:F_glyph_row=5'b10000; endcase
                "F":case(F_row)0,3:F_glyph_row=5'b11111; 1,2,4,5,6:F_glyph_row=5'b10000; endcase
                "G":case(F_row)0,6:F_glyph_row=5'b01111; 1,2:F_glyph_row=5'b10000; 3:F_glyph_row=5'b10111; 4,5:F_glyph_row=5'b10001; endcase
                "H":case(F_row)0,1,2,4,5,6:F_glyph_row=5'b10001; 3:F_glyph_row=5'b11111; endcase
                "I":case(F_row)0,6:F_glyph_row=5'b01110; 1,2,3,4,5:F_glyph_row=5'b00100; endcase
                "K":case(F_row)0,1,5,6:F_glyph_row=5'b10001; 2:F_glyph_row=5'b10010; 3:F_glyph_row=5'b11100; 4:F_glyph_row=5'b10010; endcase
                "L":case(F_row)0,1,2,3,4,5:F_glyph_row=5'b10000; 6:F_glyph_row=5'b11111; endcase
                "M":case(F_row)0,3,4,5,6:F_glyph_row=5'b10001; 1:F_glyph_row=5'b11011; 2:F_glyph_row=5'b10101; endcase
                "N":case(F_row)0,6:F_glyph_row=5'b10001; 1:F_glyph_row=5'b11001; 2:F_glyph_row=5'b10101; 3:F_glyph_row=5'b10011; 4,5:F_glyph_row=5'b10001; endcase
                "O":case(F_row)0,6:F_glyph_row=5'b01110; 1,2,3,4,5:F_glyph_row=5'b10001; endcase
                "P":case(F_row)0,3:F_glyph_row=5'b11110; 1,2:F_glyph_row=5'b10001; 4,5,6:F_glyph_row=5'b10000; endcase
                "R":case(F_row)0,3:F_glyph_row=5'b11110; 1,2:F_glyph_row=5'b10001; 4:F_glyph_row=5'b10100; 5:F_glyph_row=5'b10010; 6:F_glyph_row=5'b10001; endcase
                "S":case(F_row)0,3,6:F_glyph_row=5'b01111; 1,2:F_glyph_row=5'b10000; 4,5:F_glyph_row=5'b00001; endcase
                "T":case(F_row)0:F_glyph_row=5'b11111; 1,2,3,4,5,6:F_glyph_row=5'b00100; endcase
                "U":case(F_row)0,1,2,3,4,5:F_glyph_row=5'b10001; 6:F_glyph_row=5'b01110; endcase
                "W":case(F_row)0,1,2,3:F_glyph_row=5'b10001; 4:F_glyph_row=5'b10101; 5:F_glyph_row=5'b11011; 6:F_glyph_row=5'b10001; endcase
                "X":case(F_row)0,6:F_glyph_row=5'b10001; 1,5:F_glyph_row=5'b01010; 2,3,4:F_glyph_row=5'b00100; endcase
                "Y":case(F_row)0:F_glyph_row=5'b10001; 1:F_glyph_row=5'b01010; 2,3,4,5,6:F_glyph_row=5'b00100; endcase
                "=":case(F_row)2,4:F_glyph_row=5'b11111; endcase
                ":":case(F_row)1,5:F_glyph_row=5'b00100; endcase
                "-":case(F_row)3:F_glyph_row=5'b01110; endcase
                "/":case(F_row)0:F_glyph_row=5'b00001; 1:F_glyph_row=5'b00010; 2:F_glyph_row=5'b00100; 3:F_glyph_row=5'b01000; 4,5,6:F_glyph_row=5'b10000; endcase
                default:F_glyph_row=5'b00000;
            endcase
        end
    endfunction

    reg [7:0] S_char;
    reg [4:0] S_row_bits;
    always @* begin
        S_char = F_char(S_line, S_col);
        S_row_bits = F_glyph_row(S_char, S_glyph_y);
        O_text = S_glyph_window && S_row_bits[4 - S_glyph_x];
    end
endmodule

// Frame age in input-frame periods, measured at the DDR read-bank selection.
module frame_latency_monitor (
    input wire I_clk, I_rst_n,
    input wire I_store_start,
    input wire [1:0] I_store_slot,
    input wire I_read_start,
    input wire [1:0] I_read_slot,
    output reg O_valid,
    output reg [7:0] O_frames
);
    reg [15:0] frame_seq;
    reg [15:0] bank_seq [0:3];
    reg [3:0] bank_valid;
    reg [3:0] reads_without_store;
    wire [15:0] elapsed = frame_seq + {15'd0, I_store_start} - bank_seq[I_read_slot];

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            frame_seq <= 0;
            bank_valid <= 0;
            O_valid <= 0;
            O_frames <= 0;
            reads_without_store <= 0;
        end else begin
            if (I_store_start) begin
                frame_seq <= frame_seq + 1'b1;
                bank_seq[I_store_slot] <= frame_seq + 1'b1;
                bank_valid[I_store_slot] <= 1'b1;
                reads_without_store <= 0;
            end else if (I_read_start && reads_without_store < 4'd8) begin
                reads_without_store <= reads_without_store + 1'b1;
                if (reads_without_store == 4'd7)
                    bank_valid <= 0;
            end
            if (I_read_start) begin
                O_valid <= bank_valid[I_read_slot] &&
                           (reads_without_store < 4'd7 || I_store_start) &&
                           !(I_store_start && I_store_slot == I_read_slot);
                O_frames <= elapsed > 16'd99 ? 8'd99 : elapsed[7:0];
            end
        end
    end
endmodule

// White/light-background OPEN-PALM detector for the PH1P35 camera clock domain.
// It observes one RGB888 pixel from each four-pixel ISP beat and every fourth
// source line: 1280x720 -> 320x180.  The display stream is never back-pressured.
module light_hand_detector #(
    // Background collection is user-triggered after manual exposure is set.
    // This is deliberately independent of the OPEN_PALM/NOT_OPEN_PALM thresholds.
    parameter integer INIT_FRAMES       = 32,
    parameter integer DIFF_THRESHOLD    = 6,   // 6-bit grayscale delta
    parameter integer MIN_AREA           = 120, // 320x180 pixels
    parameter integer MAX_AREA           = 35712
) (
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire        I_frame_start,
    input  wire        I_line_last,
    input  wire        I_pixel_valid,
    input  wire [23:0] I_rgb,
    // A stable toggle already synchronized into I_clk.  Each transition
    // requests exactly one new background acquisition.
    input  wire        I_bg_capture_toggle,

    output reg         O_background_ready,
    output reg [5:0]   O_bg_frame_count,
    // 0=BG_WAIT, 1=BG_INIT, 2=READY. Exported solely for stable OSD.
    output reg [1:0]   O_bg_state,
    output reg         O_hand_valid,
    // O_hand_valid remains the strict OPEN_PALM diagnostic.  Locking is a
    // separate state so a fist or digit pose cannot be mislabeled OPEN.
    output reg         O_lock_valid,
    output reg [1:0]   O_track_state,
    output reg [3:0]   O_confirm_count,
    output reg [3:0]   O_lost_count,
    output reg         O_candidate_valid,
    output reg [8:0]   O_bbox_xmin,
    output reg [8:0]   O_bbox_xmax,
    output reg [7:0]   O_bbox_ymin,
    output reg [7:0]   O_bbox_ymax,
    output reg         O_wrist_valid,
    output reg [7:0]   O_wrist_y,
    output reg [3:0]   O_finger_max_runs,
    output reg [16:0]  O_foreground_area,
    output reg [3:0]   O_fail_code,
    output reg         O_area_ok,
    output reg         O_aspect_ok,
    output reg         O_fill_ok,
    output reg         O_segment_ok,
    output reg         O_result_toggle,
    // Stable digit gesture.  The four-bit transport can represent 0..9;
    // 4'hf is the internal UNKNOWN sentinel and is never published valid.
    // Validity is carried separately, so digit 0 is a legal published value.
    output reg         O_gesture_valid,
    output reg [3:0]   O_gesture_code,
    // Frame-local gesture evidence exported only for compact OSD debugging.
    output reg [3:0]   O_gesture_candidate_code,
    output reg [7:0]   O_gesture_best_streak_2,
    output reg [7:0]   O_gesture_best_streak_3,
    output reg [7:0]   O_gesture_best_streak_4,
    output reg [7:0]   O_gesture_best_streak_5,
    output reg [7:0]   O_gesture_narrow_best,

    // Write side of the debug-only 320x180 foreground-mask RAM.  This is a
    // registered stream tap and has no feedback into detector decisions.
    output wire        O_fg_mask_wr_en,
    output wire [15:0] O_fg_mask_wr_addr,
    output wire        O_fg_mask_wr_data
);
    localparam integer ANALYSIS_W = 320;
    localparam integer ANALYSIS_H = 180;
    // Projection scans select a coherent foreground region before classifying.
    localparam [5:0] SCAN_IDLE = 6'd0,
                     SCAN_BOUNDS_Y = 5'd1,
                     SCAN_BOUNDS_X = 5'd2,
                     SCAN_PALM = 5'd3,
                     SCAN_NECK = 5'd4,
                     SCAN_AREA = 5'd5,
                     SCAN_CLASSIFY_PREP = 5'd6,
                     SCAN_CLASSIFY_EVAL = 5'd7,
                     SCAN_CLASSIFY_COMMIT = 5'd8,
                     // Split the neck-width comparison across two clocks.
                     SCAN_NECK_EVAL = 5'd9,
                     // Gesture statistics run in their own registered scan
                     // pass so they do not extend the neck/area critical path.
                      SCAN_GESTURE = 5'd10,
                      SCAN_GESTURE_EVAL = 5'd11,
                      // Keep thumb evidence in a second, registered mid-palm
                      // pass.  It must not share a pixel-path or finger-count
                      // enable with the upper-finger scan.
                      SCAN_THUMB = 5'd12,
                      SCAN_THUMB_EVAL = 5'd13,
                      // A final low-rate contour pass derives directional
                      // extrema/defect-like evidence for digits 6..9.
                      SCAN_SHAPE = 5'd14,
                      SCAN_SHAPE_EVAL = 5'd15,
                      // The hull engine is wholly post-frame.  It uses a
                      // compact boundary-point store and one time-shared
                      // signed multiplier for convex-defect measurements.
                      SCAN_CONTOUR_PREP = 5'd16,
                      SCAN_CONTOUR_EXTRACT = 5'd17,
                      SCAN_HULL_START = 5'd18,
                      SCAN_HULL_FIND_START = 5'd19,
                      SCAN_HULL_BEGIN_EDGE = 5'd20,
                      SCAN_HULL_SCAN_NEXT = 5'd21,
                      SCAN_HULL_COMPLETE_EDGE = 5'd22,
                      SCAN_DEFECT_PREP = 5'd23,
                      SCAN_DEFECT_POINT_LOAD = 5'd24,
                      SCAN_DEFECT_CROSS_A = 5'd25,
                      SCAN_DEFECT_CROSS_B = 5'd26,
                      SCAN_DEFECT_DOT_A = 5'd27,
                      SCAN_DEFECT_DOT_B = 5'd28,
                      SCAN_DEFECT_LEN_A = 5'd29,
                      SCAN_DEFECT_LEN_B = 5'd30,
                      SCAN_DEFECT_THRESHOLD = 5'd31,
                      SCAN_DEFECT_EVAL = 6'd32,
                      SCAN_DEFECT_EDGE_COMMIT = 6'd33,
                      SCAN_HULL_FEATURE_PREP = 6'd34,
                      SCAN_HULL_FEATURE = 6'd35,
                      SCAN_HULL_CROSS_A = 6'd36,
                      SCAN_HULL_CROSS_B = 6'd37,
                      // Jarvis candidate selection is deliberately pipelined:
                      // capture distance/cross flags, decide, then commit.
                      SCAN_HULL_DECIDE = 6'd38,
                      SCAN_HULL_COMMIT_CANDIDATE = 6'd39,
                      // A separate registered row scan verifies that a first
                      // interior background gap is a closed hand hole, rather
                      // than an open finger valley.
                      SCAN_HOLE = 6'd40,
                      SCAN_HOLE_EVAL = 6'd41,
                      // Capture a contour point before comparing it to the
                      // cached Jarvis start vertex.  This keeps the dynamic
                      // contour-array read out of the start-index CE path.
                      SCAN_HULL_FIND_START_EVAL = 6'd42;
    localparam [8:0] ROW_ACTIVITY_MIN = 9'd8;
    localparam [7:0] MIN_COHERENT_ROWS = 8'd4;
    localparam [8:0] MIN_COHERENT_COLS = 9'd8;
    localparam [7:0] COLUMN_ACTIVITY_MIN = 8'd5;

    localparam [3:0] FAIL_NONE   = 4'd0,
                     FAIL_NO_FG  = 4'd1,
                     FAIL_AREA   = 4'd2,
                     FAIL_ASPECT = 4'd3,
                     FAIL_FILL   = 4'd4,
                     FAIL_SEG    = 4'd5,
                     FAIL_WRIST  = 4'd6,
                     FAIL_OTHER  = 4'd7;
    localparam [3:0] GESTURE_0    = 4'd0,
                      GESTURE_1    = 4'd1,
                     GESTURE_2    = 4'd2,
                     GESTURE_3    = 4'd3,
                     GESTURE_4    = 4'd4,
                     GESTURE_5    = 4'd5,
                     GESTURE_6    = 4'd6,
                     GESTURE_7    = 4'd7,
                     GESTURE_8    = 4'd8,
                      GESTURE_9    = 4'd9,
                     GESTURE_NONE = 4'd15;
    // Frame-to-frame hysteresis: switch OPEN_PALM/NOT_OPEN_PALM only after three
    // consecutive raw classifier results agree. This suppresses flicker from
    // borderline shapes without changing any geometric classifier threshold.
    localparam [1:0] HAND_CONFIRM_FRAMES = 2'd3;
    // Phase 1 targets a clearly spread palm, not an arbitrary hand pose.
    // Count separated foreground runs only in the upper 64% of the candidate,
    // where spread fingers should be visible. Require at least four runs in
    // one row and a three-row streak; a fist or round cup normally fails this.
    localparam [3:0] OPEN_PALM_MIN_RUNS = 4'd4;
    localparam [7:0] OPEN_PALM_MIN_RUN_STREAK = 8'd3;

    // Lock state changes once per completed analysis frame, never in the
    // pixel path.  Keep these values centralized for field tuning.
    localparam [1:0] TRACK_SEARCH  = 2'd0,
                     TRACK_CONFIRM = 2'd1,
                     TRACK_LOCKED  = 2'd2,
                     TRACK_LOST    = 2'd3;
    localparam [3:0] LOCK_CONFIRM_FRAMES = 4'd8;
    localparam [3:0] LOCK_LOST_FRAMES    = 4'd12;
    // A run count must persist over multiple adjacent analysis rows. One
    // finger additionally needs a tall, narrow upper silhouette so a fist
    // is less likely to be mislabeled as digit 1.
    // Exact row-run counts suppress the old >=k ambiguity (one row with
    // five segments must not simultaneously count as 2, 3, 4 and 5 fingers).
    // Five fingers can occupy a shorter horizontal band because fingertips
    // are not perfectly level, so its exact-run persistence threshold is 2.
    // A two-run row is particularly easy to create from one finger plus a
    // small foreground fragment.  Require one extra adjacent row before it
    // can override a sustained narrow single-finger stem.
    localparam [7:0] GESTURE_RUN_STREAK_MIN_2 = 8'd4;
    localparam [7:0] GESTURE_RUN_STREAK_MIN_3 = 8'd3;
    localparam [7:0] GESTURE_RUN_STREAK_MIN_4 = 8'd3;
    localparam [7:0] GESTURE_RUN_STREAK_MIN_5 = 8'd2;
    localparam [7:0] GESTURE_ONE_NARROW_MIN = 8'd7;
    // A side extension must persist through three mid-palm rows.  A one-row
    // edge wobble is deliberately treated as ambiguous rather than as a thumb.
    localparam [7:0] GESTURE_THUMB_SIDE_STREAK_MIN = 8'd3;
    localparam [7:0] GESTURE_SHAPE_STREAK_MIN = 8'd3;
    localparam [7:0] GESTURE_BEND_STREAK_MIN = 8'd2;
    localparam [1:0] GESTURE_CONFIRM_FRAMES = 2'd3;
    localparam [2:0] GESTURE_UNKNOWN_CLEAR_FRAMES = 3'd4;
    localparam [8:0] TRACK_X_MARGIN      = 9'd24;
    localparam [7:0] TRACK_Y_MARGIN      = 8'd16;

    // 320*180*6 = 345600 bits.  This is the only frame-sized storage.  The
    // directive below is the TD/Anlogic ERAM-inference form already used by
    // the generated FIFO IP in this project.  Crucially, this memory is only
    // read from a clocked process below: there is no asynchronous array read.
    // TD can therefore implement it as synchronous simple dual-port ERAM.
    reg [5:0] S_background [0:57599];  /* fehdl force_ram=1, ram_style="bram_fast" */
    (* ram_style = "block" *) reg [7:0] S_col_count [0:319];
    (* ram_style = "block" *) reg [8:0] S_row_width [0:179];
    (* ram_style = "block" *) reg [3:0] S_row_runs [0:179];
    // Per-row foreground edges are compact geometry statistics (180 x 9b
    // each), used only after lock to distinguish a side thumb from four
    // upright fingers.  They are not an additional frame buffer.
    (* ram_style = "block" *) reg [8:0] S_row_xmin [0:179];
    (* ram_style = "block" *) reg [8:0] S_row_xmax [0:179];
    // First interior background gap on each analysis row.  This is only two
    // extra boundary coordinates per row, not a second mask/frame buffer;
    // it preserves the index/middle valley needed by hull-defect analysis.
    reg [8:0] S_row_gap_left [0:179];
    reg [8:0] S_row_gap_right [0:179];
    reg       S_row_gap_valid [0:179];

    reg [8:0] S_src_x;
    reg [9:0] S_src_y;
    // Background RAM read pipeline.  d1 registers the address and pixel
    // metadata; d2 is kept in lockstep with the synchronous RAM output.
    reg [15:0] S_bg_addr_q;
    reg [15:0] S_bg_addr_d2;
    reg [5:0]  S_bg_value_q;
    reg [5:0]  S_gray_d1, S_gray_d2;
    reg        S_sample_d1, S_sample_d2;
    reg        S_background_ready_d1, S_background_ready_d2;
    reg        S_bg_learn_d1, S_bg_learn_d2;
    reg [8:0]  S_sample_x_d1, S_sample_x_d2;
    reg [7:0]  S_sample_y_d1, S_sample_y_d2;
    // This register stage deliberately isolates ERAM/difference logic from
    // the high-fanout row/area/bbox enables.  Metadata is kept in lockstep.
    reg        S_sample_d3, S_fg_d3;
    reg [8:0]  S_sample_x_d3;
    reg [7:0]  S_sample_y_d3;
    reg [15:0] S_fg_addr_d3;
    // 0/9 template matcher diagnostics.  Scores remain local for signal-tap
    // or waveform observation; only its registered high-confidence decision
    // participates in the 0/9 classifier fusion below.
    // These five signals were waveform-only diagnostics.  They are not read
    // by the detector's decision path or by the unified top level, so do not
    // keep them through synthesis.
    wire        S_template_busy;
    wire [10:0] S_template_score_0_num;
    wire [10:0] S_template_score_0_den;
    wire [10:0] S_template_score_9_num;
    wire [10:0] S_template_score_9_den;
    // These three signals are consumed below by the 0/9 fusion logic.  No
    // keep attribute is required; removing it permits ordinary net sharing
    // while retaining exactly the same decision inputs and state updates.
    wire        S_template_decision_valid;
    wire [3:0]  S_template_decision_code;
    wire        S_template_result_toggle;
    // Capture each completed template decision once.  The result belongs to
    // the same registered foreground/ROI stream as the detector; the latch
    // prevents a live matcher update from feeding the gesture stability path
    // combinationally.
    reg       S_template_result_seen;
    reg       S_template_decision_valid_q;
    reg [3:0] S_template_decision_code_q;
    // A completed matcher result is a single-use event.  It is consumed by
    // one scanner classification commit and cannot override later frames.
    reg       S_template_result_pending;
    reg       S_bg_capture_seen;
    reg       S_bg_capture_pending;
    reg [5:0] S_init_frames;
    reg       S_previous_fg;
    reg       S_stat_row_seen;
    reg [7:0] S_last_stat_row;
    reg [16:0] S_area;
    reg [8:0] S_xmin, S_xmax;
    reg [7:0] S_ymin, S_ymax;
    reg       S_frame_done_toggle;

    // Frame-wide raw statistics are written only by the pixel-stream process.
    // The scanner must never overwrite them; its selected coherent bounds live
    // in a separate register bank to avoid multiple procedural drivers.
    reg [16:0] S_raw_area;
    reg [8:0] S_raw_xmin, S_raw_xmax;
    reg [7:0] S_raw_ymin, S_raw_ymax;
    reg [8:0] S_candidate_xmin, S_candidate_xmax;
    reg [7:0] S_candidate_ymin, S_candidate_ymax;
    // These geometry values are captured when the coherent candidate is
    // completed.  Keeping them registered prevents a candidate-coordinate
    // subtraction from feeding row-RAM clamping, a DSP multiply and the
    // wrist/segment enables in the same camera-clock cycle.
    reg [8:0] S_candidate_width;
    reg [7:0] S_candidate_height;
    reg [8:0] S_palm_search_start_y_q, S_palm_search_end_y_q;
    reg [8:0] S_gesture_scan_end_y_q;
    reg       S_scan_seen_toggle;
    reg [5:0] S_scan_state;
    reg [7:0] S_scan_row;
    reg [8:0] S_scan_col;
    reg [7:0] S_y_streak, S_y_best_streak;
    reg [7:0] S_y_streak_start, S_y_best_start, S_y_best_end;
    reg [8:0] S_x_streak, S_x_best_streak;
    reg [8:0] S_x_streak_start, S_x_best_start, S_x_best_end;
    reg [8:0] S_palm_width;
    reg [7:0] S_palm_y;
    reg [3:0] S_scan_max_runs;
    reg [7:0] S_open_run_streak, S_open_run_best;
    reg [7:0] S_narrow_streak;
    reg       S_scan_wrist_valid;
    reg [7:0] S_scan_wrist_y, S_neck_candidate_y;
    reg       S_neck_candidate_valid;
    reg [7:0] S_hand_ymax;
    reg [7:0] S_hand_height;
    reg [16:0] S_hand_area;

    // Digit heuristics are evaluated in a dedicated two-stage row scan.
    // For each threshold k=2..5, track the longest run of adjacent rows
    // whose horizontal foreground segment count is at least k. Digit 1
    // additionally requires a sustained narrow single-run finger stem.
    reg [3:0] S_gesture_row_runs_q;
    reg [8:0] S_gesture_row_width_q;
    reg [7:0] S_gesture_scan_row_q;
    reg [7:0] S_gesture_run_streak_2, S_gesture_run_streak_3;
    reg [7:0] S_gesture_run_streak_4, S_gesture_run_streak_5;
    reg [7:0] S_gesture_best_streak_2, S_gesture_best_streak_3;
    reg [7:0] S_gesture_best_streak_4, S_gesture_best_streak_5;
    reg [7:0] S_gesture_narrow_streak, S_gesture_narrow_best;
    // Row coordinates of the strongest narrow single-stem run.  This uses
    // existing row statistics and gives digit 9 a full-resolution length
    // measurement without relying only on the decimated hull boundary.
    reg [7:0] S_gesture_narrow_start_y, S_gesture_narrow_best_start_y;
    reg [8:0] S_gesture_row_span_q;
    // Four upright fingers establish an orientation-independent upper envelope.
    // The subsequent mid-palm scan accepts either left or right extension, so
    // mirrored camera feeds and either hand use the same test.
    reg       S_gesture_four_envelope_valid;
    reg [8:0] S_gesture_four_xmin, S_gesture_four_xmax;
    reg [3:0] S_thumb_row_runs_q;
    reg [8:0] S_thumb_row_width_q, S_thumb_row_span_q;
    reg [8:0] S_thumb_row_xmin_q, S_thumb_row_xmax_q;
    reg [7:0] S_thumb_scan_row_q;
    reg [7:0] S_thumb_side_streak, S_thumb_side_best;
    reg [7:0] S_thumb_valley_streak, S_thumb_valley_best;
    // Directional, convex-hull-like summary.  All values are scan registers;
    // no contour-point RAM or per-pixel feedback is introduced.
    reg [8:0] S_palm_xmin, S_palm_xmax, S_palm_center_x;
    reg [3:0] S_shape_row_runs_q;
    reg [8:0] S_shape_row_width_q, S_shape_row_span_q;
    reg [8:0] S_shape_row_xmin_q, S_shape_row_xmax_q;
    reg [7:0] S_shape_scan_row_q;
    reg [7:0] S_shape_left_streak, S_shape_left_best;
    reg [7:0] S_shape_right_streak, S_shape_right_best;
    reg [7:0] S_shape_notch_streak, S_shape_notch_best;
    reg [7:0] S_shape_l_streak, S_shape_l_best;
    reg [7:0] S_shape_hook_streak, S_shape_hook_best;
    reg       S_shape_top_narrow_seen, S_shape_tip_compact_seen;
    reg [8:0] S_shape_top_xmin, S_shape_top_xmax;
    // Three samples of the same narrow single-finger stem.  They are collected
    // in the post-frame shape scan, never in the video pixel path.
    reg       S_shape_finger_top_seen, S_shape_finger_mid_seen;
    reg       S_shape_finger_bottom_seen;
    reg [8:0] S_shape_finger_top_x, S_shape_finger_mid_x;
    reg [8:0] S_shape_finger_bottom_x;
    // Hole candidate state.  The scanner reuses the existing per-row first
    // interior-gap cache; it does not add a frame buffer or flood fill.
    reg [3:0] S_hole_row_runs_q;
    reg       S_hole_gap_valid_q;
    reg [8:0] S_hole_gap_left_q, S_hole_gap_right_q;
    reg [8:0] S_hole_row_xmin_q, S_hole_row_xmax_q;
    reg [7:0] S_hole_scan_row_q;
    reg       S_hole_active, S_hole_open_from_boundary, S_hole_closed;
    reg [8:0] S_hole_track_left, S_hole_track_right;
    reg [7:0] S_hole_track_height;
    reg [16:0] S_hole_track_area;
    // Up to four points per eighth selected hand row give at most 92 boundary
    // samples for the 180-line analysis image: outer xmin/xmax plus the first
    // interior gap's two edges. They are actual foreground/background
    // boundary pixels, rather than another 320x180 image store. Jarvis tie
    // handling removes collinear samples from the final hull.
    localparam integer CONTOUR_POINT_MAX = 128;
    // Keep a little margin for camera-mask stair steps while retaining a
    // finite bound on the Jarvis loop and defect pass.
    localparam integer HULL_VERTEX_MAX = 24;
    // Random access needs several read addresses during Jarvis/defect scans;
    // leave this compact store unconstrained so TD may map it to LUT RAM or
    // registers instead of forcing an invalid multi-read ERAM inference.
    reg [8:0] S_contour_x [0:CONTOUR_POINT_MAX-1];
    reg [7:0] S_contour_y [0:CONTOUR_POINT_MAX-1];
    reg [7:0] S_contour_point_count;
    reg       S_contour_overflow;
    reg [8:0] S_hull_x [0:HULL_VERTEX_MAX-1];
    reg [7:0] S_hull_y [0:HULL_VERTEX_MAX-1];
    reg [7:0] S_hull_point_index, S_hull_start_index;
    reg [7:0] S_hull_current_index, S_hull_candidate_index;
    // Start-search operands are captured separately from the comparison.
    // The incumbent coordinates avoid rereading the contour array through
    // S_hull_start_index for every point in the start search.
    reg [8:0] S_hull_start_x_q, S_hull_find_point_x_q;
    reg [7:0] S_hull_start_y_q, S_hull_find_point_y_q;
    // Cache the two endpoint coordinates for one Jarvis edge.  Keeping the
    // candidate coordinate locally prevents S_hull_candidate_index from
    // repeatedly driving the contour-store address muxes during every tested
    // point, reducing its fanout and associated routing delay.
    reg [8:0] S_hull_current_x_q, S_hull_candidate_x_q;
    reg [7:0] S_hull_current_y_q, S_hull_candidate_y_q;
    reg [4:0] S_hull_vertex_count;
    reg       S_hull_overflow, S_hull_valid;
    reg signed [10:0] S_hull_ab_x, S_hull_ab_y;
    reg signed [10:0] S_hull_ap_x, S_hull_ap_y;
    reg signed [21:0] S_hull_cross_a;
    // Registered Jarvis tie-break data.  These isolate the absolute-value and
    // Manhattan-add network from the comparator and candidate-index mux.
    reg [11:0] S_hull_candidate_manhattan_q, S_hull_point_manhattan_q;
    reg        S_hull_cross_negative_q, S_hull_cross_zero_q;
    reg        S_hull_replace_q;
    // Defect engine registers.  Products are serialized through
    // S_geom_mul_*; no parallel cross-product bank is created.
    reg [4:0] S_defect_edge_index;
    reg [7:0] S_defect_point_index;
    reg signed [10:0] S_defect_ab_x, S_defect_ab_y;
    reg signed [10:0] S_defect_ap_x, S_defect_ap_y;
    reg signed [21:0] S_defect_cross_a, S_defect_cross_b;
    reg signed [21:0] S_defect_dot_a, S_defect_dot_b;
    reg signed [21:0] S_defect_len_a, S_defect_len_b;
    reg signed [10:0] S_geom_mul_a, S_geom_mul_b;
    reg [21:0] S_defect_threshold_q, S_defect_best_cross, S_defect_max_cross;
    reg [8:0] S_defect_best_x, S_defect_deepest_x;
    reg [7:0] S_defect_best_y, S_defect_deepest_y;
    reg [3:0] S_defect_count;
    // Compact hull summaries, accumulated only after a complete valid hull.
    reg [4:0] S_hull_feature_index;
    reg [3:0] S_hull_upper_count, S_hull_left_count, S_hull_right_count;
    // The highest hull point in the central upper-finger zone is retained for
    // the 1/9 length test.  It is deliberately separate from the side-thumb
    // summaries, so a lateral thumb cannot become an index fingertip.
    reg       S_hull_top_seen;
    reg [7:0] S_hull_top_y;
    // Digit 9 can end below the strict upper-finger zone used by digit 1.
    // Retain a second central-above-palm extremum solely for its shorter
    // extension measurement; it never feeds the 6/7/8 geometry rules.
    reg       S_hull_center_top_seen;
    reg [7:0] S_hull_center_top_y;
    reg [3:0] S_class_gesture_code;
    reg [3:0] S_gesture_pending_code;
    reg [1:0] S_gesture_pending_streak;
    reg [2:0] S_gesture_unknown_streak;

    // Timing pipeline for SCAN_NECK.  The row RAM read, clamp mux and
    // width*100 arithmetic are captured in SCAN_NECK; the next state evaluates
    // the comparison.  Keep the scan-row tag beside the value to preserve
    // exact row alignment.
    reg [15:0] S_area_row_width_x100_q;
    reg [7:0]  S_neck_scan_row_q;

    // Frame-statistics snapshot and predicate pipeline.  The predicates use
    // explicit full-width products to preserve the intended geometric ratios.
    reg [16:0] S_class_hand_area;
    reg [8:0]  S_class_raw_width;
    reg [7:0]  S_class_hand_height;
    reg [17:0] S_class_hand_bbox_area;
    reg [8:0]  S_class_raw_xmin, S_class_raw_xmax;
    reg [7:0]  S_class_raw_ymin, S_class_hand_ymax;
    reg        S_class_wrist_valid;
    reg [7:0]  S_class_wrist_y;
    reg [3:0]  S_class_scan_max_runs;
    reg [7:0]  S_class_open_run_best;
    reg        S_class_area_ok;
    reg        S_class_aspect_low_ok, S_class_aspect_high_ok;
    reg        S_class_fill_low_ok, S_class_fill_high_ok;
    reg        S_class_runs_ok, S_class_run_streak_ok;
    reg        S_class_candidate_density_ok;
    reg [1:0]  S_hand_positive_streak;
    reg [1:0]  S_hand_negative_streak;
    // Lock reference is updated only after a locally continuous candidate.
    reg [8:0]  S_lock_xmin, S_lock_xmax;
    reg [7:0]  S_lock_ymin, S_lock_ymax;
    reg [16:0] S_lock_area;
    // Preserve the width of the original, confirmed open palm. Do not update
    // it while fingers fold/unfold; it provides a stable scale for digit cues.
    reg [8:0]  S_open_palm_width_ref;

    wire [7:0] S_r = I_rgb[23:16];
    wire [7:0] S_g = I_rgb[15:8];
    wire [7:0] S_b = I_rgb[7:0];
    wire [9:0] S_gray_sum = {2'd0, S_r} + {1'd0, S_g, 1'b0} + {2'd0, S_b};
    wire [5:0] S_gray = S_gray_sum[9:4];
    wire [7:0] S_analysis_y = S_src_y[9:2];
    // 320 = 256 + 64; spell out the address arithmetic to avoid a generic
    // multiplier in the camera pixel path.
    wire [15:0] S_bg_addr = ({8'd0, S_analysis_y} << 8) +
                           ({8'd0, S_analysis_y} << 6) + {7'd0, S_src_x};
    wire S_sample_now = I_pixel_valid && !I_frame_start && !S_src_y[1:0] &&
                        (S_analysis_y < ANALYSIS_H) && (S_src_x < ANALYSIS_W);
    // The first learning frame establishes every RAM location directly.  All
    // later learning frames update the same single background image through a
    // registered read-modify-write path; no extra frame storage is required.
    wire S_bg_first_frame_write = (O_bg_state == 2'd1) && !O_background_ready &&
                                  ((S_init_frames == 6'd0 && I_frame_start) ||
                                   (S_init_frames == 6'd1 && S_sample_now && !I_frame_start));
    wire [15:0] S_bg_first_frame_addr = I_frame_start ? 16'd0 : S_bg_addr;
    wire [6:0] S_diff = (S_gray_d2 >= S_bg_value_q) ?
                        (S_gray_d2 - S_bg_value_q) : (S_bg_value_q - S_gray_d2);
    wire S_fg = S_sample_d2 && S_background_ready_d2 && (S_diff > DIFF_THRESHOLD);
    // Explicitly widen operands BEFORE multiplication so the full product is
    // preserved by Verilog expression sizing.  Both dimensions are scanner
    // registers, not live coordinate arithmetic.
    wire [17:0] S_hand_bbox_area = {9'd0, S_candidate_width} *
                                   {10'd0, S_hand_height};
    wire [15:0] S_candidate_height_x41 = ({8'd0, S_candidate_height} << 5) +
                                         ({8'd0, S_candidate_height} << 3) +
                                         {8'd0, S_candidate_height};
    // 41/64 ~= 64.06%, with enough width for the full 180-row range.
    wire [7:0] S_palm_search_offset = S_candidate_height_x41[13:6];
    // Gesture evidence is restricted to the upper 3/8 of the silhouette.
    // The old 64% OPEN_PALM window also included palm and wrist rows, which
    // could manufacture a false two-run streak for a single raised finger.
    wire [9:0] S_candidate_height_x3 = ({2'd0, S_candidate_height} << 1) +
                                        {2'd0, S_candidate_height};
    wire [7:0] S_gesture_scan_offset = S_candidate_height_x3[9:3];
    // Longest consecutive active-row/column runs reject isolated noise pixels.
    wire S_row_y_active = (S_row_width[S_scan_row] >= ROW_ACTIVITY_MIN);
    wire [7:0] S_y_streak_next = S_row_y_active ? (S_y_streak + 8'd1) : 8'd0;
    wire [7:0] S_y_streak_start_next = (S_y_streak == 8'd0) ? S_scan_row : S_y_streak_start;
    wire S_y_use_current = S_row_y_active && (S_y_streak_next > S_y_best_streak);
    wire [7:0] S_y_final_best_streak = S_y_use_current ? S_y_streak_next : S_y_best_streak;
    wire [7:0] S_y_final_start = S_y_use_current ? S_y_streak_start_next : S_y_best_start;
    wire [7:0] S_y_final_end = S_y_use_current ? S_scan_row : S_y_best_end;

    wire S_col_x_active = (S_col_count[S_scan_col] >= COLUMN_ACTIVITY_MIN);
    wire [8:0] S_x_streak_next = S_col_x_active ? (S_x_streak + 9'd1) : 9'd0;
    wire [8:0] S_x_streak_start_next = (S_x_streak == 9'd0) ? S_scan_col : S_x_streak_start;
    wire S_x_use_current = S_col_x_active && (S_x_streak_next > S_x_best_streak);
    wire [8:0] S_x_final_best_streak = S_x_use_current ? S_x_streak_next : S_x_best_streak;
    wire [8:0] S_x_final_start = S_x_use_current ? S_x_streak_start_next : S_x_best_start;
    wire [8:0] S_x_final_end = S_x_use_current ? S_scan_col : S_x_best_end;

    // Clamp each row to the coherent horizontal candidate before using it in
    // palm/wrist measurements.  Declare it before the dependent product so
    // TD does not issue an HDL use-before-declaration warning.
    wire [8:0] S_area_row_width =
        (S_row_width[S_scan_row] > S_candidate_width) ? S_candidate_width : S_row_width[S_scan_row];
    wire [8:0] S_area_row_span =
        (S_row_xmax[S_scan_row] >= S_row_xmin[S_scan_row]) ?
        (S_row_xmax[S_scan_row] - S_row_xmin[S_scan_row] + 9'd1) : 9'd0;

    // All geometric ratios use explicitly wide cross-products.
    wire [15:0] S_area_row_width_x100 = {7'd0, S_area_row_width} * 16'd100;
    wire [15:0] S_palm_width_x72 = {7'd0, S_palm_width} * 16'd72;
    wire [15:0] S_palm_width_x62 = {7'd0, S_palm_width} * 16'd62;
    wire [15:0] S_class_width_x100 = {7'd0, S_class_raw_width} * 16'd100;
    wire [15:0] S_class_height_x28 = {8'd0, S_class_hand_height} * 16'd28;
    wire [15:0] S_class_height_x350 = {8'd0, S_class_hand_height} * 16'd350;
    wire [23:0] S_class_hand_area_x100 = {7'd0, S_class_hand_area} * 24'd100;
    wire [23:0] S_class_bbox_area_x24 = {6'd0, S_class_hand_bbox_area} * 24'd24;
    wire [23:0] S_class_bbox_area_x86 = {6'd0, S_class_hand_bbox_area} * 24'd86;
    wire [23:0] S_class_bbox_area_x8 = {6'd0, S_class_hand_bbox_area} * 24'd8;

    // LOCKED tracking deliberately reuses the completed projection scan.  It
    // requires a coherent candidate, box overlap with a bounded local margin,
    // and area within 1/4x..4x of the locked reference.  This accepts fingers
    // folding/unfolding without accepting an arbitrary foreground speck.
    wire S_raw_open_palm = S_class_area_ok && S_class_aspect_low_ok &&
                           S_class_aspect_high_ok && S_class_fill_low_ok &&
                           S_class_fill_high_ok && S_class_wrist_valid &&
                           S_class_runs_ok && S_class_run_streak_ok;
    wire S_track_candidate = S_class_area_ok && S_class_candidate_density_ok;
    wire [9:0] S_track_xmax_margin = {1'b0, S_class_raw_xmax} + {1'b0, TRACK_X_MARGIN};
    wire [9:0] S_lock_xmax_margin  = {1'b0, S_lock_xmax} + {1'b0, TRACK_X_MARGIN};
    wire [8:0] S_track_ymax_margin = {1'b0, S_class_hand_ymax} + {1'b0, TRACK_Y_MARGIN};
    wire [8:0] S_lock_ymax_margin  = {1'b0, S_lock_ymax} + {1'b0, TRACK_Y_MARGIN};
    wire S_track_position_ok = (S_track_xmax_margin >= {1'b0, S_lock_xmin}) &&
                               ({1'b0, S_class_raw_xmin} <= S_lock_xmax_margin) &&
                               (S_track_ymax_margin >= {1'b0, S_lock_ymin}) &&
                               ({1'b0, S_class_raw_ymin} <= S_lock_ymax_margin);
    wire [18:0] S_track_area_now_x4 = {2'd0, S_class_hand_area} << 2;
    wire [18:0] S_track_area_ref_x4 = {2'd0, S_lock_area} << 2;
    wire S_track_area_ok = (S_track_area_now_x4 >= {2'd0, S_lock_area}) &&
                           ({2'd0, S_class_hand_area} <= S_track_area_ref_x4);
    wire S_track_match = S_track_candidate && S_track_position_ok && S_track_area_ok;
    // Highest persistent run-count threshold wins. One-finger classification
    // is deliberately stricter because a closed fist can also produce one run.
    wire [8:0] S_gesture_ref_width =
        (S_open_palm_width_ref != 9'd0) ? S_open_palm_width_ref : S_candidate_width;
    // Ignore very short isolated row segments when counting multi-finger
    // gestures. A single finger is much narrower than the original open palm.
    wire [8:0] S_gesture_min_multi_width = S_gesture_ref_width >> 3;
    wire [8:0] S_gesture_one_width_max = S_gesture_ref_width >> 3;
    wire [8:0] S_gesture_one_region_end_y =
        {1'b0, S_candidate_ymin} + {1'b0, (S_candidate_height >> 1)};

    // Scan only the middle half of the hand for a lateral thumb.  The upper
    // quarter contains the upright fingertips and the lower quarter trends
    // into the wrist, so neither is a reliable thumb location.
    wire [8:0] S_thumb_scan_start_y = {1'b0, S_candidate_ymin} +
                                      ({1'b0, S_hand_height} >> 2);
    wire [8:0] S_thumb_scan_end_y = {1'b0, S_candidate_ymin} +
                                    ({1'b0, S_hand_height} >> 1) +
                                    ({1'b0, S_hand_height} >> 2);
    // Use dimensions relative to the retained open-palm width rather than an
    // absolute image direction or fixed pixel distance.
    wire [8:0] S_thumb_extension_min = (S_gesture_ref_width >> 4) + 9'd2;
    wire [8:0] S_thumb_opposite_tolerance = (S_gesture_ref_width >> 5) + 9'd1;
    wire [8:0] S_thumb_valley_min = (S_gesture_ref_width >> 5) + 9'd1;
    wire [8:0] S_thumb_row_gap_q = S_thumb_row_span_q - S_thumb_row_width_q;
    wire S_thumb_left_extended = S_gesture_four_envelope_valid &&
        ({1'b0, S_thumb_row_xmin_q} + {1'b0, S_thumb_extension_min} <=
         {1'b0, S_gesture_four_xmin}) &&
        ({1'b0, S_thumb_row_xmax_q} <=
         ({1'b0, S_gesture_four_xmax} + {1'b0, S_thumb_opposite_tolerance}));
    wire S_thumb_right_extended = S_gesture_four_envelope_valid &&
        ({1'b0, S_gesture_four_xmax} + {1'b0, S_thumb_extension_min} <=
         {1'b0, S_thumb_row_xmax_q}) &&
        ({1'b0, S_thumb_row_xmin_q} + {1'b0, S_thumb_opposite_tolerance} >=
         {1'b0, S_gesture_four_xmin});
    wire S_thumb_side_row = (S_thumb_row_width_q >= S_gesture_min_multi_width) &&
                            (S_thumb_left_extended || S_thumb_right_extended);
    // The valley is supporting evidence: it detects the notch between thumb
    // and index when the binary mask keeps it.  A clean five-run upper row is
    // an alternative corroborating cue because the valley can disappear when
    // the thumb touches the palm in the foreground mask.
    wire S_thumb_valley_row = S_thumb_side_row && (S_thumb_row_runs_q == 4'd2) &&
                              (S_thumb_row_gap_q >= S_thumb_valley_min);
    // The shape pass stops before the lower wrist quarter.  The palm row was
    // selected by the existing width scan, so its center is less sensitive to
    // raised fingers than the complete bbox center.
    wire [8:0] S_shape_scan_end_y = {1'b0, S_candidate_ymin} +
                                    ({1'b0, S_hand_height} >> 1) +
                                    ({1'b0, S_hand_height} >> 2);
    wire [8:0] S_shape_side_min = (S_gesture_ref_width >> 4) + 9'd2;
    wire [8:0] S_shape_side_max_width = S_gesture_ref_width -
                                         (S_gesture_ref_width >> 2);
    wire [8:0] S_shape_notch_min = (S_gesture_ref_width >> 5) + 9'd1;
    wire [8:0] S_shape_l_width_min = S_gesture_ref_width >> 1;
    wire [8:0] S_shape_hook_width_min = S_gesture_ref_width >> 2;
    wire [8:0] S_shape_row_gap_q = S_shape_row_span_q - S_shape_row_width_q;
    // A side support must leave the central half-width around the estimated
    // palm center.  This avoids treating a broad, connected palm row as two
    // outward fingertips while retaining left/right mirror symmetry.
    wire S_shape_left_out = ({1'b0, S_shape_row_xmin_q} +
                             {1'b0, (S_gesture_ref_width >> 2)} <=
                             {1'b0, S_palm_center_x});
    wire S_shape_right_out = ({1'b0, S_palm_center_x} +
                              {1'b0, (S_gesture_ref_width >> 2)} <=
                              {1'b0, S_shape_row_xmax_q});
    wire S_shape_side_row = (S_shape_row_width_q >= S_gesture_min_multi_width) &&
                            (S_shape_row_width_q <= S_shape_side_max_width) &&
                            (S_shape_left_out || S_shape_right_out);
    wire S_shape_notch_row = (S_shape_row_runs_q == 4'd2) &&
                             (S_shape_row_gap_q >= S_shape_notch_min);
    // Compare a later single-run contour with the first narrow upper stem.
    // Large one-sided growth is an L; smaller growth followed by a notch is
    // the conservative hook approximation for digit 9.
    wire S_shape_left_bend = S_shape_top_narrow_seen && (S_shape_row_runs_q == 4'd1) &&
        ({1'b0, S_shape_row_xmin_q} + {1'b0, S_shape_side_min} <= {1'b0, S_shape_top_xmin}) &&
        ({1'b0, S_shape_row_xmax_q} <= {1'b0, S_shape_top_xmax} + {1'b0, S_shape_side_min});
    wire S_shape_right_bend = S_shape_top_narrow_seen && (S_shape_row_runs_q == 4'd1) &&
        ({1'b0, S_shape_top_xmax} + {1'b0, S_shape_side_min} <= {1'b0, S_shape_row_xmax_q}) &&
        ({1'b0, S_shape_row_xmin_q} + {1'b0, S_shape_side_min} >= {1'b0, S_shape_top_xmin});
    wire S_shape_bend_row = S_shape_left_bend || S_shape_right_bend;
    wire [9:0] S_shape_top_center_x = ({1'b0, S_shape_top_xmin} +
                                       {1'b0, S_shape_top_xmax}) >> 1;
    wire [8:0] S_shape_center_tolerance = (S_gesture_ref_width >> 2) + 9'd1;
    wire S_shape_tip_centered = S_shape_top_narrow_seen &&
        ({1'b0, S_shape_top_center_x} + {1'b0, S_shape_center_tolerance} >=
         {1'b0, S_palm_center_x}) &&
        ({1'b0, S_palm_center_x} + {1'b0, S_shape_center_tolerance} >=
         {1'b0, S_shape_top_center_x});
    // The sustained narrow-run bounds come directly from the existing upper
    // scan.  Sampling that same run at top/middle/bottom avoids palm rows and
    // makes a uniform hand tilt cancel out in the centerline test.
    wire [8:0] S_shape_finger_end_y = (S_gesture_narrow_best != 8'd0) ?
        ({1'b0, S_gesture_narrow_best_start_y} +
         {1'b0, S_gesture_narrow_best} - 9'd1) :
        {1'b0, S_gesture_narrow_best_start_y};
    wire [8:0] S_shape_finger_mid_y = {1'b0, S_gesture_narrow_best_start_y} +
                                      ({1'b0, S_gesture_narrow_best} >> 1);
    wire [9:0] S_shape_row_center_x = ({1'b0, S_shape_row_xmin_q} +
                                        {1'b0, S_shape_row_xmax_q}) >> 1;
    wire S_shape_finger_row = (S_gesture_narrow_best != 8'd0) &&
        (S_shape_row_runs_q == 4'd1) &&
        (S_shape_row_width_q <= S_gesture_one_width_max) &&
        ({1'b0, S_shape_scan_row_q} >= {1'b0, S_gesture_narrow_best_start_y}) &&
        ({1'b0, S_shape_scan_row_q} <= S_shape_finger_end_y);
    wire S_shape_finger_samples_valid = S_shape_finger_top_seen &&
                                        S_shape_finger_mid_seen &&
                                        S_shape_finger_bottom_seen;
    wire signed [10:0] S_shape_center_d1 =
        $signed({2'b0, S_shape_finger_mid_x}) -
        $signed({2'b0, S_shape_finger_top_x});
    wire signed [10:0] S_shape_center_d2 =
        $signed({2'b0, S_shape_finger_bottom_x}) -
        $signed({2'b0, S_shape_finger_mid_x});
    wire signed [10:0] S_shape_center_mid_deviation =
        ($signed({2'b0, S_shape_finger_mid_x}) <<< 1) -
        $signed({2'b0, S_shape_finger_top_x}) -
        $signed({2'b0, S_shape_finger_bottom_x});
    wire [10:0] S_shape_center_mid_deviation_abs =
        S_shape_center_mid_deviation[10] ?
        (~S_shape_center_mid_deviation + 11'd1) : S_shape_center_mid_deviation;
    wire signed [10:0] S_shape_bend_min = $signed({2'b0, S_shape_side_min});
    wire S_shape_centerline_bent = S_shape_finger_samples_valid &&
        ((S_shape_center_mid_deviation_abs >= {2'b0, S_shape_side_min}) ||
         ((S_shape_center_d1 >= S_shape_bend_min) &&
          (S_shape_center_d2 <= -S_shape_bend_min)) ||
         ((S_shape_center_d1 <= -S_shape_bend_min) &&
          (S_shape_center_d2 >= S_shape_bend_min)));

    // A digit-0 hole is a vertically bounded, central background interval
    // whose left/right foreground boundaries persist across several rows.
    // This deliberately works from the existing first-gap row cache: a gap
    // reaching the top or bottom of the scan is flagged as boundary-open and
    // cannot qualify as a hole.
    wire [8:0] S_hole_scan_start_y = {1'b0, S_candidate_ymin};
    wire [8:0] S_hole_scan_end_y = S_shape_scan_end_y;
    wire [8:0] S_hole_inner_margin = (S_gesture_ref_width >> 5) + 9'd1;
    wire [8:0] S_hole_min_width = (S_gesture_ref_width >> 4) + 9'd2;
    wire [7:0] S_hole_min_height = (S_hand_height >> 4) + 8'd3;
    wire S_hole_gap_nonempty = (S_hole_gap_right_q > (S_hole_gap_left_q + 9'd1));
    wire [8:0] S_hole_gap_width = S_hole_gap_nonempty ?
        (S_hole_gap_right_q - S_hole_gap_left_q - 9'd1) : 9'd0;
    wire [9:0] S_hole_gap_center_x = ({1'b0, S_hole_gap_left_q} +
                                       {1'b0, S_hole_gap_right_q}) >> 1;
    wire [8:0] S_hole_center_tolerance = (S_gesture_ref_width >> 2) + 9'd2;
    wire S_hole_row_inside_hand =
        ({1'b0, S_hole_gap_left_q} >=
         ({1'b0, S_hole_row_xmin_q} + {1'b0, S_hole_inner_margin})) &&
        ({1'b0, S_hole_gap_right_q} + {1'b0, S_hole_inner_margin} <=
         {1'b0, S_hole_row_xmax_q});
    wire S_hole_row_centered =
        ({1'b0, S_hole_gap_center_x} + {1'b0, S_hole_center_tolerance} >=
         {1'b0, S_palm_center_x}) &&
        ({1'b0, S_palm_center_x} + {1'b0, S_hole_center_tolerance} >=
         {1'b0, S_hole_gap_center_x});
    wire S_hole_row_usable = S_hole_gap_valid_q &&
        (S_hole_row_runs_q >= 4'd2) && (S_hole_row_runs_q <= 4'd3) &&
        (S_hole_gap_width >= S_hole_min_width) && S_hole_row_inside_hand &&
        S_hole_row_centered;
    // Overlap, instead of exact edge equality, tolerates a round hole whose
    // interval naturally expands and contracts from row to row.
    wire S_hole_track_overlap = S_hole_active &&
        ({1'b0, S_hole_gap_left_q} <=
         ({1'b0, S_hole_track_right} + {1'b0, S_hole_inner_margin})) &&
        ({1'b0, S_hole_track_left} <=
         ({1'b0, S_hole_gap_right_q} + {1'b0, S_hole_inner_margin}));
    wire S_hole_can_finish =
        ({1'b0, S_hole_scan_row_q} + {1'b0, S_hole_min_height} <
         S_hole_scan_end_y);
    wire S_hole_track_credible = !S_hole_open_from_boundary &&
        (S_hole_track_height >= S_hole_min_height) &&
        (S_hole_track_area >= {8'd0, S_gesture_ref_width});
    // All defect products use this single signed multiplier, scheduled across
    // six scanner clocks per candidate boundary point.
    wire signed [21:0] S_geom_mul_product = S_geom_mul_a * S_geom_mul_b;
    wire signed [22:0] S_defect_cross_signed =
        {S_defect_cross_a[21], S_defect_cross_a} -
        {S_defect_cross_b[21], S_defect_cross_b};
    wire [21:0] S_defect_cross_abs = S_defect_cross_signed[22] ?
        (~S_defect_cross_signed[21:0] + 22'd1) : S_defect_cross_signed[21:0];
    wire signed [22:0] S_defect_dot_signed =
        {S_defect_dot_a[21], S_defect_dot_a} +
        {S_defect_dot_b[21], S_defect_dot_b};
    wire signed [22:0] S_defect_len_signed =
        {S_defect_len_a[21], S_defect_len_a} +
        {S_defect_len_b[21], S_defect_len_b};
    wire [10:0] S_defect_abs_ab_x = S_defect_ab_x[10] ?
                                      (~S_defect_ab_x + 11'd1) : S_defect_ab_x;
    wire [10:0] S_defect_abs_ab_y = S_defect_ab_y[10] ?
                                      (~S_defect_ab_y + 11'd1) : S_defect_ab_y;
    wire [11:0] S_defect_edge_manhattan =
        {1'b0, S_defect_abs_ab_x} + {1'b0, S_defect_abs_ab_y};
    wire [8:0] S_defect_depth_min = (S_gesture_ref_width >> 4) + 9'd1;
    wire S_defect_projected_on_edge = (S_defect_dot_signed > 23'sd0) &&
                                      (S_defect_dot_signed < S_defect_len_signed);
    wire signed [22:0] S_hull_cross_signed =
        {S_hull_cross_a[21], S_hull_cross_a} -
        {S_geom_mul_product[21], S_geom_mul_product};
    wire [10:0] S_hull_abs_ab_x = S_hull_ab_x[10] ?
                                   (~S_hull_ab_x + 11'd1) : S_hull_ab_x;
    wire [10:0] S_hull_abs_ab_y = S_hull_ab_y[10] ?
                                   (~S_hull_ab_y + 11'd1) : S_hull_ab_y;
    wire [10:0] S_hull_abs_ap_x = S_hull_ap_x[10] ?
                                   (~S_hull_ap_x + 11'd1) : S_hull_ap_x;
    wire [10:0] S_hull_abs_ap_y = S_hull_ap_y[10] ?
                                   (~S_hull_ap_y + 11'd1) : S_hull_ap_y;
    // Along a collinear ray Manhattan distance preserves the farthest point
    // ordering without requiring a second multiplier or a square root.
    wire [11:0] S_hull_candidate_manhattan =
        {1'b0, S_hull_abs_ab_x} + {1'b0, S_hull_abs_ab_y};
    wire [11:0] S_hull_point_manhattan =
        {1'b0, S_hull_abs_ap_x} + {1'b0, S_hull_abs_ap_y};
    wire [4:0] S_hull_feature_addr = (S_hull_feature_index < HULL_VERTEX_MAX) ?
                                      S_hull_feature_index : 5'd0;
    wire [8:0] S_hull_feature_x = S_hull_x[S_hull_feature_addr];
    wire [7:0] S_hull_feature_y = S_hull_y[S_hull_feature_addr];
    // Separate the vertical finger zone from the lateral thumb zone in the
    // palm-relative coordinate system.  The original open-palm width is a
    // stable scale, while the test itself remains left/right symmetric.
    wire [8:0] S_hull_lateral_offset = (S_gesture_ref_width >> 2) +
                                        (S_gesture_ref_width >> 3) + 9'd2;
    wire S_hull_feature_upper =
        ({1'b0, S_hull_feature_y} + {1'b0, (S_hand_height >> 3)} <
         {1'b0, S_palm_y}) &&
        ({1'b0, S_hull_feature_x} + {1'b0, (S_gesture_ref_width >> 1)} >=
         {1'b0, S_palm_center_x}) &&
        ({1'b0, S_palm_center_x} + {1'b0, (S_gesture_ref_width >> 1)} >=
         {1'b0, S_hull_feature_x});
    wire S_hull_feature_left =
        ({1'b0, S_hull_feature_y} >=
         ({1'b0, S_candidate_ymin} + {1'b0, (S_hand_height >> 3)})) &&
        ({1'b0, S_hull_feature_x} + {1'b0, S_hull_lateral_offset} <=
         {1'b0, S_palm_center_x});
    wire S_hull_feature_right =
        ({1'b0, S_hull_feature_y} >=
         ({1'b0, S_candidate_ymin} + {1'b0, (S_hand_height >> 3)})) &&
        ({1'b0, S_palm_center_x} + {1'b0, S_hull_lateral_offset} <=
         {1'b0, S_hull_feature_x});
    // Measure the central fingertip extension from the existing palm row,
    // normalized later by the open-palm width captured at lock time.  Using
    // the preserved reference makes the 1/9 split independent of distance to
    // the camera, while the central-upper restriction excludes a side thumb.
    wire S_hull_feature_center =
        ({1'b0, S_hull_feature_x} + {1'b0, (S_gesture_ref_width >> 1)} >=
         {1'b0, S_palm_center_x}) &&
        ({1'b0, S_palm_center_x} + {1'b0, (S_gesture_ref_width >> 1)} >=
         {1'b0, S_hull_feature_x}) &&
        ({1'b0, S_hull_feature_y} < {1'b0, S_palm_y});
    wire [8:0] S_index_extension = S_hull_top_seen &&
                                  (S_palm_y >= S_hull_top_y) ?
                                  ({1'b0, S_palm_y} - {1'b0, S_hull_top_y}) :
                                  9'd0;
    wire [8:0] S_index_short_extension = S_hull_center_top_seen &&
                                          (S_palm_y >= S_hull_center_top_y) ?
                                          ({1'b0, S_palm_y} -
                                           {1'b0, S_hull_center_top_y}) : 9'd0;
    wire [8:0] S_index_scan_extension =
        (S_palm_y >= S_gesture_narrow_best_start_y) ?
        ({1'b0, S_palm_y} - {1'b0, S_gesture_narrow_best_start_y}) : 9'd0;
    wire [8:0] S_index_long_min = S_gesture_ref_width >> 1;
    // Digit 9 is visibly shorter than digit 1 but can be lower than the
    // strict upper-finger zone.  The 7/16..1/2-width interval remains an
    // intentional UNKNOWN dead band between the two classes.
    wire [8:0] S_index_short_min = (S_gesture_ref_width >> 3) + 9'd2;
    wire [8:0] S_index_short_max =
        (S_gesture_ref_width >> 1) - (S_gesture_ref_width >> 4);
    wire S_index_extension_long = S_hull_top_seen &&
                                  (S_index_extension >= S_index_long_min);
    wire S_index_extension_short =
        ((S_hull_center_top_seen &&
          (S_index_short_extension >= S_index_short_min) &&
          (S_index_short_extension <= S_index_short_max)) ||
         ((S_index_scan_extension >= S_index_short_min) &&
          (S_index_scan_extension <= S_index_short_max)));
    // The deepest accepted defect is retained with its coordinate.  Gesture
    // rules use its vertical relation to the palm so a wrist-side indentation
    // cannot impersonate a finger gap.
    wire S_defect_deepest_upper =
        ({1'b0, S_defect_deepest_y} + {1'b0, (S_hand_height >> 3)} <
         {1'b0, S_palm_y});
    wire S_gesture_two_credible =
        (S_gesture_best_streak_2 >= GESTURE_RUN_STREAK_MIN_2);
    wire S_gesture_three_credible =
        (S_gesture_best_streak_3 >= GESTURE_RUN_STREAK_MIN_3);
    wire S_gesture_four_credible =
        (S_gesture_best_streak_4 >= GESTURE_RUN_STREAK_MIN_4);
    wire S_gesture_thumb_credible = S_gesture_four_envelope_valid &&
        (S_thumb_side_best >= GESTURE_THUMB_SIDE_STREAK_MIN) &&
        ((S_thumb_valley_best != 8'd0) ||
         (S_gesture_best_streak_5 >= GESTURE_RUN_STREAK_MIN_5));
    // One extension row can be hand-edge quantisation.  Two rows without a
    // valley/five-run corroboration are intentionally UNKNOWN, not digit 5.
    wire S_gesture_thumb_absent = S_gesture_four_envelope_valid &&
                                  (S_thumb_side_best <= 8'd1);
    wire S_gesture_five_credible = S_gesture_four_credible && S_gesture_thumb_credible;
    // The 6..9 branches consume only completed Jarvis-hull / defect results.
    // A point-store or hull overflow is deliberately UNKNOWN, never a partial
    // geometry decision.  Side tests are symmetric, so neither hand nor a
    // mirrored camera stream assigns a fixed image side to the thumb.
    wire S_hull_geometry_valid = S_hull_valid && !S_hull_overflow &&
                                 !S_contour_overflow &&
                                 (S_hull_vertex_count >= 5'd3);
    wire S_hull_one_side = ((S_hull_left_count != 4'd0) &&
                            (S_hull_right_count == 4'd0)) ||
                           ((S_hull_right_count != 4'd0) &&
                            (S_hull_left_count == 4'd0));
    // Do not turn a lateral thumb into a second vertical finger merely
    // because one scan line clips both.  The raw narrow streak is retained
    // separately from digit-1's stricter !two gate for this purpose.
    wire S_gesture_single_vertical_stem =
        (S_gesture_narrow_best >= GESTURE_ONE_NARROW_MIN);
    wire S_hull_upper_defect = (S_defect_count >= 4'd1) &&
                                S_defect_deepest_upper;
    wire S_gesture_six_credible = S_hull_geometry_valid &&
        (S_hull_left_count != 4'd0) && (S_hull_right_count != 4'd0) &&
        !S_gesture_single_vertical_stem &&
        !S_gesture_three_credible && !S_gesture_four_credible &&
        !S_gesture_five_credible;
    // Digit 7 is the requested thumb+index pose.  A side thumb can create a
    // transient two-run row, so it must not be rejected merely because the
    // legacy 2-finger statistic is set.  A sustained single vertical stem
    // plus one lateral hull support is the discriminating evidence.
    wire S_gesture_seven_credible = S_hull_geometry_valid && S_hull_one_side &&
        S_gesture_single_vertical_stem && (S_hull_upper_count >= 4'd1) &&
        !S_gesture_three_credible &&
        !S_gesture_four_credible && !S_gesture_five_credible;
    // Digit 1 is a sustained, long, narrow single stem whose sampled centerline
    // stays straight.  A global hand tilt shifts all three samples similarly,
    // so it is not mistaken for a bent digit-9 finger.
    wire S_gesture_one_credible =
        (S_gesture_narrow_best >= GESTURE_ONE_NARROW_MIN) &&
        S_index_extension_long &&
        !S_shape_centerline_bent &&
        !S_gesture_two_credible && !S_gesture_three_credible &&
        !S_gesture_four_credible && !S_gesture_five_credible;
    // Digit 8 is a side thumb plus a persistent two-finger upper split.  The
    // convex defect confirms the split when the sparse boundary sample keeps
    // the valley; it is supporting rather than mandatory because an external
    // hull may legitimately bridge the index/middle valley.
    wire S_gesture_eight_credible = S_hull_geometry_valid && S_hull_one_side &&
        S_gesture_two_credible &&
        (!S_gesture_single_vertical_stem || S_hull_upper_defect) &&
        !S_gesture_three_credible && !S_gesture_four_credible &&
        !S_gesture_five_credible;
    // Digit 9 also has one narrow stem, but is selected only when its sampled
    // centerline bends: either the midpoint departs from the top/bottom chord
    // or the two local directions reverse.  Length is intentionally not used
    // as the class separator.
    wire S_gesture_nine_credible = S_gesture_single_vertical_stem &&
        S_shape_centerline_bent &&
        !S_gesture_eight_credible && !S_gesture_two_credible &&
        !S_gesture_three_credible && !S_gesture_four_credible &&
        !S_gesture_five_credible;
    // Digit 0 is not inferred from an absence of fingers.  It is accepted
    // only after the independent hole scan has observed a central, bounded
    // background interval enclosed by foreground on every retained row.
    // S_track_match remains the separate lock/loss gate, so background loss
    // cannot become digit 0 through this branch.
    wire S_gesture_zero_credible = S_hole_closed;
    wire [3:0] S_gesture_candidate_code =
        S_gesture_zero_credible  ? GESTURE_0 :
        S_gesture_five_credible  ? GESTURE_5 :
        // Do not fall through to digit 3 when four fingers are clear but the
        // thumb test is ambiguous; the caller will expose UNKNOWN instead.
        S_gesture_four_credible  ? (S_gesture_thumb_absent ? GESTURE_4 : GESTURE_NONE) :
        // Check 8 before 7: two clear upright fingers plus a side thumb must
        // not be captured by the permissive single-stem evidence of 7.
        S_gesture_eight_credible ? GESTURE_8 :
        S_gesture_seven_credible ? GESTURE_7 :
        S_gesture_nine_credible  ? GESTURE_9 :
        S_gesture_six_credible   ? GESTURE_6 :
        S_gesture_three_credible ? GESTURE_3 :
        S_gesture_two_credible   ? GESTURE_2 :
        S_gesture_one_credible   ? GESTURE_1 : GESTURE_NONE;
    // OPEN_PALM remains the lock-entry gate, but it no longer bypasses the
    // independent thumb proof while classifying 4 versus 5 after lock.
    wire [3:0] S_frame_gesture_code =
        (S_raw_open_palm && (S_class_scan_max_runs >= 4'd5) && S_gesture_thumb_credible) ?
        GESTURE_5 : S_class_gesture_code;
    // The matcher and scanner both run on I_clk.  Capture a completed result
    // only after its toggle changes, then consume it once at a scan commit.
    wire S_template_result_new =
        (S_template_result_seen != S_template_result_toggle);
    wire S_template_09_fresh_match = S_template_result_pending &&
                                     S_template_decision_valid_q &&
                                     ((S_template_decision_code_q == GESTURE_0) ||
                                      (S_template_decision_code_q == GESTURE_9));
    // Conservative fusion: classes 1..8 bypass templates completely.  Legacy
    // 0/9 require their matching fresh template proof; UNKNOWN may be filled
    // only by that same fresh 0/9 proof.
    wire [3:0] S_fused_frame_gesture_code =
        (S_frame_gesture_code == GESTURE_0) ?
            ((S_template_09_fresh_match &&
              (S_template_decision_code_q == GESTURE_0)) ?
             GESTURE_0 : GESTURE_NONE) :
        (S_frame_gesture_code == GESTURE_9) ?
            ((S_template_09_fresh_match &&
              (S_template_decision_code_q == GESTURE_9)) ?
             GESTURE_9 : GESTURE_NONE) :
        (S_frame_gesture_code == GESTURE_NONE) ?
            (S_template_09_fresh_match ? S_template_decision_code_q :
             GESTURE_NONE) :
        S_frame_gesture_code;
    assign O_fg_mask_wr_en   = S_sample_d3;
    assign O_fg_mask_wr_addr = S_fg_addr_d3;
    assign O_fg_mask_wr_data = S_fg_d3;

    // This observer receives the same registered foreground sample and the
    // same analysis-coordinate bbox that supplies the green HDMI rectangle.
    // Its registered, high-confidence 0/9 result is fused only at the digit
    // stability input; it has no feedback into tracking or pixel processing.
    hand_template_match_09 u_hand_template_match_09 (
        .I_clk              ( I_clk                         ),
        .I_rst_n            ( I_rst_n                       ),
        .I_frame_start      ( I_frame_start                 ),
        .I_sample_valid     ( S_sample_d3                   ),
        .I_sample_x         ( S_sample_x_d3                 ),
        .I_sample_y         ( S_sample_y_d3                 ),
        .I_fg               ( S_fg_d3                       ),
        .I_roi_valid        ( O_lock_valid && O_candidate_valid ),
        .I_roi_xmin         ( O_bbox_xmin                   ),
        .I_roi_xmax         ( O_bbox_xmax                   ),
        .I_roi_ymin         ( O_bbox_ymin                   ),
        .I_roi_ymax         ( O_bbox_ymax                   ),
        .O_busy             ( S_template_busy               ),
        .O_score_0_num      ( S_template_score_0_num        ),
        .O_score_0_den      ( S_template_score_0_den        ),
        .O_score_9_num      ( S_template_score_9_num        ),
        .O_score_9_den      ( S_template_score_9_den        ),
        .O_decision_valid   ( S_template_decision_valid      ),
        .O_decision_code    ( S_template_decision_code       ),
        .O_result_toggle    ( S_template_result_toggle       )
    );

    // 1/4 IIR update, expressed without signed arithmetic or a divider.
    // Symmetric truncation deliberately ignores sub-four-LSB noise.
    function [5:0] F_bg_iir_next;
        input [5:0] F_old;
        input [5:0] F_new;
        reg [6:0] F_delta;
        begin
            if(F_new >= F_old) begin
                F_delta = F_new - F_old;
                F_bg_iir_next = F_old + (F_delta >> 2);
            end else begin
                F_delta = F_old - F_new;
                F_bg_iir_next = F_old - (F_delta >> 2);
            end
        end
    endfunction

    // Update the published OPEN_PALM state only after a stable run of raw frame
    // classifications. A positive frame resets the negative streak and vice
    // versa. The counters saturate at HAND_CONFIRM_FRAMES.
    task T_update_hand_stability;
        input T_raw_hand;
        begin
            if(T_raw_hand) begin
                S_hand_negative_streak <= 2'd0;
                if(S_hand_positive_streak < HAND_CONFIRM_FRAMES)
                    S_hand_positive_streak <= S_hand_positive_streak + 2'd1;
                if(S_hand_positive_streak >= (HAND_CONFIRM_FRAMES - 2'd1))
                    O_hand_valid <= 1'b1;
            end else begin
                S_hand_positive_streak <= 2'd0;
                if(S_hand_negative_streak < HAND_CONFIRM_FRAMES)
                    S_hand_negative_streak <= S_hand_negative_streak + 2'd1;
                if(S_hand_negative_streak >= (HAND_CONFIRM_FRAMES - 2'd1))
                    O_hand_valid <= 1'b0;
            end
        end
    endtask

    // A frame which never produces a coherent candidate must also advance the
    // lock-loss state.  Keeping this in the scanner process means that an
    // empty scene cannot leave LOCKED asserted forever merely because it exits
    // before SCAN_CLASSIFY_COMMIT.
    task T_track_miss;
        begin
            // These values describe one completed candidate scan.  A frame
            // without a coherent candidate must not retain a stale OSD trace.
            O_gesture_candidate_code <= GESTURE_NONE;
            O_gesture_best_streak_2 <= 8'd0;
            O_gesture_best_streak_3 <= 8'd0;
            O_gesture_best_streak_4 <= 8'd0;
            O_gesture_best_streak_5 <= 8'd0;
            O_gesture_narrow_best <= 8'd0;
            if(O_track_state == TRACK_CONFIRM) begin
                O_track_state <= TRACK_SEARCH;
                O_lock_valid <= 1'b0;
                O_confirm_count <= 4'd0;
                O_lost_count <= 4'd0;
                O_gesture_valid <= 1'b0;
                O_gesture_code <= 3'd0;
                S_gesture_pending_code <= GESTURE_NONE;
                S_gesture_pending_streak <= 2'd0;
                S_gesture_unknown_streak <= 3'd0;
            end else if(O_track_state == TRACK_LOCKED) begin
                O_track_state <= TRACK_LOST;
                O_lost_count <= 4'd1;
                O_gesture_valid <= 1'b0;
                O_gesture_code <= 3'd0;
                S_gesture_pending_code <= GESTURE_NONE;
                S_gesture_pending_streak <= 2'd0;
                S_gesture_unknown_streak <= 3'd0;
            end else if(O_track_state == TRACK_LOST) begin
                if(O_lost_count >= (LOCK_LOST_FRAMES - 4'd1)) begin
                    O_track_state <= TRACK_SEARCH;
                    O_lock_valid <= 1'b0;
                    O_confirm_count <= 4'd0;
                    O_lost_count <= 4'd0;
                    S_lock_xmin <= 9'd0; S_lock_xmax <= 9'd0;
                    S_lock_ymin <= 8'd0; S_lock_ymax <= 8'd0;
                    S_lock_area <= 17'd0;
                    S_open_palm_width_ref <= 9'd0;
                end else begin
                    O_lost_count <= O_lost_count + 4'd1;
                end
            end else begin
                O_lock_valid <= 1'b0;
                O_confirm_count <= 4'd0;
                O_lost_count <= 4'd0;
            end
        end
    endtask

    // Background capture and streaming projection accumulation.  First-pixel
    // loss at frame start is intentional: it avoids any feedback/buffering on
    // the proven camera stream and affects only one of 57600 analysis samples.
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            S_src_x <= 9'd0;
            S_src_y <= 10'd0;
            S_bg_addr_q <= 16'd0;
            S_bg_addr_d2 <= 16'd0;
            S_bg_value_q <= 6'd0;
            S_gray_d1 <= 6'd0; S_gray_d2 <= 6'd0;
            S_sample_d1 <= 1'b0; S_sample_d2 <= 1'b0;
            S_background_ready_d1 <= 1'b0; S_background_ready_d2 <= 1'b0;
            S_bg_learn_d1 <= 1'b0; S_bg_learn_d2 <= 1'b0;
            S_sample_x_d1 <= 9'd0; S_sample_x_d2 <= 9'd0;
            S_sample_y_d1 <= 8'd0; S_sample_y_d2 <= 8'd0;
            S_sample_d3 <= 1'b0; S_fg_d3 <= 1'b0;
            S_sample_x_d3 <= 9'd0; S_sample_y_d3 <= 8'd0;
            S_fg_addr_d3 <= 16'd0;
            S_bg_capture_seen <= 1'b0;
            S_bg_capture_pending <= 1'b0;
            S_init_frames <= 6'd0;
            O_background_ready <= 1'b0;
            O_bg_frame_count <= 6'd0;
            O_bg_state <= 2'd0;
            S_previous_fg <= 1'b0;
            S_stat_row_seen <= 1'b0;
            S_last_stat_row <= 8'd0;
            S_area <= 17'd0;
            S_xmin <= 9'd319; S_xmax <= 9'd0;
            S_ymin <= 8'd179; S_ymax <= 8'd0;
            S_raw_area <= 17'd0;
            S_raw_xmin <= 9'd0; S_raw_xmax <= 9'd0;
            S_raw_ymin <= 8'd0; S_raw_ymax <= 8'd0;
            S_frame_done_toggle <= 1'b0;
        end else begin
            if(I_frame_start) begin
                S_src_x <= I_line_last ? 9'd0 : 9'd1;
                S_src_y <= I_line_last ? 10'd1 : 10'd0;
                S_area <= 17'd0;
                S_xmin <= 9'd319; S_xmax <= 9'd0;
                S_ymin <= 8'd179; S_ymax <= 8'd0;
                if(S_bg_capture_pending) begin
                    // Start only at a source-frame boundary.  The old mask,
                    // bbox and HAND result are invalidated immediately; RAM
                    // contents are overwritten by the next 32 learning frames.
                    S_bg_capture_pending <= 1'b0;
                    S_init_frames <= 6'd0;
                    O_background_ready <= 1'b0;
                    O_bg_frame_count <= 6'd0;
                    O_bg_state <= 2'd1;
                end else if((O_bg_state == 2'd1) && !O_background_ready) begin
                    if(S_init_frames >= INIT_FRAMES) begin
                        O_background_ready <= 1'b1;
                        O_bg_frame_count <= INIT_FRAMES;
                        O_bg_state <= 2'd2;
                    end else begin
                        S_init_frames <= S_init_frames + 6'd1;
                        O_bg_frame_count <= S_init_frames + 6'd1;
                    end
                end
            end else if(I_pixel_valid) begin
                if(I_line_last) begin
                    S_src_x <= 9'd0;
                    S_src_y <= S_src_y + 10'd1;
                end else begin
                    S_src_x <= S_src_x + 9'd1;
                end
                // The last source line arrives after the final sampled line
                // (716), so all projection writes have completed here.
                if(I_line_last && S_src_y == 10'd719 && O_background_ready) begin
                    S_raw_area <= S_area;
                    S_raw_xmin <= S_xmin; S_raw_xmax <= S_xmax;
                    S_raw_ymin <= S_ymin; S_raw_ymax <= S_ymax;
                    S_frame_done_toggle <= ~S_frame_done_toggle;
                end
            end

            // Synchronous simple-dual-port background RAM.  The RAM port B
            // consumes the already registered address.  Thus S_bg_value_q
            // corresponds exactly to the d2 metadata after this clock edge.
            // The write port is never reset or bulk-cleared.
            S_sample_d2 <= S_sample_d1;
            S_gray_d2 <= S_gray_d1;
            S_background_ready_d2 <= S_background_ready_d1;
            S_bg_learn_d2 <= S_bg_learn_d1;
            S_bg_addr_d2 <= S_bg_addr_q;
            S_sample_x_d2 <= S_sample_x_d1;
            S_sample_y_d2 <= S_sample_y_d1;
            if(S_sample_d1)
                S_bg_value_q <= S_background[S_bg_addr_q];

            S_sample_d1 <= S_sample_now;
            S_bg_learn_d1 <= S_sample_now && (O_bg_state == 2'd1) && !O_background_ready &&
                             (S_init_frames > 6'd1);
            if(S_sample_now) begin
                S_bg_addr_q <= S_bg_addr;
                S_gray_d1 <= S_gray;
                S_background_ready_d1 <= O_background_ready;
                S_sample_x_d1 <= S_src_x;
                S_sample_y_d1 <= S_analysis_y;
            end

            if(S_bg_first_frame_write)
                S_background[S_bg_first_frame_addr] <= S_gray;
            else if(S_bg_learn_d2)
                S_background[S_bg_addr_d2] <= F_bg_iir_next(S_bg_value_q, S_gray_d2);

            // One additional registered foreground stage breaks the ERAM
            // output -> abs-diff -> statistic-enable path.  The final sample
            // drains during source lines 717..719 before frame completion.
            S_sample_d3 <= S_sample_d2 && S_background_ready_d2;
            S_fg_d3 <= S_fg;
            S_sample_x_d3 <= S_sample_x_d2;
            S_sample_y_d3 <= S_sample_y_d2;
            S_fg_addr_d3 <= S_bg_addr_d2;

            // Consume the registered foreground decision.  All geometric
            // statistics use its matching coordinate, never live input x/y.
            if(S_sample_d3) begin
                // I_frame_start intentionally drops source pixel (0,0).  Reset
                // row summaries on a row transition, not on x==0, otherwise
                // row 0 accumulates stale counts across frames.
                if(!S_stat_row_seen || (S_sample_y_d3 != S_last_stat_row)) begin
                    S_row_width[S_sample_y_d3] <= S_fg_d3 ? 9'd1 : 9'd0;
                    S_row_runs[S_sample_y_d3] <= S_fg_d3 ? 4'd1 : 4'd0;
                    S_row_xmin[S_sample_y_d3] <= S_fg_d3 ? S_sample_x_d3 : 9'd319;
                    S_row_xmax[S_sample_y_d3] <= S_fg_d3 ? S_sample_x_d3 : 9'd0;
                    S_row_gap_left[S_sample_y_d3] <= 9'd0;
                    S_row_gap_right[S_sample_y_d3] <= 9'd0;
                    S_row_gap_valid[S_sample_y_d3] <= 1'b0;
                    S_previous_fg <= S_fg_d3;
                    S_stat_row_seen <= 1'b1;
                    S_last_stat_row <= S_sample_y_d3;
                end else begin
                    if(S_fg_d3) begin
                        S_row_width[S_sample_y_d3] <= S_row_width[S_sample_y_d3] + 9'd1;
                        if(S_row_width[S_sample_y_d3] == 9'd0)
                            S_row_xmin[S_sample_y_d3] <= S_sample_x_d3;
                        S_row_xmax[S_sample_y_d3] <= S_sample_x_d3;
                    end
                    if(S_fg_d3 && !S_previous_fg)
                        S_row_runs[S_sample_y_d3] <= S_row_runs[S_sample_y_d3] + 4'd1;
                    // Capture only the first internal gap: it is sufficient
                    // for index/middle separation while keeping storage and
                    // point-extraction work bounded.
                    if(!S_fg_d3 && S_previous_fg &&
                       (S_row_runs[S_sample_y_d3] == 4'd1))
                        S_row_gap_left[S_sample_y_d3] <= S_sample_x_d3;
                    if(S_fg_d3 && !S_previous_fg &&
                       (S_row_runs[S_sample_y_d3] == 4'd1)) begin
                        S_row_gap_right[S_sample_y_d3] <= S_sample_x_d3;
                        S_row_gap_valid[S_sample_y_d3] <= 1'b1;
                    end
                    S_previous_fg <= S_fg_d3;
                end
                // Column 0 also misses source pixel (0,0), so initialize it at
                // its first observed sample (analysis row 1) instead of adding
                // to an uninitialized/stale previous-frame value.
                if(S_sample_y_d3 == 8'd0 ||
                   (S_sample_x_d3 == 9'd0 && S_sample_y_d3 == 8'd1))
                    S_col_count[S_sample_x_d3] <= S_fg_d3 ? 8'd1 : 8'd0;
                else if(S_fg_d3)
                    S_col_count[S_sample_x_d3] <= S_col_count[S_sample_x_d3] + 8'd1;

                if(S_fg_d3) begin
                    S_area <= S_area + 17'd1;
                    if(S_sample_x_d3 < S_xmin) S_xmin <= S_sample_x_d3;
                    if(S_sample_x_d3 > S_xmax) S_xmax <= S_sample_x_d3;
                    if(S_sample_y_d3 < S_ymin) S_ymin <= S_sample_y_d3;
                    if(S_sample_y_d3 > S_ymax) S_ymax <= S_sample_y_d3;
                end
            end

            // The 24 MHz button domain emits a toggle, synchronized before
            // this module.  Latch it as a pending request so a press arriving
            // mid-frame cannot split one background-learning frame in two.
            if(I_bg_capture_toggle != S_bg_capture_seen) begin
                S_bg_capture_seen <= I_bg_capture_toggle;
                S_bg_capture_pending <= 1'b1;
            end
        end
    end

    // Frame-end projection scanner.  It reads 180 row summaries and 320 column
    // counts, rejects sparse scatter, then evaluates open-palm/wrist and finger-separation features.
    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            S_scan_seen_toggle <= 1'b0;
            S_scan_state <= SCAN_IDLE;
            S_scan_row <= 8'd0;
            S_scan_col <= 9'd0;
            S_y_streak <= 8'd0; S_y_best_streak <= 8'd0;
            S_y_streak_start <= 8'd0; S_y_best_start <= 8'd0; S_y_best_end <= 8'd0;
            S_x_streak <= 9'd0; S_x_best_streak <= 9'd0;
            S_x_streak_start <= 9'd0; S_x_best_start <= 9'd0; S_x_best_end <= 9'd0;
            S_palm_width <= 9'd0; S_palm_y <= 8'd0;
            S_scan_max_runs <= 4'd0; S_open_run_streak <= 8'd0; S_open_run_best <= 8'd0;
            S_narrow_streak <= 8'd0; S_scan_wrist_valid <= 1'b0;
            S_scan_wrist_y <= 8'd0; S_neck_candidate_y <= 8'd0;
            S_neck_candidate_valid <= 1'b0;
            S_candidate_xmin <= 9'd0; S_candidate_xmax <= 9'd0;
            S_candidate_ymin <= 8'd0; S_candidate_ymax <= 8'd0;
            S_candidate_width <= 9'd0; S_candidate_height <= 8'd0;
            S_palm_search_start_y_q <= 9'd0; S_palm_search_end_y_q <= 9'd0;
            S_gesture_scan_end_y_q <= 9'd0;
            S_hand_ymax <= 8'd0; S_hand_height <= 8'd0; S_hand_area <= 17'd0;
            S_area_row_width_x100_q <= 16'd0;
            S_neck_scan_row_q <= 8'd0;
            S_gesture_row_runs_q <= 4'd0;
            S_gesture_row_width_q <= 9'd0;
            S_gesture_scan_row_q <= 8'd0;
            S_gesture_run_streak_2 <= 8'd0; S_gesture_run_streak_3 <= 8'd0;
            S_gesture_run_streak_4 <= 8'd0; S_gesture_run_streak_5 <= 8'd0;
            S_gesture_best_streak_2 <= 8'd0; S_gesture_best_streak_3 <= 8'd0;
            S_gesture_best_streak_4 <= 8'd0; S_gesture_best_streak_5 <= 8'd0;
            S_gesture_narrow_streak <= 8'd0; S_gesture_narrow_best <= 8'd0;
            S_gesture_narrow_start_y <= 8'd0;
            S_gesture_narrow_best_start_y <= 8'd0;
            S_gesture_row_span_q <= 9'd0;
            S_gesture_four_envelope_valid <= 1'b0;
            S_gesture_four_xmin <= 9'd0; S_gesture_four_xmax <= 9'd0;
            S_thumb_row_runs_q <= 4'd0;
            S_thumb_row_width_q <= 9'd0; S_thumb_row_span_q <= 9'd0;
            S_thumb_row_xmin_q <= 9'd0; S_thumb_row_xmax_q <= 9'd0;
            S_thumb_scan_row_q <= 8'd0;
            S_thumb_side_streak <= 8'd0; S_thumb_side_best <= 8'd0;
            S_thumb_valley_streak <= 8'd0; S_thumb_valley_best <= 8'd0;
            S_palm_xmin <= 9'd0; S_palm_xmax <= 9'd0; S_palm_center_x <= 9'd0;
            S_shape_row_runs_q <= 4'd0;
            S_shape_row_width_q <= 9'd0; S_shape_row_span_q <= 9'd0;
            S_shape_row_xmin_q <= 9'd0; S_shape_row_xmax_q <= 9'd0;
            S_shape_scan_row_q <= 8'd0;
            S_shape_left_streak <= 8'd0; S_shape_left_best <= 8'd0;
            S_shape_right_streak <= 8'd0; S_shape_right_best <= 8'd0;
            S_shape_notch_streak <= 8'd0; S_shape_notch_best <= 8'd0;
            S_shape_l_streak <= 8'd0; S_shape_l_best <= 8'd0;
            S_shape_hook_streak <= 8'd0; S_shape_hook_best <= 8'd0;
            S_shape_top_narrow_seen <= 1'b0; S_shape_tip_compact_seen <= 1'b0;
            S_shape_top_xmin <= 9'd0; S_shape_top_xmax <= 9'd0;
            S_shape_finger_top_seen <= 1'b0; S_shape_finger_mid_seen <= 1'b0;
            S_shape_finger_bottom_seen <= 1'b0;
            S_shape_finger_top_x <= 9'd0; S_shape_finger_mid_x <= 9'd0;
            S_shape_finger_bottom_x <= 9'd0;
            S_hole_row_runs_q <= 4'd0; S_hole_gap_valid_q <= 1'b0;
            S_hole_gap_left_q <= 9'd0; S_hole_gap_right_q <= 9'd0;
            S_hole_row_xmin_q <= 9'd0; S_hole_row_xmax_q <= 9'd0;
            S_hole_scan_row_q <= 8'd0;
            S_hole_active <= 1'b0; S_hole_open_from_boundary <= 1'b0;
            S_hole_closed <= 1'b0;
            S_hole_track_left <= 9'd0; S_hole_track_right <= 9'd0;
            S_hole_track_height <= 8'd0; S_hole_track_area <= 17'd0;
            S_contour_point_count <= 8'd0; S_contour_overflow <= 1'b0;
            S_hull_point_index <= 8'd0; S_hull_start_index <= 8'd0;
            S_hull_current_index <= 8'd0; S_hull_candidate_index <= 8'd0;
            S_hull_start_x_q <= 9'd0; S_hull_start_y_q <= 8'd0;
            S_hull_find_point_x_q <= 9'd0; S_hull_find_point_y_q <= 8'd0;
            S_hull_current_x_q <= 9'd0; S_hull_candidate_x_q <= 9'd0;
            S_hull_current_y_q <= 8'd0; S_hull_candidate_y_q <= 8'd0;
            S_hull_vertex_count <= 5'd0; S_hull_overflow <= 1'b0;
            S_hull_valid <= 1'b0;
            S_hull_ab_x <= 11'sd0; S_hull_ab_y <= 11'sd0;
            S_hull_ap_x <= 11'sd0; S_hull_ap_y <= 11'sd0;
            S_hull_cross_a <= 22'sd0;
            S_hull_candidate_manhattan_q <= 12'd0;
            S_hull_point_manhattan_q <= 12'd0;
            S_hull_cross_negative_q <= 1'b0; S_hull_cross_zero_q <= 1'b0;
            S_hull_replace_q <= 1'b0;
            S_defect_edge_index <= 5'd0; S_defect_point_index <= 8'd0;
            S_defect_ab_x <= 11'sd0; S_defect_ab_y <= 11'sd0;
            S_defect_ap_x <= 11'sd0; S_defect_ap_y <= 11'sd0;
            S_defect_cross_a <= 22'sd0; S_defect_cross_b <= 22'sd0;
            S_defect_dot_a <= 22'sd0; S_defect_dot_b <= 22'sd0;
            S_defect_len_a <= 22'sd0; S_defect_len_b <= 22'sd0;
            S_geom_mul_a <= 11'sd0; S_geom_mul_b <= 11'sd0;
            S_defect_threshold_q <= 22'd0; S_defect_best_cross <= 22'd0;
            S_defect_max_cross <= 22'd0; S_defect_best_x <= 9'd0;
            S_defect_best_y <= 8'd0; S_defect_deepest_x <= 9'd0;
            S_defect_deepest_y <= 8'd0; S_defect_count <= 4'd0;
            S_hull_feature_index <= 5'd0;
            S_hull_upper_count <= 4'd0; S_hull_left_count <= 4'd0;
            S_hull_right_count <= 4'd0;
            S_hull_top_seen <= 1'b0; S_hull_top_y <= 8'd0;
            S_hull_center_top_seen <= 1'b0; S_hull_center_top_y <= 8'd0;
            S_class_gesture_code <= GESTURE_NONE;
            S_gesture_pending_code <= GESTURE_NONE;
            S_gesture_pending_streak <= 2'd0;
            S_gesture_unknown_streak <= 3'd0;
            S_template_result_seen <= 1'b0;
            S_template_decision_valid_q <= 1'b0;
            S_template_decision_code_q <= GESTURE_NONE;
            S_template_result_pending <= 1'b0;
            O_gesture_valid <= 1'b0;
            O_gesture_code <= 3'd0;
            O_gesture_candidate_code <= GESTURE_NONE;
            O_gesture_best_streak_2 <= 8'd0; O_gesture_best_streak_3 <= 8'd0;
            O_gesture_best_streak_4 <= 8'd0; O_gesture_best_streak_5 <= 8'd0;
            O_gesture_narrow_best <= 8'd0;
            O_hand_valid <= 1'b0;
            O_lock_valid <= 1'b0;
            O_track_state <= TRACK_SEARCH;
            O_confirm_count <= 4'd0;
            O_lost_count <= 4'd0;
            O_candidate_valid <= 1'b0;
            O_bbox_xmin <= 9'd0; O_bbox_xmax <= 9'd0;
            O_bbox_ymin <= 8'd0; O_bbox_ymax <= 8'd0;
            O_wrist_valid <= 1'b0; O_wrist_y <= 8'd0;
            O_finger_max_runs <= 4'd0;
            O_foreground_area <= 17'd0;
            O_fail_code <= FAIL_NO_FG;
            O_area_ok <= 1'b0; O_aspect_ok <= 1'b0;
            O_fill_ok <= 1'b0; O_segment_ok <= 1'b0;
            S_class_candidate_density_ok <= 1'b0;
            S_hand_positive_streak <= 2'd0;
            S_hand_negative_streak <= 2'd0;
            S_lock_xmin <= 9'd0; S_lock_xmax <= 9'd0;
            S_lock_ymin <= 8'd0; S_lock_ymax <= 8'd0;
            S_lock_area <= 17'd0;
            S_open_palm_width_ref <= 9'd0;
            O_result_toggle <= 1'b0;
        end else begin
            // Discard template data whenever the displayed ROI is not a valid
            // locked candidate.  This prevents a previous hand's 0/9 result
            // from influencing a later lock.  Otherwise latch a matcher
            // result only after its completion toggle has changed.
            if(!O_lock_valid || !O_candidate_valid) begin
                S_template_result_seen <= S_template_result_toggle;
                S_template_decision_valid_q <= 1'b0;
                S_template_decision_code_q <= GESTURE_NONE;
                S_template_result_pending <= 1'b0;
            end else if(S_template_result_new) begin
                S_template_result_seen <= S_template_result_toggle;
                S_template_decision_valid_q <= S_template_decision_valid;
                S_template_decision_code_q <= S_template_decision_code;
                S_template_result_pending <= 1'b1;
            end
            // During BG_WAIT/BG_INIT suppress all stale classifier output.
            // This affects only display/state publication, never a classifier
            // comparison or its threshold.
            if(!O_background_ready) begin
                S_scan_state <= SCAN_IDLE;
                S_scan_seen_toggle <= S_frame_done_toggle;
                O_hand_valid <= 1'b0;
                O_lock_valid <= 1'b0;
                O_track_state <= TRACK_SEARCH;
                O_confirm_count <= 4'd0;
                O_lost_count <= 4'd0;
                S_lock_xmin <= 9'd0; S_lock_xmax <= 9'd0;
                S_lock_ymin <= 8'd0; S_lock_ymax <= 8'd0;
                S_lock_area <= 17'd0;
                S_open_palm_width_ref <= 9'd0;
                S_hand_positive_streak <= 2'd0;
                S_hand_negative_streak <= 2'd0;
                O_gesture_valid <= 1'b0;
                O_gesture_code <= 3'd0;
                O_gesture_candidate_code <= GESTURE_NONE;
                O_gesture_best_streak_2 <= 8'd0; O_gesture_best_streak_3 <= 8'd0;
                O_gesture_best_streak_4 <= 8'd0; O_gesture_best_streak_5 <= 8'd0;
                O_gesture_narrow_best <= 8'd0;
                S_gesture_pending_code <= GESTURE_NONE;
                S_gesture_pending_streak <= 2'd0;
                S_gesture_unknown_streak <= 3'd0;
                if(O_candidate_valid || O_hand_valid || O_gesture_valid)
                    O_result_toggle <= ~O_result_toggle;
                O_candidate_valid <= 1'b0;
                O_bbox_xmin <= 9'd0; O_bbox_xmax <= 9'd0;
                O_bbox_ymin <= 8'd0; O_bbox_ymax <= 8'd0;
                O_wrist_valid <= 1'b0; O_wrist_y <= 8'd0;
                O_finger_max_runs <= 4'd0;
                O_foreground_area <= 17'd0;
                O_fail_code <= FAIL_NO_FG;
                O_area_ok <= 1'b0; O_aspect_ok <= 1'b0;
                O_fill_ok <= 1'b0; O_segment_ok <= 1'b0;
            end else if(S_scan_state == SCAN_IDLE) begin
                if(S_scan_seen_toggle != S_frame_done_toggle) begin
                    S_scan_seen_toggle <= S_frame_done_toggle;
                    if(S_raw_area == 0 || S_raw_xmin > S_raw_xmax || S_raw_ymin > S_raw_ymax) begin
                        T_update_hand_stability(1'b0);
                        T_track_miss;
                        O_candidate_valid <= 1'b0;
                        O_bbox_xmin <= 9'd0; O_bbox_xmax <= 9'd0;
                        O_bbox_ymin <= 8'd0; O_bbox_ymax <= 8'd0;
                        O_wrist_valid <= 1'b0; O_wrist_y <= 8'd0;
                        O_finger_max_runs <= 4'd0;
                        O_foreground_area <= 17'd0;
                        O_fail_code <= FAIL_NO_FG;
                        O_area_ok <= 1'b0; O_aspect_ok <= 1'b0;
                        O_fill_ok <= 1'b0; O_segment_ok <= 1'b0;
                        O_result_toggle <= ~O_result_toggle;
                    end else if(S_raw_area < MIN_AREA) begin
                        // A few isolated red points must never create a bbox.
                        T_update_hand_stability(1'b0);
                        T_track_miss;
                        O_candidate_valid <= 1'b0;
                        O_bbox_xmin <= 9'd0; O_bbox_xmax <= 9'd0;
                        O_bbox_ymin <= 8'd0; O_bbox_ymax <= 8'd0;
                        O_wrist_valid <= 1'b0; O_wrist_y <= 8'd0;
                        O_finger_max_runs <= 4'd0;
                        O_foreground_area <= S_raw_area;
                        O_fail_code <= FAIL_AREA;
                        O_area_ok <= 1'b0; O_aspect_ok <= 1'b0;
                        O_fill_ok <= 1'b0; O_segment_ok <= 1'b0;
                        O_result_toggle <= ~O_result_toggle;
                    end else begin
                        // First find the longest consecutive active-row run.
                        // This prevents a few isolated pixels at distant y
                        // coordinates from stretching the candidate vertically.
                        S_candidate_xmin <= 9'd0; S_candidate_xmax <= 9'd0;
                        S_candidate_ymin <= 8'd0; S_candidate_ymax <= 8'd0;
                        S_candidate_width <= 9'd0; S_candidate_height <= 8'd0;
                        S_palm_search_start_y_q <= 9'd0; S_palm_search_end_y_q <= 9'd0;
                        S_gesture_scan_end_y_q <= 9'd0;
                        S_scan_state <= SCAN_BOUNDS_Y;
                        S_scan_row <= 8'd0;
                        S_y_streak <= 8'd0; S_y_best_streak <= 8'd0;
                        S_y_streak_start <= 8'd0; S_y_best_start <= 8'd0; S_y_best_end <= 8'd0;
                    end
                end
            end else if(S_scan_state == SCAN_BOUNDS_Y) begin
                if(S_row_y_active) begin
                    if(S_y_streak == 8'd0)
                        S_y_streak_start <= S_scan_row;
                    S_y_streak <= S_y_streak + 8'd1;
                    if(S_y_streak_next > S_y_best_streak) begin
                        S_y_best_streak <= S_y_streak_next;
                        S_y_best_start <= S_y_streak_start_next;
                        S_y_best_end <= S_scan_row;
                    end
                end else begin
                    S_y_streak <= 8'd0;
                end

                if(S_scan_row == 8'd179) begin
                    if(S_y_final_best_streak >= MIN_COHERENT_ROWS) begin
                        S_candidate_ymin <= S_y_final_start;
                        S_candidate_ymax <= S_y_final_end;
                        S_candidate_height <= S_y_final_end - S_y_final_start + 8'd1;
                        S_scan_state <= SCAN_BOUNDS_X;
                        S_scan_col <= 9'd0;
                        S_x_streak <= 9'd0; S_x_best_streak <= 9'd0;
                        S_x_streak_start <= 9'd0; S_x_best_start <= 9'd0; S_x_best_end <= 9'd0;
                    end else begin
                        // There are enough pixels overall, but no coherent object.
                        T_update_hand_stability(1'b0);
                        T_track_miss;
                        O_candidate_valid <= 1'b0;
                        O_bbox_xmin <= 9'd0; O_bbox_xmax <= 9'd0;
                        O_bbox_ymin <= 8'd0; O_bbox_ymax <= 8'd0;
                        O_wrist_valid <= 1'b0; O_wrist_y <= 8'd0;
                        O_finger_max_runs <= 4'd0;
                        O_foreground_area <= S_raw_area;
                        O_fail_code <= FAIL_AREA;
                        O_area_ok <= 1'b0; O_aspect_ok <= 1'b0;
                        O_fill_ok <= 1'b0; O_segment_ok <= 1'b0;
                        O_result_toggle <= ~O_result_toggle;
                        S_scan_state <= SCAN_IDLE;
                    end
                end else begin
                    S_scan_row <= S_scan_row + 8'd1;
                end
            end else if(S_scan_state == SCAN_BOUNDS_X) begin
                // Column occupancy uses the existing projection RAM.  The
                // longest run suppresses distant specks without full-frame CCL.
                if(S_col_x_active) begin
                    if(S_x_streak == 9'd0)
                        S_x_streak_start <= S_scan_col;
                    S_x_streak <= S_x_streak + 9'd1;
                    if(S_x_streak_next > S_x_best_streak) begin
                        S_x_best_streak <= S_x_streak_next;
                        S_x_best_start <= S_x_streak_start_next;
                        S_x_best_end <= S_scan_col;
                    end
                end else begin
                    S_x_streak <= 9'd0;
                end

                if(S_scan_col == 9'd319) begin
                    if(S_x_final_best_streak >= MIN_COHERENT_COLS) begin
                        S_candidate_xmin <= S_x_final_start;
                        S_candidate_xmax <= S_x_final_end;
                        S_candidate_width <= S_x_final_end - S_x_final_start + 9'd1;
                        // S_candidate_y* and S_candidate_height were stable
                        // throughout the column scan.  Register the upper
                        // palm search interval before SCAN_PALM consumes it.
                        S_palm_search_start_y_q <= {1'b0, S_candidate_ymin} +
                                                   {1'b0, (S_candidate_height >> 3)};
                        S_palm_search_end_y_q <= {1'b0, S_candidate_ymin} +
                                                 {1'b0, S_palm_search_offset};
                        S_gesture_scan_end_y_q <= {1'b0, S_candidate_ymin} +
                                                  {1'b0, S_gesture_scan_offset};
                        S_scan_state <= SCAN_PALM;
                        S_scan_row <= 8'd0;
                        S_palm_width <= 9'd0; S_palm_y <= S_candidate_ymin;
                        S_scan_max_runs <= 4'd0; S_open_run_streak <= 8'd0; S_open_run_best <= 8'd0;
                    end else begin
                        // A sparse scatter has no sufficiently wide column run.
                        T_update_hand_stability(1'b0);
                        T_track_miss;
                        O_candidate_valid <= 1'b0;
                        O_bbox_xmin <= 9'd0; O_bbox_xmax <= 9'd0;
                        O_bbox_ymin <= 8'd0; O_bbox_ymax <= 8'd0;
                        O_wrist_valid <= 1'b0; O_wrist_y <= 8'd0;
                        O_finger_max_runs <= 4'd0;
                        O_foreground_area <= S_raw_area;
                        O_fail_code <= FAIL_AREA;
                        O_area_ok <= 1'b0; O_aspect_ok <= 1'b0;
                        O_fill_ok <= 1'b0; O_segment_ok <= 1'b0;
                        O_result_toggle <= ~O_result_toggle;
                        S_scan_state <= SCAN_IDLE;
                    end
                end else begin
                    S_scan_col <= S_scan_col + 9'd1;
                end
            end else if(S_scan_state == SCAN_PALM) begin
                if(S_scan_row >= S_candidate_ymin && S_scan_row <= S_candidate_ymax) begin
                    // Open-palm evidence is measured only in the upper 64% of
                    // the candidate. Forearm texture or isolated lower noise
                    // must not count as finger separation.
                    if(({1'b0, S_scan_row} < S_palm_search_end_y_q)) begin
                        if(S_row_runs[S_scan_row] > S_scan_max_runs)
                            S_scan_max_runs <= S_row_runs[S_scan_row];
                        if(S_row_runs[S_scan_row] >= OPEN_PALM_MIN_RUNS) begin
                            S_open_run_streak <= S_open_run_streak + 8'd1;
                            if(S_open_run_streak >= S_open_run_best)
                                S_open_run_best <= S_open_run_streak + 8'd1;
                        end else begin
                            S_open_run_streak <= 8'd0;
                        end
                    end else begin
                        S_open_run_streak <= 8'd0;
                    end
                    // Search the upper 1/8 through approximately 64% of the
                    // robust bbox height; widened coordinates avoid overflow.
                    if(({1'b0, S_scan_row} >= S_palm_search_start_y_q) &&
                       ({1'b0, S_scan_row} < S_palm_search_end_y_q) &&
                       S_area_row_width > S_palm_width) begin
                        S_palm_width <= S_area_row_width;
                        S_palm_y <= S_scan_row;
                    end
                end
                if(S_scan_row == 8'd179) begin
                    S_scan_state <= SCAN_NECK;
                    S_scan_row <= 8'd0;
                    S_narrow_streak <= 8'd0;
                    S_scan_wrist_valid <= 1'b0;
                    S_neck_candidate_valid <= 1'b0;
                end else begin
                    S_scan_row <= S_scan_row + 8'd1;
                end
            end else if(S_scan_state == SCAN_NECK) begin
                // Stage 1: capture this row's clamped width cross-product.
                // The old implementation fed the RAM read, clamp, multiply,
                // comparison and wrist-state update through one clock path.
                S_area_row_width_x100_q <= S_area_row_width_x100;
                S_neck_scan_row_q <= S_scan_row;
                S_scan_state <= SCAN_NECK_EVAL;
            end else if(S_scan_state == SCAN_NECK_EVAL) begin
                // Stage 2: compare the registered value against the palm-width
                // thresholds.  Use the matching registered row index, not the
                // next row that will be scheduled after this evaluation.
                if(S_neck_scan_row_q > S_palm_y + (S_candidate_height >> 5) &&
                   S_neck_scan_row_q < S_candidate_ymax && S_palm_width != 0) begin
                    // Cross products use 16-bit intermediates, not truncated
                    // 9-bit products that can reverse the wrist decision.
                    if(S_area_row_width_x100_q <= S_palm_width_x72) begin
                        S_narrow_streak <= S_narrow_streak + 8'd1;
                        if(S_area_row_width_x100_q <= S_palm_width_x62 && !S_neck_candidate_valid) begin
                            S_neck_candidate_y <= S_neck_scan_row_q;
                            S_neck_candidate_valid <= 1'b1;
                        end
                        if(S_narrow_streak >= 8'd2 && S_neck_candidate_valid && !S_scan_wrist_valid) begin
                            S_scan_wrist_valid <= 1'b1;
                            S_scan_wrist_y <= S_neck_candidate_y;
                        end
                    end else begin
                        S_narrow_streak <= 8'd0;
                        S_neck_candidate_valid <= 1'b0;
                    end
                end
                if(S_neck_scan_row_q == 8'd179) begin
                    S_scan_state <= SCAN_AREA;
                    // SCAN_AREA only consumes rows inside the selected hand
                    // box.  Starting at ymin and stopping at ymax removes
                    // two wide range comparisons from S_hand_area's clock
                    // enable (the routed critical path), while preserving
                    // the exact inclusive ymin..ymax sum.
                    S_scan_row <= S_candidate_ymin;
                    S_hand_area <= 17'd0;
                    S_hand_ymax <= S_scan_wrist_valid ? S_scan_wrist_y : S_candidate_ymax;
                    S_hand_height <= (S_scan_wrist_valid ? S_scan_wrist_y : S_candidate_ymax) -
                                     S_candidate_ymin + 8'd1;
                end else begin
                    S_scan_row <= S_neck_scan_row_q + 8'd1;
                    S_scan_state <= SCAN_NECK;
                end
            end else if(S_scan_state == SCAN_AREA) begin
                S_hand_area <= S_hand_area + {8'd0, S_area_row_width};
                if(S_scan_row == S_hand_ymax) begin
                    // Separate pass for gesture statistics. Keep the row-RAM
                    // read in one state and consume the registered sample in
                    // the next state so gesture arithmetic does not lengthen
                    // the existing neck/area timing paths.
                    S_scan_state <= SCAN_GESTURE;
                    S_scan_row <= S_candidate_ymin;
                    S_gesture_run_streak_2 <= 8'd0;
                    S_gesture_run_streak_3 <= 8'd0;
                    S_gesture_run_streak_4 <= 8'd0;
                    S_gesture_run_streak_5 <= 8'd0;
                    S_gesture_best_streak_2 <= 8'd0;
                    S_gesture_best_streak_3 <= 8'd0;
                    S_gesture_best_streak_4 <= 8'd0;
                    S_gesture_best_streak_5 <= 8'd0;
                    S_gesture_narrow_streak <= 8'd0;
                    S_gesture_narrow_best <= 8'd0;
                    S_gesture_narrow_start_y <= S_candidate_ymin;
                    S_gesture_narrow_best_start_y <= S_candidate_ymin;
                    S_gesture_four_envelope_valid <= 1'b0;
                    S_gesture_four_xmin <= 9'd0; S_gesture_four_xmax <= 9'd0;
                    S_thumb_side_streak <= 8'd0; S_thumb_side_best <= 8'd0;
                    S_thumb_valley_streak <= 8'd0; S_thumb_valley_best <= 8'd0;
                    // S_palm_y is found by the existing palm-width scan, not
                    // by the bbox.  Its row edges form the shape-pass baseline.
                    S_palm_xmin <= S_row_xmin[S_palm_y];
                    S_palm_xmax <= S_row_xmax[S_palm_y];
                    S_palm_center_x <= ({1'b0, S_row_xmin[S_palm_y]} +
                                        {1'b0, S_row_xmax[S_palm_y]}) >> 1;
                    S_shape_left_streak <= 8'd0; S_shape_left_best <= 8'd0;
                    S_shape_right_streak <= 8'd0; S_shape_right_best <= 8'd0;
                    S_shape_notch_streak <= 8'd0; S_shape_notch_best <= 8'd0;
                    S_shape_l_streak <= 8'd0; S_shape_l_best <= 8'd0;
                    S_shape_hook_streak <= 8'd0; S_shape_hook_best <= 8'd0;
                    S_shape_top_narrow_seen <= 1'b0;
                    S_shape_tip_compact_seen <= 1'b0;
                    S_shape_finger_top_seen <= 1'b0;
                    S_shape_finger_mid_seen <= 1'b0;
                    S_shape_finger_bottom_seen <= 1'b0;
                    S_shape_finger_top_x <= 9'd0;
                    S_shape_finger_mid_x <= 9'd0;
                    S_shape_finger_bottom_x <= 9'd0;
                    S_hole_row_runs_q <= 4'd0;
                    S_hole_gap_valid_q <= 1'b0;
                    S_hole_gap_left_q <= 9'd0;
                    S_hole_gap_right_q <= 9'd0;
                    S_hole_row_xmin_q <= 9'd0;
                    S_hole_row_xmax_q <= 9'd0;
                    S_hole_scan_row_q <= 8'd0;
                    S_hole_active <= 1'b0;
                    S_hole_open_from_boundary <= 1'b0;
                    S_hole_closed <= 1'b0;
                    S_hole_track_left <= 9'd0;
                    S_hole_track_right <= 9'd0;
                    S_hole_track_height <= 8'd0;
                    S_hole_track_area <= 17'd0;
                end else begin
                    S_scan_row <= S_scan_row + 8'd1;
                end
            end else if(S_scan_state == SCAN_GESTURE) begin
                if({1'b0, S_scan_row} >= S_gesture_scan_end_y_q) begin
                    // Empty/very short upper scan: still run the thumb pass;
                    // without a four-finger envelope it will classify UNKNOWN.
                    S_scan_row <= S_thumb_scan_start_y[7:0];
                    S_scan_state <= SCAN_THUMB;
                end else begin
                    S_gesture_row_runs_q <= S_row_runs[S_scan_row];
                    S_gesture_row_width_q <= S_area_row_width;
                    S_gesture_row_span_q <= S_area_row_span;
                    S_gesture_scan_row_q <= S_scan_row;
                    S_scan_state <= SCAN_GESTURE_EVAL;
                end
            end else if(S_scan_state == SCAN_GESTURE_EVAL) begin
                // Classify finger count from persistent horizontal segments
                // across adjacent rows. The width/row tag is paired with the
                // registered run count; no extra pixel-path logic is added.
                // Require an exact segment count rather than >= count. In the
                // previous version a 3-run row also extended the 2-run streak,
                // while a 5-run row extended all four streaks. Tiny row totals
                // are ignored to reduce isolated mask specks.
                if(S_gesture_row_runs_q == 4'd2 &&
                   S_gesture_row_width_q >= S_gesture_min_multi_width) begin
                    if(S_gesture_run_streak_2 < 8'd180)
                        S_gesture_run_streak_2 <= S_gesture_run_streak_2 + 8'd1;
                    if((S_gesture_run_streak_2 + 8'd1) > S_gesture_best_streak_2)
                        S_gesture_best_streak_2 <= S_gesture_run_streak_2 + 8'd1;
                end else begin
                    S_gesture_run_streak_2 <= 8'd0;
                end
                if(S_gesture_row_runs_q == 4'd3 &&
                   S_gesture_row_width_q >= S_gesture_min_multi_width) begin
                    if(S_gesture_run_streak_3 < 8'd180)
                        S_gesture_run_streak_3 <= S_gesture_run_streak_3 + 8'd1;
                    if((S_gesture_run_streak_3 + 8'd1) > S_gesture_best_streak_3)
                        S_gesture_best_streak_3 <= S_gesture_run_streak_3 + 8'd1;
                end else begin
                    S_gesture_run_streak_3 <= 8'd0;
                end
                if(S_gesture_row_runs_q == 4'd4 &&
                   S_gesture_row_width_q >= S_gesture_min_multi_width) begin
                    if(S_gesture_run_streak_4 < 8'd180)
                        S_gesture_run_streak_4 <= S_gesture_run_streak_4 + 8'd1;
                    if((S_gesture_run_streak_4 + 8'd1) > S_gesture_best_streak_4)
                        S_gesture_best_streak_4 <= S_gesture_run_streak_4 + 8'd1;
                end else begin
                    S_gesture_run_streak_4 <= 8'd0;
                end
                // Build the horizontal envelope of the four upright fingers.
                // This is a per-frame extrema set, not a new frame buffer.
                if(S_gesture_row_runs_q == 4'd4 &&
                   S_gesture_row_width_q >= S_gesture_min_multi_width) begin
                    if(!S_gesture_four_envelope_valid) begin
                        S_gesture_four_envelope_valid <= 1'b1;
                        S_gesture_four_xmin <= S_row_xmin[S_gesture_scan_row_q];
                        S_gesture_four_xmax <= S_row_xmax[S_gesture_scan_row_q];
                    end else begin
                        if(S_row_xmin[S_gesture_scan_row_q] < S_gesture_four_xmin)
                            S_gesture_four_xmin <= S_row_xmin[S_gesture_scan_row_q];
                        if(S_row_xmax[S_gesture_scan_row_q] > S_gesture_four_xmax)
                            S_gesture_four_xmax <= S_row_xmax[S_gesture_scan_row_q];
                    end
                end
                if(S_gesture_row_runs_q == 4'd5 &&
                   S_gesture_row_width_q >= S_gesture_min_multi_width) begin
                    if(S_gesture_run_streak_5 < 8'd180)
                        S_gesture_run_streak_5 <= S_gesture_run_streak_5 + 8'd1;
                    if((S_gesture_run_streak_5 + 8'd1) > S_gesture_best_streak_5)
                        S_gesture_best_streak_5 <= S_gesture_run_streak_5 + 8'd1;
                end else begin
                    S_gesture_run_streak_5 <= 8'd0;
                end
                // Digit 1 is only accepted in the upper half of the silhouette,
                // as a narrow single run relative to the original open-palm
                // width. A folded fist is usually much wider than one finger.
                if(S_gesture_row_runs_q == 4'd1 &&
                   S_gesture_row_width_q <= S_gesture_one_width_max &&
                   {1'b0, S_gesture_scan_row_q} < S_gesture_one_region_end_y) begin
                    if(S_gesture_narrow_streak == 8'd0)
                        S_gesture_narrow_start_y <= S_gesture_scan_row_q;
                    if(S_gesture_narrow_streak < 8'd180)
                        S_gesture_narrow_streak <= S_gesture_narrow_streak + 8'd1;
                    if((S_gesture_narrow_streak + 8'd1) > S_gesture_narrow_best) begin
                        S_gesture_narrow_best <= S_gesture_narrow_streak + 8'd1;
                        S_gesture_narrow_best_start_y <=
                            (S_gesture_narrow_streak == 8'd0) ?
                            S_gesture_scan_row_q : S_gesture_narrow_start_y;
                    end
                end else begin
                    S_gesture_narrow_streak <= 8'd0;
                end
                // Preserve the first narrow upper stem as a directional
                // reference for later L/hook tests.  It is intentionally
                // independent of the digit-1 streak counter.
                if(!S_shape_top_narrow_seen && S_gesture_row_runs_q == 4'd1 &&
                   S_gesture_row_width_q <= S_gesture_one_width_max) begin
                    S_shape_top_narrow_seen <= 1'b1;
                    S_shape_top_xmin <= S_row_xmin[S_gesture_scan_row_q];
                    S_shape_top_xmax <= S_row_xmax[S_gesture_scan_row_q];
                end
                // Pinched 7 starts as a compact upper cluster.  It cannot
                // classify alone; the later shape pass also requires a notch.
                if(({1'b0, S_gesture_scan_row_q} <
                    ({1'b0, S_candidate_ymin} + {1'b0, (S_hand_height >> 2)})) &&
                   ((S_gesture_row_runs_q == 4'd1 &&
                     S_gesture_row_width_q <= (S_gesture_ref_width >> 2)) ||
                    (S_gesture_row_runs_q == 4'd2 &&
                     S_gesture_row_width_q <= (S_gesture_ref_width >> 1) &&
                     (S_gesture_row_span_q - S_gesture_row_width_q) >= S_shape_notch_min)))
                    S_shape_tip_compact_seen <= 1'b1;
                if(({1'b0, S_gesture_scan_row_q} + 9'd1) >= S_gesture_scan_end_y_q) begin
                    S_scan_row <= S_thumb_scan_start_y[7:0];
                    S_scan_state <= SCAN_THUMB;
                end else begin
                    S_scan_row <= S_gesture_scan_row_q + 8'd1;
                    S_scan_state <= SCAN_GESTURE;
                end
            end else if(S_scan_state == SCAN_THUMB) begin
                if(({1'b0, S_scan_row} >= S_thumb_scan_end_y) ||
                   (S_thumb_scan_start_y >= S_thumb_scan_end_y)) begin
                    S_scan_row <= S_candidate_ymin;
                    S_scan_state <= SCAN_SHAPE;
                end else begin
                    // Register the row summary before all extension comparisons.
                    S_thumb_row_runs_q <= S_row_runs[S_scan_row];
                    S_thumb_row_width_q <= S_area_row_width;
                    S_thumb_row_span_q <= S_area_row_span;
                    S_thumb_row_xmin_q <= S_row_xmin[S_scan_row];
                    S_thumb_row_xmax_q <= S_row_xmax[S_scan_row];
                    S_thumb_scan_row_q <= S_scan_row;
                    S_scan_state <= SCAN_THUMB_EVAL;
                end
            end else if(S_scan_state == SCAN_THUMB_EVAL) begin
                // A thumb is a unilateral continuation outside the four-finger
                // envelope.  Either side is legal; that makes the result
                // invariant to left/right hand and camera mirror direction.
                if(S_thumb_side_row) begin
                    if(S_thumb_side_streak < 8'd180)
                        S_thumb_side_streak <= S_thumb_side_streak + 8'd1;
                    if((S_thumb_side_streak + 8'd1) > S_thumb_side_best)
                        S_thumb_side_best <= S_thumb_side_streak + 8'd1;
                end else begin
                    S_thumb_side_streak <= 8'd0;
                end
                if(S_thumb_valley_row) begin
                    if(S_thumb_valley_streak < 8'd180)
                        S_thumb_valley_streak <= S_thumb_valley_streak + 8'd1;
                    if((S_thumb_valley_streak + 8'd1) > S_thumb_valley_best)
                        S_thumb_valley_best <= S_thumb_valley_streak + 8'd1;
                end else begin
                    S_thumb_valley_streak <= 8'd0;
                end
                if(({1'b0, S_thumb_scan_row_q} + 9'd1) >= S_thumb_scan_end_y) begin
                    S_scan_row <= S_candidate_ymin;
                    S_scan_state <= SCAN_SHAPE;
                end else begin
                    S_scan_row <= S_thumb_scan_row_q + 8'd1;
                    S_scan_state <= SCAN_THUMB;
                end
            end else if(S_scan_state == SCAN_SHAPE) begin
                if(({1'b0, S_scan_row} >= S_shape_scan_end_y) ||
                   ({1'b0, S_scan_row} > {1'b0, S_hand_ymax})) begin
                    S_scan_row <= S_hole_scan_start_y[7:0];
                    S_scan_state <= SCAN_HOLE;
                end else begin
                    S_shape_row_runs_q <= S_row_runs[S_scan_row];
                    S_shape_row_width_q <= S_area_row_width;
                    S_shape_row_span_q <= S_area_row_span;
                    S_shape_row_xmin_q <= S_row_xmin[S_scan_row];
                    S_shape_row_xmax_q <= S_row_xmax[S_scan_row];
                    S_shape_scan_row_q <= S_scan_row;
                    S_scan_state <= SCAN_SHAPE_EVAL;
                end
            end else if(S_scan_state == SCAN_SHAPE_EVAL) begin
                // Sample the centre of the narrow, single-run finger contour at
                // its top, middle and lower end.  Comparing the two adjacent
                // displacements removes uniform hand tilt from the bend test.
                if(S_shape_finger_row) begin
                    if(!S_shape_finger_top_seen) begin
                        S_shape_finger_top_seen <= 1'b1;
                        S_shape_finger_top_x    <= S_shape_row_center_x[8:0];
                    end
                    if(!S_shape_finger_mid_seen &&
                       ({1'b0, S_shape_scan_row_q} >= S_shape_finger_mid_y)) begin
                        S_shape_finger_mid_seen <= 1'b1;
                        S_shape_finger_mid_x    <= S_shape_row_center_x[8:0];
                    end
                    if({1'b0, S_shape_scan_row_q} >= S_shape_finger_mid_y) begin
                        S_shape_finger_bottom_seen <= 1'b1;
                        S_shape_finger_bottom_x    <= S_shape_row_center_x[8:0];
                    end
                end

                // Approximate directional support points: extrema outside the
                // palm row are accumulated independently for either side.
                if(S_shape_side_row && S_shape_left_out) begin
                    if(S_shape_left_streak < 8'd180) S_shape_left_streak <= S_shape_left_streak + 8'd1;
                    if((S_shape_left_streak + 8'd1) > S_shape_left_best)
                        S_shape_left_best <= S_shape_left_streak + 8'd1;
                end else S_shape_left_streak <= 8'd0;
                if(S_shape_side_row && S_shape_right_out) begin
                    if(S_shape_right_streak < 8'd180) S_shape_right_streak <= S_shape_right_streak + 8'd1;
                    if((S_shape_right_streak + 8'd1) > S_shape_right_best)
                        S_shape_right_best <= S_shape_right_streak + 8'd1;
                end else S_shape_right_streak <= 8'd0;
                // Two runs with a proportional gap are a compact approximation
                // of a convexity defect; isolated splits are rejected by streak.
                if(S_shape_notch_row) begin
                    if(S_shape_notch_streak < 8'd180) S_shape_notch_streak <= S_shape_notch_streak + 8'd1;
                    if((S_shape_notch_streak + 8'd1) > S_shape_notch_best)
                        S_shape_notch_best <= S_shape_notch_streak + 8'd1;
                end else S_shape_notch_streak <= 8'd0;
                if(S_shape_bend_row && S_shape_row_width_q >= S_shape_l_width_min) begin
                    if(S_shape_l_streak < 8'd180) S_shape_l_streak <= S_shape_l_streak + 8'd1;
                    if((S_shape_l_streak + 8'd1) > S_shape_l_best)
                        S_shape_l_best <= S_shape_l_streak + 8'd1;
                end else S_shape_l_streak <= 8'd0;
                if(S_shape_bend_row && S_shape_row_width_q >= S_shape_hook_width_min &&
                   S_shape_row_width_q < S_shape_l_width_min) begin
                    if(S_shape_hook_streak < 8'd180) S_shape_hook_streak <= S_shape_hook_streak + 8'd1;
                    if((S_shape_hook_streak + 8'd1) > S_shape_hook_best)
                        S_shape_hook_best <= S_shape_hook_streak + 8'd1;
                end else S_shape_hook_streak <= 8'd0;
                if(({1'b0, S_shape_scan_row_q} + 9'd1) >= S_shape_scan_end_y ||
                   S_shape_scan_row_q >= S_hand_ymax) begin
                    S_scan_row <= S_hole_scan_start_y[7:0];
                    S_scan_state <= SCAN_HOLE;
                end else begin
                    S_scan_row <= S_shape_scan_row_q + 8'd1;
                    S_scan_state <= SCAN_SHAPE;
                end
            end else if(S_scan_state == SCAN_HOLE) begin
                // Register one row of the existing gap cache before comparing
                // it with the previous row's interval.  This keeps row-RAM
                // addressing out of the continuity/classification logic.
                if(({1'b0, S_scan_row} >= S_hole_scan_end_y) ||
                   ({1'b0, S_scan_row} > {1'b0, S_hand_ymax})) begin
                    // A gap that reaches the scan boundary is open to the
                    // external background, not a closed hole.
                    S_hole_active <= 1'b0;
                    S_hole_open_from_boundary <= 1'b0;
                    S_scan_state <= SCAN_CONTOUR_PREP;
                end else begin
                    S_hole_row_runs_q <= S_row_runs[S_scan_row];
                    S_hole_gap_valid_q <= S_row_gap_valid[S_scan_row];
                    S_hole_gap_left_q <= S_row_gap_left[S_scan_row];
                    S_hole_gap_right_q <= S_row_gap_right[S_scan_row];
                    S_hole_row_xmin_q <= S_row_xmin[S_scan_row];
                    S_hole_row_xmax_q <= S_row_xmax[S_scan_row];
                    S_hole_scan_row_q <= S_scan_row;
                    S_scan_state <= SCAN_HOLE_EVAL;
                end
            end else if(S_scan_state == SCAN_HOLE_EVAL) begin
                if(S_hole_row_usable) begin
                    if(S_hole_active && S_hole_track_overlap) begin
                        S_hole_track_left <= S_hole_gap_left_q;
                        S_hole_track_right <= S_hole_gap_right_q;
                        if(S_hole_track_height < 8'd180)
                            S_hole_track_height <= S_hole_track_height + 8'd1;
                        S_hole_track_area <= S_hole_track_area +
                                             {8'd0, S_hole_gap_width};
                    end else begin
                        // A previous interval has closed or disconnected.
                        // Only a segment wholly internal to the scan window
                        // and large relative to the locked palm may qualify.
                        if(S_hole_active && S_hole_track_credible &&
                           S_hole_can_finish)
                            S_hole_closed <= 1'b1;
                        S_hole_active <= 1'b1;
                        S_hole_open_from_boundary <=
                            ({1'b0, S_hole_scan_row_q} <=
                             ({1'b0, S_hole_scan_start_y} +
                              {1'b0, S_hole_min_height}));
                        S_hole_track_left <= S_hole_gap_left_q;
                        S_hole_track_right <= S_hole_gap_right_q;
                        S_hole_track_height <= 8'd1;
                        S_hole_track_area <= {8'd0, S_hole_gap_width};
                    end
                end else if(S_hole_active) begin
                    // The candidate has a real vertical closing boundary.
                    if(S_hole_track_credible && S_hole_can_finish)
                        S_hole_closed <= 1'b1;
                    S_hole_active <= 1'b0;
                    S_hole_open_from_boundary <= 1'b0;
                end

                if(({1'b0, S_hole_scan_row_q} + 9'd1 >= S_hole_scan_end_y) ||
                   S_hole_scan_row_q >= S_hand_ymax) begin
                    // Do not commit an interval that survives through the
                    // lower scan boundary: it remains externally connected.
                    S_hole_active <= 1'b0;
                    S_hole_open_from_boundary <= 1'b0;
                    S_scan_state <= SCAN_CONTOUR_PREP;
                end else begin
                    S_scan_row <= S_hole_scan_row_q + 8'd1;
                    S_scan_state <= SCAN_HOLE;
                end
            end else if(S_scan_state == SCAN_CONTOUR_PREP) begin
                // Extract only true boundary pixels from the selected hand,
                // not a full raster. Eight-row decimation bounds the outer
                // pair plus first-gap pair at 92 points for a 180-line frame.
                S_contour_point_count <= 8'd0;
                S_contour_overflow <= 1'b0;
                S_hull_vertex_count <= 5'd0;
                S_hull_overflow <= 1'b0;
                S_hull_valid <= 1'b0;
                S_defect_count <= 4'd0;
                S_defect_max_cross <= 22'd0;
                S_scan_row <= S_candidate_ymin;
                S_scan_state <= SCAN_CONTOUR_EXTRACT;
            end else if(S_scan_state == SCAN_CONTOUR_EXTRACT) begin
                if(S_scan_row > S_hand_ymax) begin
                    if((S_contour_point_count >= 8'd3) && !S_contour_overflow)
                        S_scan_state <= SCAN_HULL_START;
                    else
                        S_scan_state <= SCAN_CLASSIFY_PREP;
                end else begin
                    if((S_scan_row[2:0] == 3'd0) &&
                       (S_row_width[S_scan_row] >= ROW_ACTIVITY_MIN)) begin
                        if(S_row_gap_valid[S_scan_row] &&
                           (S_contour_point_count <= 8'd124)) begin
                            S_contour_x[S_contour_point_count] <= S_row_xmin[S_scan_row];
                            S_contour_y[S_contour_point_count] <= S_scan_row;
                            S_contour_x[S_contour_point_count + 8'd1] <= S_row_xmax[S_scan_row];
                            S_contour_y[S_contour_point_count + 8'd1] <= S_scan_row;
                            S_contour_x[S_contour_point_count + 8'd2] <= S_row_gap_left[S_scan_row];
                            S_contour_y[S_contour_point_count + 8'd2] <= S_scan_row;
                            S_contour_x[S_contour_point_count + 8'd3] <= S_row_gap_right[S_scan_row];
                            S_contour_y[S_contour_point_count + 8'd3] <= S_scan_row;
                            S_contour_point_count <= S_contour_point_count + 8'd4;
                        end else if(!S_row_gap_valid[S_scan_row] &&
                                    (S_contour_point_count <= 8'd126)) begin
                            S_contour_x[S_contour_point_count] <= S_row_xmin[S_scan_row];
                            S_contour_y[S_contour_point_count] <= S_scan_row;
                            S_contour_x[S_contour_point_count + 8'd1] <= S_row_xmax[S_scan_row];
                            S_contour_y[S_contour_point_count + 8'd1] <= S_scan_row;
                            S_contour_point_count <= S_contour_point_count + 8'd2;
                        end else begin
                            // Never silently truncate: geometry is invalid for
                            // this frame and classifier fusion will return --.
                            S_contour_overflow <= 1'b1;
                        end
                    end
                    S_scan_row <= S_scan_row + 8'd1;
                end
            end else if(S_scan_state == SCAN_HULL_START) begin
                S_hull_point_index <= 8'd0;
                S_hull_start_index <= 8'd0;
                S_hull_start_x_q <= 9'd0;
                S_hull_start_y_q <= 8'd0;
                S_scan_state <= SCAN_HULL_FIND_START;
            end else if(S_scan_state == SCAN_HULL_FIND_START) begin
                // Stage 1: capture the dynamically addressed contour point.
                // The X/Y comparison and S_hull_start_index clock-enable are
                // deliberately deferred to the following cycle.
                if(S_hull_point_index < S_contour_point_count) begin
                    S_hull_find_point_x_q <= S_contour_x[S_hull_point_index];
                    S_hull_find_point_y_q <= S_contour_y[S_hull_point_index];
                    S_scan_state <= SCAN_HULL_FIND_START_EVAL;
                end else begin
                    S_hull_current_index <= S_hull_start_index;
                    S_hull_vertex_count <= 5'd0;
                    S_scan_state <= SCAN_HULL_BEGIN_EDGE;
                end
            end else if(S_scan_state == SCAN_HULL_FIND_START_EVAL) begin
                // Stage 2: preserve the original Jarvis start rule exactly:
                // lower X wins; for equal X, lower Y wins.  Point zero becomes
                // the initial incumbent before any comparison is evaluated.
                if(S_hull_point_index == 8'd0) begin
                    S_hull_start_index <= 8'd0;
                    S_hull_start_x_q <= S_hull_find_point_x_q;
                    S_hull_start_y_q <= S_hull_find_point_y_q;
                end else if((S_hull_find_point_x_q < S_hull_start_x_q) ||
                            ((S_hull_find_point_x_q == S_hull_start_x_q) &&
                             (S_hull_find_point_y_q < S_hull_start_y_q))) begin
                    S_hull_start_index <= S_hull_point_index;
                    S_hull_start_x_q <= S_hull_find_point_x_q;
                    S_hull_start_y_q <= S_hull_find_point_y_q;
                end
                // Advance only after this registered point is considered.
                // Thus indices 0 through point_count-1 are each tested once.
                S_hull_point_index <= S_hull_point_index + 8'd1;
                S_scan_state <= SCAN_HULL_FIND_START;
            end else if(S_scan_state == SCAN_HULL_BEGIN_EDGE) begin
                if(S_hull_vertex_count >= HULL_VERTEX_MAX) begin
                    S_hull_overflow <= 1'b1;
                    S_scan_state <= SCAN_CLASSIFY_PREP;
                end else begin
                    S_hull_x[S_hull_vertex_count] <= S_contour_x[S_hull_current_index];
                    S_hull_y[S_hull_vertex_count] <= S_contour_y[S_hull_current_index];
                    S_hull_vertex_count <= S_hull_vertex_count + 5'd1;
                    S_hull_candidate_index <= (S_hull_current_index == 8'd0) ? 8'd1 : 8'd0;
                    S_hull_current_x_q <= S_contour_x[S_hull_current_index];
                    S_hull_current_y_q <= S_contour_y[S_hull_current_index];
                    S_hull_candidate_x_q <= S_contour_x[(S_hull_current_index == 8'd0) ? 8'd1 : 8'd0];
                    S_hull_candidate_y_q <= S_contour_y[(S_hull_current_index == 8'd0) ? 8'd1 : 8'd0];
                    S_hull_point_index <= 8'd0;
                    S_scan_state <= SCAN_HULL_SCAN_NEXT;
                end
            end else if(S_scan_state == SCAN_HULL_SCAN_NEXT) begin
                if(S_hull_point_index >= S_contour_point_count) begin
                    S_scan_state <= SCAN_HULL_COMPLETE_EDGE;
                end else if(S_hull_point_index == S_hull_current_index) begin
                    S_hull_point_index <= S_hull_point_index + 8'd1;
                end else begin
                    S_hull_ab_x <= $signed({1'b0, S_hull_candidate_x_q}) -
                                   $signed({1'b0, S_hull_current_x_q});
                    S_hull_ab_y <= $signed({1'b0, S_hull_candidate_y_q}) -
                                   $signed({1'b0, S_hull_current_y_q});
                    S_hull_ap_x <= $signed({1'b0, S_contour_x[S_hull_point_index]}) -
                                   $signed({1'b0, S_hull_current_x_q});
                    S_hull_ap_y <= $signed({1'b0, S_contour_y[S_hull_point_index]}) -
                                   $signed({1'b0, S_hull_current_y_q});
                    S_geom_mul_a <= $signed({1'b0, S_hull_candidate_x_q}) -
                                     $signed({1'b0, S_hull_current_x_q});
                    S_geom_mul_b <= $signed({1'b0, S_contour_y[S_hull_point_index]}) -
                                     $signed({1'b0, S_hull_current_y_q});
                    S_scan_state <= SCAN_HULL_CROSS_A;
                end
            end else if(S_scan_state == SCAN_HULL_CROSS_A) begin
                S_hull_cross_a <= S_geom_mul_product;
                S_geom_mul_a <= S_hull_ab_y;
                S_geom_mul_b <= S_hull_ap_x;
                S_scan_state <= SCAN_HULL_CROSS_B;
            end else if(S_scan_state == SCAN_HULL_CROSS_B) begin
                // Stage 1: capture the cross result and both Manhattan
                // distances.  The absolute-value/add chain ends at these
                // registers rather than feeding the candidate-index mux.
                S_hull_cross_negative_q <= (S_hull_cross_signed < 23'sd0);
                S_hull_cross_zero_q <= (S_hull_cross_signed == 23'sd0);
                S_hull_candidate_manhattan_q <= S_hull_candidate_manhattan;
                S_hull_point_manhattan_q <= S_hull_point_manhattan;
                S_scan_state <= SCAN_HULL_DECIDE;
            end else if(S_scan_state == SCAN_HULL_DECIDE) begin
                // Stage 2: resolve the orientation/collinear tie using only
                // registered values.  A separate result register isolates the
                // comparator from the index and contour-address fanout.
                S_hull_replace_q <= S_hull_cross_negative_q ||
                    (S_hull_cross_zero_q &&
                     (S_hull_point_manhattan_q > S_hull_candidate_manhattan_q));
                S_scan_state <= SCAN_HULL_COMMIT_CANDIDATE;
            end else if(S_scan_state == SCAN_HULL_COMMIT_CANDIDATE) begin
                // Stage 3: commit the exact same selected point.  Candidate
                // coordinates advance with its index, preserving alignment for
                // the next Jarvis comparison without rereading that index.
                if(S_hull_replace_q) begin
                    S_hull_candidate_index <= S_hull_point_index;
                    S_hull_candidate_x_q <= S_contour_x[S_hull_point_index];
                    S_hull_candidate_y_q <= S_contour_y[S_hull_point_index];
                end
                S_hull_point_index <= S_hull_point_index + 8'd1;
                S_scan_state <= SCAN_HULL_SCAN_NEXT;
            end else if(S_scan_state == SCAN_HULL_COMPLETE_EDGE) begin
                if(S_hull_candidate_index == S_hull_start_index) begin
                    S_hull_valid <= 1'b1;
                    S_scan_state <= SCAN_DEFECT_PREP;
                end else begin
                    S_hull_current_index <= S_hull_candidate_index;
                    S_scan_state <= SCAN_HULL_BEGIN_EDGE;
                end
            end else if(S_scan_state == SCAN_DEFECT_PREP) begin
                if(S_hull_vertex_count < 5'd3) begin
                    S_hull_valid <= 1'b0;
                    S_scan_state <= SCAN_CLASSIFY_PREP;
                end else begin
                    S_defect_edge_index <= 5'd0;
                    S_defect_point_index <= 8'd0;
                    S_defect_count <= 4'd0;
                    S_defect_max_cross <= 22'd0;
                    S_defect_best_cross <= 22'd0;
                    S_scan_state <= SCAN_DEFECT_POINT_LOAD;
                end
            end else if(S_scan_state == SCAN_DEFECT_POINT_LOAD) begin
                if(S_defect_point_index >= S_contour_point_count) begin
                    S_scan_state <= SCAN_DEFECT_EDGE_COMMIT;
                end else begin
                    S_defect_ab_x <= $signed({1'b0,
                        S_hull_x[((S_defect_edge_index + 5'd1) >= S_hull_vertex_count) ?
                                 4'd0 : (S_defect_edge_index + 5'd1)]}) -
                                     $signed({1'b0, S_hull_x[S_defect_edge_index]});
                    S_defect_ab_y <= $signed({1'b0,
                        S_hull_y[((S_defect_edge_index + 5'd1) >= S_hull_vertex_count) ?
                                 4'd0 : (S_defect_edge_index + 5'd1)]}) -
                                     $signed({1'b0, S_hull_y[S_defect_edge_index]});
                    S_defect_ap_x <= $signed({1'b0, S_contour_x[S_defect_point_index]}) -
                                     $signed({1'b0, S_hull_x[S_defect_edge_index]});
                    S_defect_ap_y <= $signed({1'b0, S_contour_y[S_defect_point_index]}) -
                                     $signed({1'b0, S_hull_y[S_defect_edge_index]});
                    S_geom_mul_a <= $signed({1'b0,
                        S_hull_x[((S_defect_edge_index + 5'd1) >= S_hull_vertex_count) ?
                                 4'd0 : (S_defect_edge_index + 5'd1)]}) -
                                    $signed({1'b0, S_hull_x[S_defect_edge_index]});
                    S_geom_mul_b <= $signed({1'b0, S_contour_y[S_defect_point_index]}) -
                                    $signed({1'b0, S_hull_y[S_defect_edge_index]});
                    S_scan_state <= SCAN_DEFECT_CROSS_A;
                end
            end else if(S_scan_state == SCAN_DEFECT_CROSS_A) begin
                S_defect_cross_a <= S_geom_mul_product;
                S_geom_mul_a <= S_defect_ab_y;
                S_geom_mul_b <= S_defect_ap_x;
                S_scan_state <= SCAN_DEFECT_CROSS_B;
            end else if(S_scan_state == SCAN_DEFECT_CROSS_B) begin
                S_defect_cross_b <= S_geom_mul_product;
                S_geom_mul_a <= S_defect_ab_x;
                S_geom_mul_b <= S_defect_ap_x;
                S_scan_state <= SCAN_DEFECT_DOT_A;
            end else if(S_scan_state == SCAN_DEFECT_DOT_A) begin
                S_defect_dot_a <= S_geom_mul_product;
                S_geom_mul_a <= S_defect_ab_y;
                S_geom_mul_b <= S_defect_ap_y;
                S_scan_state <= SCAN_DEFECT_DOT_B;
            end else if(S_scan_state == SCAN_DEFECT_DOT_B) begin
                S_defect_dot_b <= S_geom_mul_product;
                S_geom_mul_a <= S_defect_ab_x;
                S_geom_mul_b <= S_defect_ab_x;
                S_scan_state <= SCAN_DEFECT_LEN_A;
            end else if(S_scan_state == SCAN_DEFECT_LEN_A) begin
                S_defect_len_a <= S_geom_mul_product;
                S_geom_mul_a <= S_defect_ab_y;
                S_geom_mul_b <= S_defect_ab_y;
                S_scan_state <= SCAN_DEFECT_LEN_B;
            end else if(S_scan_state == SCAN_DEFECT_LEN_B) begin
                S_defect_len_b <= S_geom_mul_product;
                S_geom_mul_a <= $signed({1'b0, S_defect_edge_manhattan[9:0]});
                S_geom_mul_b <= $signed({1'b0, S_defect_depth_min});
                S_scan_state <= SCAN_DEFECT_THRESHOLD;
            end else if(S_scan_state == SCAN_DEFECT_THRESHOLD) begin
                S_defect_threshold_q <= S_geom_mul_product;
                S_scan_state <= SCAN_DEFECT_EVAL;
            end else if(S_scan_state == SCAN_DEFECT_EVAL) begin
                // Cross magnitude is a true signed point-to-hull-edge
                // distance numerator.  The dot-product test confines it to
                // the finite edge; the Manhattan-scaled threshold normalizes
                // depth without division or square root.
                if(S_defect_projected_on_edge &&
                   (S_defect_cross_abs >= S_defect_threshold_q) &&
                   (S_defect_cross_abs > S_defect_best_cross)) begin
                    S_defect_best_cross <= S_defect_cross_abs;
                    S_defect_best_x <= S_contour_x[S_defect_point_index];
                    S_defect_best_y <= S_contour_y[S_defect_point_index];
                end
                S_defect_point_index <= S_defect_point_index + 8'd1;
                S_scan_state <= SCAN_DEFECT_POINT_LOAD;
            end else if(S_scan_state == SCAN_DEFECT_EDGE_COMMIT) begin
                if(S_defect_best_cross != 22'd0) begin
                    if(S_defect_count != 4'hf)
                        S_defect_count <= S_defect_count + 4'd1;
                    if(S_defect_best_cross > S_defect_max_cross) begin
                        S_defect_max_cross <= S_defect_best_cross;
                        S_defect_deepest_x <= S_defect_best_x;
                        S_defect_deepest_y <= S_defect_best_y;
                    end
                end
                if((S_defect_edge_index + 5'd1) >= S_hull_vertex_count) begin
                    S_scan_state <= SCAN_HULL_FEATURE_PREP;
                end else begin
                    S_defect_edge_index <= S_defect_edge_index + 5'd1;
                    S_defect_point_index <= 8'd0;
                    S_defect_best_cross <= 22'd0;
                    S_scan_state <= SCAN_DEFECT_POINT_LOAD;
                end
            end else if(S_scan_state == SCAN_HULL_FEATURE_PREP) begin
                S_hull_feature_index <= 5'd0;
                S_hull_upper_count <= 4'd0;
                S_hull_left_count <= 4'd0;
                S_hull_right_count <= 4'd0;
                S_hull_top_seen <= 1'b0;
                S_hull_top_y <= 8'd0;
                S_hull_center_top_seen <= 1'b0;
                S_hull_center_top_y <= 8'd0;
                S_scan_state <= SCAN_HULL_FEATURE;
            end else if(S_scan_state == SCAN_HULL_FEATURE) begin
                if(S_hull_feature_index >= S_hull_vertex_count) begin
                    S_scan_state <= SCAN_CLASSIFY_PREP;
                end else begin
                    if(S_hull_feature_upper && S_hull_upper_count != 4'hf)
                        S_hull_upper_count <= S_hull_upper_count + 4'd1;
                    if(S_hull_feature_left && S_hull_left_count != 4'hf)
                        S_hull_left_count <= S_hull_left_count + 4'd1;
                    if(S_hull_feature_right && S_hull_right_count != 4'hf)
                        S_hull_right_count <= S_hull_right_count + 4'd1;
                    if(S_hull_feature_upper &&
                       (!S_hull_top_seen || (S_hull_feature_y < S_hull_top_y))) begin
                        S_hull_top_seen <= 1'b1;
                        S_hull_top_y <= S_hull_feature_y;
                    end
                    if(S_hull_feature_center &&
                       (!S_hull_center_top_seen ||
                        (S_hull_feature_y < S_hull_center_top_y))) begin
                        S_hull_center_top_seen <= 1'b1;
                        S_hull_center_top_y <= S_hull_feature_y;
                    end
                    S_hull_feature_index <= S_hull_feature_index + 5'd1;
                end
            end else if(S_scan_state == SCAN_CLASSIFY_PREP) begin
                // Snapshot all frame statistics before classification.
                S_class_hand_area <= S_hand_area;
                S_class_raw_width <= S_candidate_width;
                S_class_hand_height <= S_hand_height;
                S_class_hand_bbox_area <= S_hand_bbox_area;
                S_class_raw_xmin <= S_candidate_xmin; S_class_raw_xmax <= S_candidate_xmax;
                S_class_raw_ymin <= S_candidate_ymin; S_class_hand_ymax <= S_hand_ymax;
                S_class_wrist_valid <= S_scan_wrist_valid;
                S_class_wrist_y <= S_scan_wrist_y;
                S_class_scan_max_runs <= S_scan_max_runs;
                S_class_open_run_best <= S_open_run_best;
                S_class_gesture_code <= S_gesture_candidate_code;
                S_scan_state <= SCAN_CLASSIFY_EVAL;
            end else if(S_scan_state == SCAN_CLASSIFY_EVAL) begin
                // Full-width cross-products keep all geometry comparisons exact.
                S_class_area_ok <= (S_class_hand_area >= MIN_AREA) &&
                                   (S_class_hand_area <= MAX_AREA);
                S_class_aspect_low_ok <= (S_class_width_x100 >= S_class_height_x28);
                S_class_aspect_high_ok <= (S_class_width_x100 <= S_class_height_x350);
                S_class_fill_low_ok <= (S_class_hand_area_x100 >= S_class_bbox_area_x24);
                S_class_fill_high_ok <= (S_class_hand_area_x100 <= S_class_bbox_area_x86);
                // Box display has a looser 8% occupancy gate than HAND's 24..86%
                // fill range, allowing plausible NOT_HAND objects to be shown.
                S_class_candidate_density_ok <= (S_class_hand_bbox_area != 0) &&
                                                (S_class_hand_area_x100 >= S_class_bbox_area_x8);
                S_class_runs_ok <= (S_class_scan_max_runs >= OPEN_PALM_MIN_RUNS);
                S_class_run_streak_ok <= (S_class_open_run_best >= OPEN_PALM_MIN_RUN_STREAK);
                S_scan_state <= SCAN_CLASSIFY_COMMIT;
            end else begin // SCAN_CLASSIFY_COMMIT
                // This is intentionally an OPEN-PALM classifier: a fist is
                // a hand anatomically, but is NOT a positive target here. A
                // valid wrist/neck plus repeated separated runs in the upper
                // silhouette are both required before the result can be OPEN.
                T_update_hand_stability(S_raw_open_palm);
                // SEARCH/CONFIRM require strict OPEN_PALM.  LOCKED/LOST use
                // only S_track_match; strict segmentation is intentionally not
                // a lock-retention requirement.
                if(O_track_state == TRACK_SEARCH) begin
                    O_lock_valid <= 1'b0;
                    O_lost_count <= 4'd0;
                    S_open_palm_width_ref <= 9'd0;
                    if(S_raw_open_palm) begin
                        O_track_state <= TRACK_CONFIRM;
                        O_confirm_count <= 4'd1;
                        S_lock_xmin <= S_class_raw_xmin; S_lock_xmax <= S_class_raw_xmax;
                        S_lock_ymin <= S_class_raw_ymin; S_lock_ymax <= S_class_hand_ymax;
                        S_lock_area <= S_class_hand_area;
                        O_candidate_valid <= 1'b1;
                        O_bbox_xmin <= S_class_raw_xmin; O_bbox_xmax <= S_class_raw_xmax;
                        O_bbox_ymin <= S_class_raw_ymin; O_bbox_ymax <= S_class_hand_ymax;
                    end else begin
                        O_confirm_count <= 4'd0;
                        O_candidate_valid <= 1'b0;
                        O_bbox_xmin <= 9'd0; O_bbox_xmax <= 9'd0;
                        O_bbox_ymin <= 8'd0; O_bbox_ymax <= 8'd0;
                    end
                end else if(O_track_state == TRACK_CONFIRM) begin
                    O_lost_count <= 4'd0;
                    if(S_raw_open_palm && S_track_match) begin
                        S_lock_xmin <= S_class_raw_xmin; S_lock_xmax <= S_class_raw_xmax;
                        S_lock_ymin <= S_class_raw_ymin; S_lock_ymax <= S_class_hand_ymax;
                        S_lock_area <= S_class_hand_area;
                        O_candidate_valid <= 1'b1;
                        O_bbox_xmin <= S_class_raw_xmin; O_bbox_xmax <= S_class_raw_xmax;
                        O_bbox_ymin <= S_class_raw_ymin; O_bbox_ymax <= S_class_hand_ymax;
                        if(O_confirm_count >= (LOCK_CONFIRM_FRAMES - 4'd1)) begin
                            O_track_state <= TRACK_LOCKED;
                            O_lock_valid <= 1'b1;
                            O_confirm_count <= LOCK_CONFIRM_FRAMES;
                            S_open_palm_width_ref <= S_class_raw_width;
                        end else begin
                            O_confirm_count <= O_confirm_count + 4'd1;
                        end
                    end else if(S_raw_open_palm) begin
                        // A new distant open palm restarts the confirmation
                        // reference instead of joining two unrelated targets.
                        O_confirm_count <= 4'd1;
                        S_lock_xmin <= S_class_raw_xmin; S_lock_xmax <= S_class_raw_xmax;
                        S_lock_ymin <= S_class_raw_ymin; S_lock_ymax <= S_class_hand_ymax;
                        S_lock_area <= S_class_hand_area;
                        O_candidate_valid <= 1'b1;
                        O_bbox_xmin <= S_class_raw_xmin; O_bbox_xmax <= S_class_raw_xmax;
                        O_bbox_ymin <= S_class_raw_ymin; O_bbox_ymax <= S_class_hand_ymax;
                    end else begin
                        O_track_state <= TRACK_SEARCH;
                        O_lock_valid <= 1'b0;
                        O_confirm_count <= 4'd0;
                        S_open_palm_width_ref <= 9'd0;
                        O_candidate_valid <= 1'b0;
                        O_bbox_xmin <= 9'd0; O_bbox_xmax <= 9'd0;
                        O_bbox_ymin <= 8'd0; O_bbox_ymax <= 8'd0;
                    end
                end else if(O_track_state == TRACK_LOCKED) begin
                    O_confirm_count <= LOCK_CONFIRM_FRAMES;
                    if(S_track_match) begin
                        // Only classify a digit after the original open palm
                        // has been locked. Keep the previous digit during a
                        // short transition, and publish a new one only after
                        // three consecutive frame classifications agree.
                        if(S_fused_frame_gesture_code != GESTURE_NONE) begin
                            S_gesture_unknown_streak <= 3'd0;
                            if(S_fused_frame_gesture_code == S_gesture_pending_code) begin
                                if(S_gesture_pending_streak < GESTURE_CONFIRM_FRAMES)
                                    S_gesture_pending_streak <= S_gesture_pending_streak + 2'd1;
                                if(S_gesture_pending_streak >= (GESTURE_CONFIRM_FRAMES - 2'd1)) begin
                                    O_gesture_valid <= 1'b1;
                                    O_gesture_code <= S_fused_frame_gesture_code;
                                end
                            end else begin
                                S_gesture_pending_code <= S_fused_frame_gesture_code;
                                S_gesture_pending_streak <= 2'd1;
                            end
                        end else begin
                            S_gesture_pending_code <= GESTURE_NONE;
                            S_gesture_pending_streak <= 2'd0;
                            if(S_gesture_unknown_streak < GESTURE_UNKNOWN_CLEAR_FRAMES)
                                S_gesture_unknown_streak <= S_gesture_unknown_streak + 3'd1;
                            if(S_gesture_unknown_streak >= (GESTURE_UNKNOWN_CLEAR_FRAMES - 3'd1)) begin
                                O_gesture_valid <= 1'b0;
                                O_gesture_code <= 3'd0;
                            end
                        end
                        S_lock_xmin <= S_class_raw_xmin; S_lock_xmax <= S_class_raw_xmax;
                        S_lock_ymin <= S_class_raw_ymin; S_lock_ymax <= S_class_hand_ymax;
                        S_lock_area <= S_class_hand_area;
                        O_lost_count <= 4'd0;
                        O_candidate_valid <= 1'b1;
                        O_bbox_xmin <= S_class_raw_xmin; O_bbox_xmax <= S_class_raw_xmax;
                        O_bbox_ymin <= S_class_raw_ymin; O_bbox_ymax <= S_class_hand_ymax;
                    end else begin
                        O_track_state <= TRACK_LOST;
                        O_lost_count <= 4'd1;
                        O_gesture_valid <= 1'b0;
                        O_gesture_code <= 3'd0;
                        S_gesture_pending_code <= GESTURE_NONE;
                        S_gesture_pending_streak <= 2'd0;
                        S_gesture_unknown_streak <= 3'd0;
                        // Do not draw an old box while waiting for loss
                        // confirmation; the lock reference remains private.
                        O_candidate_valid <= 1'b0;
                        O_bbox_xmin <= 9'd0; O_bbox_xmax <= 9'd0;
                        O_bbox_ymin <= 8'd0; O_bbox_ymax <= 8'd0;
                    end
                end else begin // TRACK_LOST
                    if(S_track_match) begin
                        O_track_state <= TRACK_LOCKED;
                        O_lost_count <= 4'd0;
                        S_lock_xmin <= S_class_raw_xmin; S_lock_xmax <= S_class_raw_xmax;
                        S_lock_ymin <= S_class_raw_ymin; S_lock_ymax <= S_class_hand_ymax;
                        S_lock_area <= S_class_hand_area;
                        O_candidate_valid <= 1'b1;
                        O_bbox_xmin <= S_class_raw_xmin; O_bbox_xmax <= S_class_raw_xmax;
                        O_bbox_ymin <= S_class_raw_ymin; O_bbox_ymax <= S_class_hand_ymax;
                    end else if(O_lost_count >= (LOCK_LOST_FRAMES - 4'd1)) begin
                        O_track_state <= TRACK_SEARCH;
                        O_lock_valid <= 1'b0;
                        O_confirm_count <= 4'd0; O_lost_count <= 4'd0;
                        S_lock_xmin <= 9'd0; S_lock_xmax <= 9'd0;
                        S_lock_ymin <= 8'd0; S_lock_ymax <= 8'd0; S_lock_area <= 17'd0;
                        S_open_palm_width_ref <= 9'd0;
                        O_candidate_valid <= 1'b0;
                        O_bbox_xmin <= 9'd0; O_bbox_xmax <= 9'd0;
                        O_bbox_ymin <= 8'd0; O_bbox_ymax <= 8'd0;
                    end else begin
                        O_lost_count <= O_lost_count + 4'd1;
                        O_candidate_valid <= 1'b0;
                        O_bbox_xmin <= 9'd0; O_bbox_xmax <= 9'd0;
                        O_bbox_ymin <= 8'd0; O_bbox_ymax <= 8'd0;
                    end
                end
                // Publish the completed scan evidence with the frame result.
                // These are diagnostics only; they are not fed back into the
                // pixel path or the locking state machine.
                O_gesture_candidate_code <= S_class_gesture_code;
                O_gesture_best_streak_2 <= S_gesture_best_streak_2;
                O_gesture_best_streak_3 <= S_gesture_best_streak_3;
                O_gesture_best_streak_4 <= S_gesture_best_streak_4;
                O_gesture_best_streak_5 <= S_gesture_best_streak_5;
                O_gesture_narrow_best <= S_gesture_narrow_best;
                O_wrist_valid <= S_class_wrist_valid;
                O_wrist_y <= S_class_wrist_y;
                O_finger_max_runs <= S_class_scan_max_runs;
                O_foreground_area <= S_raw_area;
                O_area_ok <= S_class_area_ok;
                O_aspect_ok <= S_class_aspect_low_ok && S_class_aspect_high_ok;
                O_fill_ok <= S_class_fill_low_ok && S_class_fill_high_ok;
                O_segment_ok <= S_class_runs_ok && S_class_run_streak_ok;
                if(S_class_area_ok && S_class_aspect_low_ok &&
                   S_class_aspect_high_ok && S_class_fill_low_ok &&
                   S_class_fill_high_ok && S_class_wrist_valid &&
                   S_class_runs_ok && S_class_run_streak_ok)
                    O_fail_code <= FAIL_NONE;
                else if(!S_class_area_ok)
                    O_fail_code <= FAIL_AREA;
                else if(!S_class_aspect_low_ok || !S_class_aspect_high_ok)
                    O_fail_code <= FAIL_ASPECT;
                else if(!S_class_fill_low_ok || !S_class_fill_high_ok)
                    O_fail_code <= FAIL_FILL;
                else if(!S_class_wrist_valid)
                    O_fail_code <= FAIL_WRIST;
                else if(!S_class_runs_ok || !S_class_run_streak_ok)
                    O_fail_code <= FAIL_SEG;
                else
                    O_fail_code <= FAIL_OTHER;
                // A result is deliberately single-use.  If a new matcher
                // event arrived in this same cycle, preserve that newer event
                // for the next completed scan rather than clearing it here.
                if(S_template_result_pending && !S_template_result_new)
                    S_template_result_pending <= 1'b0;
                O_result_toggle <= ~O_result_toggle;
                S_scan_state <= SCAN_IDLE;
            end
        end
    end
endmodule

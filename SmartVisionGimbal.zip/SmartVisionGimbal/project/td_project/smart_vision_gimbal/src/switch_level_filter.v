// Debounce a board slide switch and expose its stable logic level.
// SW1/SW2 are documented as low when down and high when up.
module switch_level_filter #(
    parameter [19:0] DEBOUNCE_CYCLES = 20'd1000000
) (
    input  wire I_clk,
    input  wire I_rst_n,
    input  wire I_switch,
    output reg  O_level
);
    reg [1:0] S_sync;
    reg [19:0] S_count;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            S_sync <= 2'b00;
            S_count <= 20'd0;
            O_level <= 1'b0;
        end else begin
            S_sync <= {S_sync[0], I_switch};
            if (S_sync[1] == O_level) begin
                S_count <= 20'd0;
            end else if (S_count == DEBOUNCE_CYCLES - 20'd1) begin
                O_level <= S_sync[1];
                S_count <= 20'd0;
            end else begin
                S_count <= S_count + 20'd1;
            end
        end
    end
endmodule

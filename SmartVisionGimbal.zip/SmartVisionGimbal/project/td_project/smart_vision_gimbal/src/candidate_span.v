// Find the highest-scoring dense foreground span in sampled pixels.
module candidate_span (
    input  wire       I_clk,
    input  wire       I_rst_n,
    input  wire       I_frame_ready,
    input  wire [7:0] I_column_count,
    output reg  [8:0] O_read_x,
    output reg        O_done,
    output reg        O_candidate_valid,
    output reg  [8:0] O_left,
    output reg  [8:0] O_right
);
    localparam [3:0] IDLE = 4'd0, MAX_WAIT_1 = 4'd1,
                     MAX_WAIT_2 = 4'd2, FIND_MAX = 4'd3,
                     THRESHOLD_LATCH = 4'd4, SPAN_WAIT_1 = 4'd5,
                     SPAN_WAIT_2 = 4'd6, FIND_SPAN = 4'd7;
    reg [3:0] state;
    reg seen_ready;
    reg [7:0] maximum;
    reg [7:0] threshold_reg;
    reg [15:0] run_score;
    reg [15:0] best_score;
    reg [8:0] run_start;
    reg [8:0] best_left;
    reg [8:0] best_right;
    reg in_run;
    reg best_valid;
    wire [9:0] scaled_maximum = {2'b00, maximum} * 10'd3;
    wire [7:0] relative_threshold = scaled_maximum / 10'd10;
    wire [7:0] threshold = (relative_threshold > 8'd20) ?
                           relative_threshold : 8'd20;
    wire active = I_column_count >= threshold_reg;
    wire [15:0] final_score = in_run ? run_score + I_column_count :
                              {8'd0, I_column_count};
    wire [8:0] final_start = in_run ? run_start : O_read_x;
    wire close_run = in_run && !active;
    wire close_last = (O_read_x == 9'd319) && active;
    wire [8:0] close_start = close_last ? final_start : run_start;
    wire [8:0] close_end = close_last ? 9'd320 : O_read_x;
    wire [15:0] close_score = close_last ? final_score : run_score;
    wire better_span = (close_run || close_last) &&
                       (close_end - close_start >= 9'd8) &&
                       (!best_valid || close_score > best_score);
    wire [8:0] winning_left = better_span ? close_start : best_left;
    wire [8:0] winning_right = better_span ? close_end : best_right;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            state <= IDLE;
            seen_ready <= 1'b0;
            O_read_x <= 9'd0;
            O_done <= 1'b0;
            O_candidate_valid <= 1'b0;
            O_left <= 9'd0;
            O_right <= 9'd0;
            maximum <= 8'd0;
            threshold_reg <= 8'd20;
            run_score <= 16'd0;
            best_score <= 16'd0;
            run_start <= 9'd0;
            best_left <= 9'd0;
            best_right <= 9'd0;
            in_run <= 1'b0;
            best_valid <= 1'b0;
        end else begin
            O_done <= 1'b0;
            if (!I_frame_ready)
                seen_ready <= 1'b0;
            case (state)
                IDLE: if (I_frame_ready && !seen_ready) begin
                    seen_ready <= 1'b1;
                    O_read_x <= 9'd0;
                    maximum <= 8'd0;
                    best_score <= 16'd0;
                    best_valid <= 1'b0;
                    in_run <= 1'b0;
                    state <= MAX_WAIT_1;
                end
                // The compact column memory has a two-cycle read response.
                // The candidate calculation itself is unchanged.
                MAX_WAIT_1: state <= MAX_WAIT_2;
                MAX_WAIT_2: state <= FIND_MAX;
                FIND_MAX: begin
                    if (I_column_count > maximum)
                        maximum <= I_column_count;
                    if (O_read_x == 9'd319) begin
                        O_read_x <= 9'd0;
                        state <= THRESHOLD_LATCH;
                    end else begin
                        O_read_x <= O_read_x + 9'd1;
                        state <= MAX_WAIT_1;
                    end
                end
                THRESHOLD_LATCH: begin
                    threshold_reg <= threshold;
                    state <= SPAN_WAIT_1;
                end
                SPAN_WAIT_1: state <= SPAN_WAIT_2;
                SPAN_WAIT_2: state <= FIND_SPAN;
                FIND_SPAN: begin
                    if (active) begin
                        if (in_run) begin
                            run_score <= run_score + I_column_count;
                        end else begin
                            in_run <= 1'b1;
                            run_start <= O_read_x;
                            run_score <= {8'd0, I_column_count};
                        end
                    end else begin
                        in_run <= 1'b0;
                        run_score <= 16'd0;
                    end
                    if (better_span) begin
                        best_score <= close_score;
                        best_left <= close_start;
                        best_right <= close_end;
                        best_valid <= 1'b1;
                    end
                    if (O_read_x == 9'd319) begin
                        O_candidate_valid <= best_valid || better_span;
                        O_left <= winning_left;
                        O_right <= winning_right;
                        if (!best_valid && !better_span) begin
                            O_left <= 9'd0;
                            O_right <= 9'd0;
                        end
                        O_done <= 1'b1;
                        state <= IDLE;
                    end else begin
                        O_read_x <= O_read_x + 9'd1;
                        state <= SPAN_WAIT_1;
                    end
                end
                default: state <= IDLE;
            endcase
        end
    end
endmodule

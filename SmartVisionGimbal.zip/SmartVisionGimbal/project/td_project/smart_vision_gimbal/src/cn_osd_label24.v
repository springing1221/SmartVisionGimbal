// Auto-generated 24x24 Microsoft YaHei Bold subtitle ROM for 模式.
// Bit 23 is the left-most pixel.
module cn_osd_label24(input wire I_char, input wire [4:0] I_row, output reg [23:0] O_row_bits);
always @(*) begin O_row_bits = 24'h000000; case(I_char)
1'b0: case(I_row) // 模
5'd0: O_row_bits = 24'h0E1C70;
5'd1: O_row_bits = 24'h0E1C70;
5'd2: O_row_bits = 24'h0EFFFE;
5'd3: O_row_bits = 24'h0EFFFE;
5'd4: O_row_bits = 24'h0E1C70;
5'd5: O_row_bits = 24'h7F8000;
5'd6: O_row_bits = 24'h7FFFFC;
5'd7: O_row_bits = 24'h7FFFFC;
5'd8: O_row_bits = 24'h0E701C;
5'd9: O_row_bits = 24'h1E7FFC;
5'd10: O_row_bits = 24'h1F7FFC;
5'd11: O_row_bits = 24'h3FF01C;
5'd12: O_row_bits = 24'h3F7FFC;
5'd13: O_row_bits = 24'h7E7FFC;
5'd14: O_row_bits = 24'h2E0380;
5'd15: O_row_bits = 24'h2EFFFC;
5'd16: O_row_bits = 24'h0EFFFC;
5'd17: O_row_bits = 24'h0E0FC0;
5'd18: O_row_bits = 24'h0E3EF0;
5'd19: O_row_bits = 24'h0EFC7E;
5'd20: O_row_bits = 24'h0EF03C;
5'd21: O_row_bits = 24'h0E600C;
default: O_row_bits = 24'h000000; endcase
1'b1: case(I_row) // 式
5'd0: O_row_bits = 24'h000F20;
5'd1: O_row_bits = 24'h000F70;
5'd2: O_row_bits = 24'h000F38;
5'd3: O_row_bits = 24'h000F38;
5'd4: O_row_bits = 24'h7FFFFC;
5'd5: O_row_bits = 24'h7FFFFC;
5'd6: O_row_bits = 24'h7FFFFC;
5'd7: O_row_bits = 24'h000700;
5'd8: O_row_bits = 24'h000700;
5'd9: O_row_bits = 24'h3FF700;
5'd10: O_row_bits = 24'h3FF700;
5'd11: O_row_bits = 24'h3FF700;
5'd12: O_row_bits = 24'h038700;
5'd13: O_row_bits = 24'h038700;
5'd14: O_row_bits = 24'h038380;
5'd15: O_row_bits = 24'h038388;
5'd16: O_row_bits = 24'h03FB8E;
5'd17: O_row_bits = 24'h7FFB9C;
5'd18: O_row_bits = 24'h3FFBDC;
5'd19: O_row_bits = 24'h3C01FC;
5'd20: O_row_bits = 24'h0000FC;
5'd21: O_row_bits = 24'h000078;
default: O_row_bits = 24'h000000; endcase
default: O_row_bits = 24'h000000;
endcase
end
endmodule

// One RGB888 pixel is accepted for every asserted I_video_de clock.
// The two line stores and the three horizontal taps form one shared 3x3
// window for CARTOON Sobel, sharpen, adaptive threshold and morphology.
// The first two rows/columns suppress operators needing a complete window.
// Morphology deliberately uses one 1-bit two-line store: open and close are
// mutually exclusive display modes, so their first pass never needs two RAMs.
module image_processing_3x3 #(
    parameter integer IMG_WIDTH  = 1280,
    parameter integer IMG_HEIGHT = 720
)(
    input wire I_clk, input wire I_rst_n, input wire I_video_de,
    input wire I_video_user, input wire I_video_last, input wire [3:0] I_mode,
    input wire [23:0] I_video_data, output reg [23:0] O_video_data
);
    // Bit 24 packs morphology's first-pass result into the existing RGB
    // line stores.  PH1 ERAM has spare physical data width here, so this
    // avoids inferring any additional ERAM for the 1-bit intermediate image.
    (* ram_style = "bram" *) reg [24:0] line_m2 [0:IMG_WIDTH-1];
    (* ram_style = "bram" *) reg [24:0] line_m1 [0:IMG_WIDTH-1];
    reg [11:0] x_pos, y_pos;
    // Prefetch the address that x_pos will hold after this clock edge.
    // RAM outputs have no reset; incomplete rows are masked below.
    // This keeps the existing zero-added-latency pixel/control interface.
    wire [11:0] line_read_addr = !I_video_de ? x_pos :
                                   I_video_user ? 12'd1 :
                                   I_video_last ? 12'd0 : x_pos + 12'd1;
    reg [11:0] line_prefetch_addr;
    wire [24:0] line_m2_q = line_m2[line_prefetch_addr];
    wire [24:0] line_m1_q = line_m1[line_prefetch_addr];
    always @(posedge I_clk) begin
        line_prefetch_addr <= line_read_addr;
        if(I_rst_n && I_video_de) begin
            line_m2[x_pos] <= {morph_mid_now,mid_now};
            line_m1[x_pos] <= {morph_first,bot_now};
        end
    end
    reg [23:0] top_l2, top_l1, mid_l2, mid_l1, bot_l2, bot_l1;
    reg morph_top_l2, morph_top_l1, morph_mid_l2, morph_mid_l1;
    reg morph_bot_l2, morph_bot_l1;
    wire [23:0] top_now = line_m2_q[23:0];
    wire [23:0] mid_now = line_m1_q[23:0];
    wire [23:0] bot_now = I_video_data;
    wire morph_top_now = line_m2_q[24];
    wire morph_mid_now = line_m1_q[24];
    wire window_valid = I_video_de && !I_video_user &&
                        (x_pos >= 12'd2) && (y_pos >= 12'd2);
    // The second morphology pass consumes a 3x3 window of first-pass
    // results, so a fully defined output starts after four source rows and
    // columns.  Before then use the ordinary threshold result, never stale
    // RAM contents from the previous frame/mode.
    wire morph_valid = I_video_de && !I_video_user &&
                       (x_pos >= 12'd4) && (y_pos >= 12'd4);

    // Classic five-point sharpening, no multiplier/divider or new pipeline.
    // Kernel: (0,-1,0; -1,5,-1; 0,-1,0), saturate to RGB888.
    function [7:0] F_sharpen;
        input [7:0] a01; input [7:0] a10; input [7:0] a11;
        input [7:0] a12; input [7:0] a21;
        reg signed [11:0] value;
        begin
            // Full range -1020..1275 fits in twelve signed bits.
            value = ($signed({4'd0,a11}) <<< 2) + $signed({4'd0,a11})
                  - $signed({4'd0,a01}) - $signed({4'd0,a10})
                  - $signed({4'd0,a12}) - $signed({4'd0,a21});
            if(value < 0) F_sharpen = 8'd0;
            else if(value > 12'sd255) F_sharpen = 8'd255;
            else F_sharpen = value[7:0];
        end
    endfunction

    // Eight evenly-spaced chroma levels; black is retained and the top bucket
    // is explicitly mapped to white rather than a dim 252.
    function [7:0] F_cartoon_quant;
        input [7:0] value;
        begin
            if(value[7:5] == 3'b111)
                F_cartoon_quant = 8'hff;
            else
                F_cartoon_quant = {value[7:5],value[7:5],2'b00};
        end
    endfunction

    // Approximate luma = R/4 + G/2 + B/4, with no multiplier.
    function [7:0] F_luma;
        input [23:0] pixel;
        begin
            F_luma = {2'd0,pixel[23:18]} + {1'b0,pixel[15:9]}
                   + {2'd0,pixel[7:2]};
        end
    endfunction

    // Direct 24-bit adaptation of the real peer implementation in
    // lab_ex2_edge_liu/.../isp/img_proc_top.v.  Its source stream is four
    // pixels per beat; this design's HDMI reader is one pixel per beat.
    function [23:0] F_peer_pseudo;
        input [7:0] gray;
        begin
            case(gray[7:6])
                2'b00: F_peer_pseudo = 24'h0000ff;
                2'b01: F_peer_pseudo = 24'h00ff00;
                2'b10: F_peer_pseudo = 24'hff0000;
                default: F_peer_pseudo = 24'hffffff;
            endcase
        end
    endfunction

    function [10:0] F_sobel;
        input [7:0] a00; input [7:0] a01; input [7:0] a02;
        input [7:0] a10; input [7:0] a12;
        input [7:0] a20; input [7:0] a21; input [7:0] a22;
        reg signed [12:0] gx, gy;
        reg [10:0] abs_gx, abs_gy;
        begin
            gx = -$signed({5'd0,a00}) + $signed({5'd0,a02})
               - ($signed({5'd0,a10}) <<< 1) + ($signed({5'd0,a12}) <<< 1)
               - $signed({5'd0,a20}) + $signed({5'd0,a22});
            gy = -$signed({5'd0,a00}) - ($signed({5'd0,a01}) <<< 1)
               - $signed({5'd0,a02}) + $signed({5'd0,a20})
               + ($signed({5'd0,a21}) <<< 1) + $signed({5'd0,a22});
            abs_gx = gx[12] ? -gx : gx;
            abs_gy = gy[12] ? -gy : gy;
            F_sobel = abs_gx + abs_gy;
        end
    endfunction

    // Classical monochrome emboss: (-2 -1 0; -1 0 1; 0 1 2) plus a
    // 128 bias.  The signed 13-bit accumulator safely covers -892..1148.
    function [7:0] F_emboss;
        input [7:0] a00; input [7:0] a01; input [7:0] a02;
        input [7:0] a10; input [7:0] a11; input [7:0] a12;
        input [7:0] a20; input [7:0] a21; input [7:0] a22;
        reg signed [12:0] value;
        begin
            value = 13'sd128
                  - ($signed({5'd0,a00}) <<< 1) - $signed({5'd0,a01})
                  - $signed({5'd0,a10}) + $signed({5'd0,a12})
                  + $signed({5'd0,a21}) + ($signed({5'd0,a22}) <<< 1);
            if(value < 0) F_emboss = 8'd0;
            else if(value > 13'sd255) F_emboss = 8'd255;
            else F_emboss = value[7:0];
        end
    endfunction

    // gamma = 0.85, quantised offline as a synthesizable 256x8 case ROM.
    function [7:0] F_gamma;
        input [7:0] value;
        begin
            case(value)
                8'd0: F_gamma = 8'd0;
                8'd1: F_gamma = 8'd2;
                8'd2: F_gamma = 8'd4;
                8'd3: F_gamma = 8'd6;
                8'd4: F_gamma = 8'd7;
                8'd5: F_gamma = 8'd9;
                8'd6: F_gamma = 8'd11;
                8'd7: F_gamma = 8'd12;
                8'd8: F_gamma = 8'd13;
                8'd9: F_gamma = 8'd15;
                8'd10: F_gamma = 8'd16;
                8'd11: F_gamma = 8'd18;
                8'd12: F_gamma = 8'd19;
                8'd13: F_gamma = 8'd20;
                8'd14: F_gamma = 8'd22;
                8'd15: F_gamma = 8'd23;
                8'd16: F_gamma = 8'd24;
                8'd17: F_gamma = 8'd26;
                8'd18: F_gamma = 8'd27;
                8'd19: F_gamma = 8'd28;
                8'd20: F_gamma = 8'd29;
                8'd21: F_gamma = 8'd31;
                8'd22: F_gamma = 8'd32;
                8'd23: F_gamma = 8'd33;
                8'd24: F_gamma = 8'd34;
                8'd25: F_gamma = 8'd35;
                8'd26: F_gamma = 8'd37;
                8'd27: F_gamma = 8'd38;
                8'd28: F_gamma = 8'd39;
                8'd29: F_gamma = 8'd40;
                8'd30: F_gamma = 8'd41;
                8'd31: F_gamma = 8'd43;
                8'd32: F_gamma = 8'd44;
                8'd33: F_gamma = 8'd45;
                8'd34: F_gamma = 8'd46;
                8'd35: F_gamma = 8'd47;
                8'd36: F_gamma = 8'd48;
                8'd37: F_gamma = 8'd49;
                8'd38: F_gamma = 8'd51;
                8'd39: F_gamma = 8'd52;
                8'd40: F_gamma = 8'd53;
                8'd41: F_gamma = 8'd54;
                8'd42: F_gamma = 8'd55;
                8'd43: F_gamma = 8'd56;
                8'd44: F_gamma = 8'd57;
                8'd45: F_gamma = 8'd58;
                8'd46: F_gamma = 8'd59;
                8'd47: F_gamma = 8'd61;
                8'd48: F_gamma = 8'd62;
                8'd49: F_gamma = 8'd63;
                8'd50: F_gamma = 8'd64;
                8'd51: F_gamma = 8'd65;
                8'd52: F_gamma = 8'd66;
                8'd53: F_gamma = 8'd67;
                8'd54: F_gamma = 8'd68;
                8'd55: F_gamma = 8'd69;
                8'd56: F_gamma = 8'd70;
                8'd57: F_gamma = 8'd71;
                8'd58: F_gamma = 8'd72;
                8'd59: F_gamma = 8'd73;
                8'd60: F_gamma = 8'd75;
                8'd61: F_gamma = 8'd76;
                8'd62: F_gamma = 8'd77;
                8'd63: F_gamma = 8'd78;
                8'd64: F_gamma = 8'd79;
                8'd65: F_gamma = 8'd80;
                8'd66: F_gamma = 8'd81;
                8'd67: F_gamma = 8'd82;
                8'd68: F_gamma = 8'd83;
                8'd69: F_gamma = 8'd84;
                8'd70: F_gamma = 8'd85;
                8'd71: F_gamma = 8'd86;
                8'd72: F_gamma = 8'd87;
                8'd73: F_gamma = 8'd88;
                8'd74: F_gamma = 8'd89;
                8'd75: F_gamma = 8'd90;
                8'd76: F_gamma = 8'd91;
                8'd77: F_gamma = 8'd92;
                8'd78: F_gamma = 8'd93;
                8'd79: F_gamma = 8'd94;
                8'd80: F_gamma = 8'd95;
                8'd81: F_gamma = 8'd96;
                8'd82: F_gamma = 8'd97;
                8'd83: F_gamma = 8'd98;
                8'd84: F_gamma = 8'd99;
                8'd85: F_gamma = 8'd100;
                8'd86: F_gamma = 8'd101;
                8'd87: F_gamma = 8'd102;
                8'd88: F_gamma = 8'd103;
                8'd89: F_gamma = 8'd104;
                8'd90: F_gamma = 8'd105;
                8'd91: F_gamma = 8'd106;
                8'd92: F_gamma = 8'd107;
                8'd93: F_gamma = 8'd108;
                8'd94: F_gamma = 8'd109;
                8'd95: F_gamma = 8'd110;
                8'd96: F_gamma = 8'd111;
                8'd97: F_gamma = 8'd112;
                8'd98: F_gamma = 8'd113;
                8'd99: F_gamma = 8'd114;
                8'd100: F_gamma = 8'd115;
                8'd101: F_gamma = 8'd116;
                8'd102: F_gamma = 8'd117;
                8'd103: F_gamma = 8'd118;
                8'd104: F_gamma = 8'd119;
                8'd105: F_gamma = 8'd120;
                8'd106: F_gamma = 8'd121;
                8'd107: F_gamma = 8'd122;
                8'd108: F_gamma = 8'd123;
                8'd109: F_gamma = 8'd124;
                8'd110: F_gamma = 8'd125;
                8'd111: F_gamma = 8'd126;
                8'd112: F_gamma = 8'd127;
                8'd113: F_gamma = 8'd128;
                8'd114: F_gamma = 8'd129;
                8'd115: F_gamma = 8'd130;
                8'd116: F_gamma = 8'd131;
                8'd117: F_gamma = 8'd132;
                8'd118: F_gamma = 8'd132;
                8'd119: F_gamma = 8'd133;
                8'd120: F_gamma = 8'd134;
                8'd121: F_gamma = 8'd135;
                8'd122: F_gamma = 8'd136;
                8'd123: F_gamma = 8'd137;
                8'd124: F_gamma = 8'd138;
                8'd125: F_gamma = 8'd139;
                8'd126: F_gamma = 8'd140;
                8'd127: F_gamma = 8'd141;
                8'd128: F_gamma = 8'd142;
                8'd129: F_gamma = 8'd143;
                8'd130: F_gamma = 8'd144;
                8'd131: F_gamma = 8'd145;
                8'd132: F_gamma = 8'd146;
                8'd133: F_gamma = 8'd147;
                8'd134: F_gamma = 8'd148;
                8'd135: F_gamma = 8'd149;
                8'd136: F_gamma = 8'd149;
                8'd137: F_gamma = 8'd150;
                8'd138: F_gamma = 8'd151;
                8'd139: F_gamma = 8'd152;
                8'd140: F_gamma = 8'd153;
                8'd141: F_gamma = 8'd154;
                8'd142: F_gamma = 8'd155;
                8'd143: F_gamma = 8'd156;
                8'd144: F_gamma = 8'd157;
                8'd145: F_gamma = 8'd158;
                8'd146: F_gamma = 8'd159;
                8'd147: F_gamma = 8'd160;
                8'd148: F_gamma = 8'd161;
                8'd149: F_gamma = 8'd162;
                8'd150: F_gamma = 8'd162;
                8'd151: F_gamma = 8'd163;
                8'd152: F_gamma = 8'd164;
                8'd153: F_gamma = 8'd165;
                8'd154: F_gamma = 8'd166;
                8'd155: F_gamma = 8'd167;
                8'd156: F_gamma = 8'd168;
                8'd157: F_gamma = 8'd169;
                8'd158: F_gamma = 8'd170;
                8'd159: F_gamma = 8'd171;
                8'd160: F_gamma = 8'd172;
                8'd161: F_gamma = 8'd172;
                8'd162: F_gamma = 8'd173;
                8'd163: F_gamma = 8'd174;
                8'd164: F_gamma = 8'd175;
                8'd165: F_gamma = 8'd176;
                8'd166: F_gamma = 8'd177;
                8'd167: F_gamma = 8'd178;
                8'd168: F_gamma = 8'd179;
                8'd169: F_gamma = 8'd180;
                8'd170: F_gamma = 8'd181;
                8'd171: F_gamma = 8'd182;
                8'd172: F_gamma = 8'd182;
                8'd173: F_gamma = 8'd183;
                8'd174: F_gamma = 8'd184;
                8'd175: F_gamma = 8'd185;
                8'd176: F_gamma = 8'd186;
                8'd177: F_gamma = 8'd187;
                8'd178: F_gamma = 8'd188;
                8'd179: F_gamma = 8'd189;
                8'd180: F_gamma = 8'd190;
                8'd181: F_gamma = 8'd191;
                8'd182: F_gamma = 8'd191;
                8'd183: F_gamma = 8'd192;
                8'd184: F_gamma = 8'd193;
                8'd185: F_gamma = 8'd194;
                8'd186: F_gamma = 8'd195;
                8'd187: F_gamma = 8'd196;
                8'd188: F_gamma = 8'd197;
                8'd189: F_gamma = 8'd198;
                8'd190: F_gamma = 8'd199;
                8'd191: F_gamma = 8'd199;
                8'd192: F_gamma = 8'd200;
                8'd193: F_gamma = 8'd201;
                8'd194: F_gamma = 8'd202;
                8'd195: F_gamma = 8'd203;
                8'd196: F_gamma = 8'd204;
                8'd197: F_gamma = 8'd205;
                8'd198: F_gamma = 8'd206;
                8'd199: F_gamma = 8'd207;
                8'd200: F_gamma = 8'd207;
                8'd201: F_gamma = 8'd208;
                8'd202: F_gamma = 8'd209;
                8'd203: F_gamma = 8'd210;
                8'd204: F_gamma = 8'd211;
                8'd205: F_gamma = 8'd212;
                8'd206: F_gamma = 8'd213;
                8'd207: F_gamma = 8'd214;
                8'd208: F_gamma = 8'd214;
                8'd209: F_gamma = 8'd215;
                8'd210: F_gamma = 8'd216;
                8'd211: F_gamma = 8'd217;
                8'd212: F_gamma = 8'd218;
                8'd213: F_gamma = 8'd219;
                8'd214: F_gamma = 8'd220;
                8'd215: F_gamma = 8'd221;
                8'd216: F_gamma = 8'd221;
                8'd217: F_gamma = 8'd222;
                8'd218: F_gamma = 8'd223;
                8'd219: F_gamma = 8'd224;
                8'd220: F_gamma = 8'd225;
                8'd221: F_gamma = 8'd226;
                8'd222: F_gamma = 8'd227;
                8'd223: F_gamma = 8'd228;
                8'd224: F_gamma = 8'd228;
                8'd225: F_gamma = 8'd229;
                8'd226: F_gamma = 8'd230;
                8'd227: F_gamma = 8'd231;
                8'd228: F_gamma = 8'd232;
                8'd229: F_gamma = 8'd233;
                8'd230: F_gamma = 8'd234;
                8'd231: F_gamma = 8'd234;
                8'd232: F_gamma = 8'd235;
                8'd233: F_gamma = 8'd236;
                8'd234: F_gamma = 8'd237;
                8'd235: F_gamma = 8'd238;
                8'd236: F_gamma = 8'd239;
                8'd237: F_gamma = 8'd240;
                8'd238: F_gamma = 8'd240;
                8'd239: F_gamma = 8'd241;
                8'd240: F_gamma = 8'd242;
                8'd241: F_gamma = 8'd243;
                8'd242: F_gamma = 8'd244;
                8'd243: F_gamma = 8'd245;
                8'd244: F_gamma = 8'd246;
                8'd245: F_gamma = 8'd246;
                8'd246: F_gamma = 8'd247;
                8'd247: F_gamma = 8'd248;
                8'd248: F_gamma = 8'd249;
                8'd249: F_gamma = 8'd250;
                8'd250: F_gamma = 8'd251;
                8'd251: F_gamma = 8'd252;
                8'd252: F_gamma = 8'd252;
                8'd253: F_gamma = 8'd253;
                8'd254: F_gamma = 8'd254;
                8'd255: F_gamma = 8'd255;
                default: F_gamma = 8'd0;
            endcase
        end
    endfunction

    localparam [10:0] CARTOON_EDGE_THRESHOLD = 11'd180;
    // Adaptive threshold: centre*9 >= sum(3x3)-9*C.  C=12 makes the
    // foreground decision mildly darker than the local mean and requires
    // only shifts/adds/comparison (no divider or multiplier).
    localparam [7:0] ADAPTIVE_OFFSET_C = 8'd12;
    localparam [7:0] BINARY_THRESHOLD  = 8'd128;
    // Default red-object colour-segmentation limits.  Kept here as compact
    // parameters so a later board calibration only changes constants.
    localparam [7:0] RED_MIN_R = 8'd160;
    localparam [7:0] RED_MAX_G = 8'd120;
    localparam [7:0] RED_MAX_B = 8'd120;
    wire [7:0] lum00 = F_luma(top_l2);
    wire [7:0] lum01 = F_luma(top_l1);
    wire [7:0] lum02 = F_luma(top_now);
    wire [7:0] lum10 = F_luma(mid_l2);
    wire [7:0] lum11 = F_luma(mid_l1);
    wire [7:0] lum12 = F_luma(mid_now);
    wire [7:0] lum20 = F_luma(bot_l2);
    wire [7:0] lum21 = F_luma(bot_l1);
    wire [7:0] lum22 = F_luma(bot_now);
    wire [10:0] sobel_magnitude = F_sobel(lum00,lum01,lum02,lum10,lum12,lum20,lum21,lum22);
    wire [7:0] peer_gray = F_luma(I_video_data);
    wire [23:0] peer_gray_data = {peer_gray,peer_gray,peer_gray};
    wire [23:0] peer_binary_data = (peer_gray >= 8'd128) ? 24'hffffff : 24'h000000;
    wire [23:0] peer_pseudo_data = F_peer_pseudo(peer_gray);
    // Peer img_proc_top uses this Sobel core with EDGE_TH=80. Its 96-bit
    // right-neighbour de-noiser cannot be used without changing this
    // one-pixel HDMI interface, so the real threshold/kernel are retained.
    wire peer_edge = window_valid && (sobel_magnitude >= 11'd80);
    wire [23:0] peer_edge_data = peer_edge ? 24'hffffff : 24'h000000;
    wire [23:0] cartoon_data = {F_cartoon_quant(I_video_data[23:16]),
                                F_cartoon_quant(I_video_data[15:8]),
                                F_cartoon_quant(I_video_data[7:0])};
    wire [7:0] emboss_gray = F_emboss(lum00,lum01,lum02,lum10,lum11,lum12,lum20,lum21,lum22);
    wire [23:0] emboss_data = {emboss_gray,emboss_gray,emboss_gray};
    wire [7:0] sharpen_r = F_sharpen(top_l1[23:16],mid_l2[23:16],mid_l1[23:16],mid_now[23:16],bot_l1[23:16]);
    wire [7:0] sharpen_g = F_sharpen(top_l1[15:8],mid_l2[15:8],mid_l1[15:8],mid_now[15:8],bot_l1[15:8]);
    wire [7:0] sharpen_b = F_sharpen(top_l1[7:0],mid_l2[7:0],mid_l1[7:0],mid_now[7:0],bot_l1[7:0]);
    wire [23:0] gamma_data = {F_gamma(I_video_data[23:16]),F_gamma(I_video_data[15:8]),F_gamma(I_video_data[7:0])};

    // 3x3 adaptive mean and the binary source shared by morphology.  The
    // maximum sum is 9*255=2295, so twelve bits are sufficient.
    wire [11:0] local_sum = {4'd0,lum00}+{4'd0,lum01}+{4'd0,lum02}
                         + {4'd0,lum10}+{4'd0,lum11}+{4'd0,lum12}
                         + {4'd0,lum20}+{4'd0,lum21}+{4'd0,lum22};
    wire [11:0] adaptive_lhs = ({4'd0,lum11} << 3) + {4'd0,lum11}
                             + ({4'd0,ADAPTIVE_OFFSET_C} << 3) + {4'd0,ADAPTIVE_OFFSET_C};
    wire adaptive_bit = window_valid && (adaptive_lhs >= local_sum);
    wire [23:0] adaptive_data = adaptive_bit ? 24'hffffff : 24'h000000;

    wire bin00 = (lum00 >= BINARY_THRESHOLD); wire bin01 = (lum01 >= BINARY_THRESHOLD);
    wire bin02 = (lum02 >= BINARY_THRESHOLD); wire bin10 = (lum10 >= BINARY_THRESHOLD);
    wire bin11 = (lum11 >= BINARY_THRESHOLD); wire bin12 = (lum12 >= BINARY_THRESHOLD);
    wire bin20 = (lum20 >= BINARY_THRESHOLD); wire bin21 = (lum21 >= BINARY_THRESHOLD);
    wire bin22 = (lum22 >= BINARY_THRESHOLD);
    wire morph_erode_first  = bin00 & bin01 & bin02 & bin10 & bin11 & bin12 & bin20 & bin21 & bin22;
    wire morph_dilate_first = bin00 | bin01 | bin02 | bin10 | bin11 | bin12 | bin20 | bin21 | bin22;
    // The two display modes are mutually exclusive; selection before RAM
    // makes the intermediate buffer genuinely shared rather than duplicated.
    wire morph_first = (I_mode == 4'd11) ? morph_erode_first : morph_dilate_first;
    wire morph_open_bit = morph_top_l2 | morph_top_l1 | morph_top_now |
                          morph_mid_l2 | morph_mid_l1 | morph_mid_now |
                          morph_bot_l2 | morph_bot_l1 | morph_first;
    wire morph_close_bit = morph_top_l2 & morph_top_l1 & morph_top_now &
                           morph_mid_l2 & morph_mid_l1 & morph_mid_now &
                           morph_bot_l2 & morph_bot_l1 & morph_first;
    wire [23:0] morph_open_data  = morph_valid ? (morph_open_bit  ? 24'hffffff : 24'h000000) : peer_binary_data;
    wire [23:0] morph_close_data = morph_valid ? (morph_close_bit ? 24'hffffff : 24'h000000) : peer_binary_data;

    // Red target segmentation: qualifying pixels retain RGB; background is
    // luma-only.  This is direct RGB thresholding, so no HSV converter/DSP.
    wire color_red_hit = (I_video_data[23:16] >= RED_MIN_R) &&
                         (I_video_data[15:8]  <= RED_MAX_G) &&
                         (I_video_data[7:0]   <= RED_MAX_B) &&
                         ({1'b0,I_video_data[23:16]} >= ({1'b0,I_video_data[15:8]} + 9'd40)) &&
                         ({1'b0,I_video_data[23:16]} >= ({1'b0,I_video_data[7:0]}  + 9'd40));
    wire [23:0] color_segment_data = color_red_hit ? I_video_data : peer_gray_data;

    // Keep this path combinational.  video_out and hdmi_mixer already have
    // matched data/control pipelines; registering here would add a data-only
    // pixel delay and misalign RGB from DE/coordinates.
    always @(*) begin
        if(!I_video_de) begin
            O_video_data = 24'd0;
        end else begin
            case(I_mode)
                4'd1: O_video_data = window_valid ? {sharpen_r,sharpen_g,sharpen_b} : I_video_data;
                4'd2: O_video_data = gamma_data;
                4'd3: O_video_data = peer_gray_data;
                4'd4: O_video_data = peer_binary_data;
                4'd5: O_video_data = peer_edge_data;
                4'd6: O_video_data = peer_pseudo_data;
                // ID 7 (manga) removed; the controller skips it.
                4'd8: O_video_data = (window_valid && (sobel_magnitude >= CARTOON_EDGE_THRESHOLD)) ? 24'h000000 : cartoon_data;
                4'd9: O_video_data = window_valid ? emboss_data : I_video_data;
                // Modes 10..12 are now executed before DDR by the exact
                // peer 96-bit stream cores.  Do not re-filter them here.
                4'd10: O_video_data = I_video_data;
                4'd11: O_video_data = I_video_data;
                4'd12: O_video_data = I_video_data;
                4'd13: O_video_data = color_segment_data;
                default: O_video_data = I_video_data;
            endcase
        end
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if(!I_rst_n) begin
            x_pos <= 12'd0; y_pos <= 12'd0;
            top_l2 <= 24'd0; top_l1 <= 24'd0; mid_l2 <= 24'd0;
            mid_l1 <= 24'd0; bot_l2 <= 24'd0; bot_l1 <= 24'd0;
            morph_top_l2 <= 1'b0; morph_top_l1 <= 1'b0;
            morph_mid_l2 <= 1'b0; morph_mid_l1 <= 1'b0;
            morph_bot_l2 <= 1'b0; morph_bot_l1 <= 1'b0;
        end else if(I_video_de) begin
            // The unreset synchronous RAM path prefetches the next x_pos.
            top_l2 <= top_l1; top_l1 <= top_now;
            mid_l2 <= mid_l1; mid_l1 <= mid_now;
            bot_l2 <= bot_l1; bot_l1 <= bot_now;
            morph_top_l2 <= morph_top_l1; morph_top_l1 <= morph_top_now;
            morph_mid_l2 <= morph_mid_l1; morph_mid_l1 <= morph_mid_now;
            morph_bot_l2 <= morph_bot_l1; morph_bot_l1 <= morph_first;
            if(I_video_user) begin
                x_pos <= 12'd1; y_pos <= 12'd0;
            end else if(I_video_last) begin
                x_pos <= 12'd0;
                y_pos <= (y_pos == IMG_HEIGHT-1) ? 12'd0 : y_pos + 1'b1;
                // Do not reset RAM: y_pos masks the incomplete first two rows.
                top_l2 <= 24'd0; top_l1 <= 24'd0; mid_l2 <= 24'd0;
                mid_l1 <= 24'd0; bot_l2 <= 24'd0; bot_l1 <= 24'd0;
                morph_top_l2 <= 1'b0; morph_top_l1 <= 1'b0;
                morph_mid_l2 <= 1'b0; morph_mid_l1 <= 1'b0;
                morph_bot_l2 <= 1'b0; morph_bot_l1 <= 1'b0;
            end else begin
                x_pos <= x_pos + 1'b1;
            end
        end
    end
endmodule

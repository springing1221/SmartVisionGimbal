// Generates two 50-Hz positional-servo waveforms from 2-us pulse units.
// New pulse widths are committed only at the start of a PWM frame.
module gimbal_pwm_dual (
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire [10:0] I_base_pulse_ticks,
    input  wire [10:0] I_tilt_pulse_ticks,
    output wire        O_pwm_base,
    output wire        O_pwm_tilt
);
    localparam [7:0]  CLK_PER_2US_TICK = 8'd200;
    localparam [13:0] PWM_PERIOD_TICKS = 14'd10000;

    reg [7:0]  S_tick_div;
    reg [13:0] S_pwm_count;
    reg [10:0] S_active_base_ticks;
    reg [10:0] S_active_tilt_ticks;
    wire S_tick_2us = (S_tick_div == CLK_PER_2US_TICK - 8'd1);

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            S_tick_div          <= 8'd0;
            S_pwm_count         <= 14'd0;
            S_active_base_ticks <= 11'd750;
            S_active_tilt_ticks <= 11'd750;
        end else if (S_tick_2us) begin
            S_tick_div <= 8'd0;
            if (S_pwm_count == PWM_PERIOD_TICKS - 14'd1) begin
                S_pwm_count         <= 14'd0;
                S_active_base_ticks <= I_base_pulse_ticks;
                S_active_tilt_ticks <= I_tilt_pulse_ticks;
            end else begin
                S_pwm_count <= S_pwm_count + 14'd1;
            end
        end else begin
            S_tick_div <= S_tick_div + 8'd1;
        end
    end

    assign O_pwm_base = I_rst_n && (S_pwm_count < S_active_base_ticks);
    assign O_pwm_tilt = I_rst_n && (S_pwm_count < S_active_tilt_ticks);
endmodule

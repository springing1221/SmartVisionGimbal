// Hybrid proposal box: candidate columns determine horizontal bounds while
// foreground-mask rows determine vertical bounds. This avoids widening the
// box with unrelated foreground pixels beside the selected candidate.
module candidate_box #(
    parameter [9:0] DISPLAY_Y_END = 10'd696,
    parameter [8:0] HORIZONTAL_PAD = 9'd3,
    parameter [3:0] MAX_ROW_GAP = 4'd4
) (
    input  wire       I_clk,
    input  wire       I_rst_n,
    input  wire       I_candidate_done,
    input  wire       I_candidate_valid,
    input  wire [8:0] I_left,
    input  wire [8:0] I_right,
    output wire       O_read_en,
    output wire [8:0] O_read_x,
    output wire [7:0] O_read_y,
    input  wire       I_mask_valid,
    input  wire       I_mask_pixel,
    input  wire [8:0] I_mask_x,
    input  wire [7:0] I_mask_y,
    output reg        O_done,
    output reg        O_box_valid,
    output reg  [10:0] O_x0,
    output reg  [9:0] O_y0,
    output reg  [10:0] O_x1,
    output reg  [9:0] O_y1
);
    localparam [1:0] IDLE = 2'd0, SCAN = 2'd1,
                     WAIT_LAST = 2'd2, FINALIZE = 2'd3;
    reg [1:0] state;
    reg [8:0] left, right, read_x;
    reg [7:0] read_y;
    reg [8:0] row_pixels, row_min, row_first_x, row_last_x;
    reg geometry_ok;
    reg run_active;
    reg [3:0] gap_rows;
    reg [15:0] run_area, best_area;
    reg [7:0] run_first_y, run_last_y;
    reg [7:0] best_first_y, best_last_y;

    wire [8:0] span_width = I_right - I_left;
    wire [8:0] proposed_left = (I_left >= HORIZONTAL_PAD) ?
                               I_left - HORIZONTAL_PAD : 9'd0;
    wire [9:0] right_sum = {1'b0, I_right} + {1'b0, HORIZONTAL_PAD};
    wire [8:0] proposed_right = (right_sum <= 10'd320) ?
                                right_sum[8:0] : 9'd320;
    wire [8:0] proposed_row_min = span_width / 9'd10;
    wire row_end = I_mask_x == right - 9'd1;
    wire [8:0] next_row_pixels = row_pixels + {8'd0, I_mask_pixel};
    wire [8:0] next_row_first_x =
        (I_mask_pixel && I_mask_x < row_first_x) ? I_mask_x : row_first_x;
    wire [8:0] next_row_last_x =
        (I_mask_pixel && I_mask_x > row_last_x) ? I_mask_x : row_last_x;
    wire row_occupied = next_row_pixels >= row_min;
    wire [15:0] merged_area = (run_active ? run_area : 16'd0) +
                              {7'd0, next_row_pixels};
    wire use_current = run_active && run_area >= best_area;
    wire [15:0] selected_area = use_current ? run_area : best_area;
    wire [7:0] selected_first_y = use_current ? run_first_y : best_first_y;
    wire [7:0] selected_last_y = use_current ? run_last_y : best_last_y;
    wire [10:0] padded_bottom = {1'b0, selected_last_y, 2'b00} + 11'd12;
    wire final_valid = selected_area >= 16'd600 &&
                       (selected_last_y - selected_first_y + 8'd1 >= 8'd30) &&
                       geometry_ok;

    assign O_read_en = state == SCAN;
    assign O_read_x = read_x;
    assign O_read_y = read_y;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            state <= IDLE;
            left <= 9'd0;
            right <= 9'd0;
            read_x <= 9'd0;
            read_y <= 8'd8;
            row_pixels <= 9'd0;
            row_min <= 9'd6;
            row_first_x <= 9'd320;
            row_last_x <= 9'd0;
            geometry_ok <= 1'b0;
            run_active <= 1'b0;
            gap_rows <= 4'd0;
            run_area <= 16'd0;
            run_first_y <= 8'd0;
            run_last_y <= 8'd0;
            best_area <= 16'd0;
            best_first_y <= 8'd0;
            best_last_y <= 8'd0;
            O_done <= 1'b0;
            O_box_valid <= 1'b0;
            O_x0 <= 11'd0;
            O_y0 <= 10'd0;
            O_x1 <= 11'd0;
            O_y1 <= 10'd0;
        end else begin
            O_done <= 1'b0;
            O_box_valid <= 1'b0;
            if (state == IDLE && I_candidate_done) begin
                if (I_candidate_valid && proposed_left < proposed_right) begin
                    left <= proposed_left;
                    right <= proposed_right;
                    read_x <= proposed_left;
                    read_y <= 8'd8;
                    row_pixels <= 9'd0;
                    row_first_x <= 9'd320;
                    row_last_x <= 9'd0;
                    row_min <= (proposed_row_min > 9'd6) ?
                               proposed_row_min : 9'd6;
                    geometry_ok <= span_width <= 9'd90;
                    run_active <= 1'b0;
                    gap_rows <= 4'd0;
                    run_area <= 16'd0;
                    run_first_y <= 8'd0;
                    run_last_y <= 8'd0;
                    best_area <= 16'd0;
                    best_first_y <= 8'd0;
                    best_last_y <= 8'd0;
                    state <= SCAN;
                end else begin
                    O_done <= 1'b1;
                end
            end
            if (state == SCAN) begin
                if (read_x == right - 9'd1) begin
                    read_x <= left;
                    if (read_y == 8'd179)
                        state <= WAIT_LAST;
                    else
                        read_y <= read_y + 8'd1;
                end else begin
                    read_x <= read_x + 9'd1;
                end
            end
            if (I_mask_valid) begin
                if (row_end) begin
                    row_pixels <= 9'd0;
                    row_first_x <= 9'd320;
                    row_last_x <= 9'd0;
                    if (row_occupied) begin
                        run_active <= 1'b1;
                        gap_rows <= 4'd0;
                        run_area <= merged_area;
                        if (!run_active)
                            run_first_y <= I_mask_y;
                        run_last_y <= I_mask_y;
                    end else if (run_active) begin
                        if (gap_rows == MAX_ROW_GAP) begin
                            if (run_area > best_area) begin
                                best_area <= run_area;
                                best_first_y <= run_first_y;
                                best_last_y <= run_last_y;
                            end
                            run_active <= 1'b0;
                            gap_rows <= 4'd0;
                        end else begin
                            gap_rows <= gap_rows + 4'd1;
                        end
                    end
                    if (I_mask_y == 8'd179)
                        state <= FINALIZE;
                end else begin
                    row_pixels <= next_row_pixels;
                    row_first_x <= next_row_first_x;
                    row_last_x <= next_row_last_x;
                end
            end
            if (state == FINALIZE) begin
                O_done <= 1'b1;
                O_box_valid <= final_valid;
                if (final_valid) begin
                    O_x0 <= {left, 2'b00};
                    O_x1 <= {right, 2'b00} - 11'd1;
                    O_y0 <= (selected_first_y >= 8'd3) ?
                            {selected_first_y - 8'd2, 2'b00} : 10'd4;
                    O_y1 <= (padded_bottom >= {1'b0, DISPLAY_Y_END}) ?
                            DISPLAY_Y_END : padded_bottom[9:0];
                end
                state <= IDLE;
            end
        end
    end
endmodule

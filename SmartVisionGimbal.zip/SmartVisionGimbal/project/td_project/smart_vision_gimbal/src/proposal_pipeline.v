// Candidate-column pipeline tapped from the ISP's pre-repacker RGB96 stream.
// It does not alter the original video or DDR paths.
module proposal_pipeline (
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire        I_night_mode,
    input  wire        I_capture_background,
    input  wire        I_frame_start,
    input  wire        I_line_end,
    input  wire        I_valid,
    input  wire [95:0] I_rgb,
    output wire        O_background_ready,
    output wire        O_column_done,
    output wire        O_candidate_valid,
    output wire [8:0]  O_left,
    output wire [8:0]  O_right,
    output wire        O_row_overrun,
    output wire        O_box_done,
    output wire        O_box_valid,
    output wire [10:0] O_x0,
    output wire [9:0]  O_y0,
    output wire [10:0] O_x1,
    output wire [9:0]  O_y1
);
    wire [31:0] gray;
    wire gray_valid;
    reg frame_start_d;
    reg frame_start_dd;
    reg line_end_d;
    reg line_end_dd;
    wire sample_valid;
    wire [7:0] sample_gray;
    wire [7:0] sample_background;
    wire [8:0] sample_x;
    wire [7:0] sample_y;
    wire signed [8:0] offset;
    wire foreground_valid;
    wire foreground;
    wire [8:0] foreground_x;
    wire [7:0] foreground_y;
    wire [8:0] read_x;
    wire [7:0] column_count;
    wire columns_ready;
    wire mask_write_valid;
    wire mask_write_pixel;
    wire [8:0] mask_write_x;
    wire [7:0] mask_write_y;
    wire mask_read_en;
    wire [8:0] mask_read_x;
    wire [7:0] mask_read_y;
    wire mask_read_valid;
    wire mask_read_pixel;
    wire [8:0] mask_return_x;
    wire [7:0] mask_return_y;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            frame_start_d <= 1'b0;
            frame_start_dd <= 1'b0;
            line_end_d <= 1'b0;
            line_end_dd <= 1'b0;
        end else begin
            frame_start_d <= I_frame_start;
            frame_start_dd <= frame_start_d;
            line_end_d <= I_line_end;
            line_end_dd <= line_end_d;
        end
    end

    rgb96_gray4 u_gray (
        .I_clk(I_clk), .I_rst_n(I_rst_n), .I_valid(I_valid),
        .I_night_mode(I_night_mode),
        .I_rgb(I_rgb), .O_valid(gray_valid), .O_gray(gray)
    );

    background_sample u_background (
        .I_clk(I_clk), .I_rst_n(I_rst_n),
        .I_capture(I_capture_background),
        .I_frame_start(frame_start_dd), .I_line_end(line_end_dd),
        .I_valid(gray_valid), .I_gray(gray),
        .O_valid(sample_valid), .O_gray(sample_gray),
        .O_background(sample_background), .O_x(sample_x), .O_y(sample_y),
        .O_background_ready(O_background_ready)
    );

    exposure_offset u_exposure (
        .I_clk(I_clk), .I_rst_n(I_rst_n),
        .I_frame_start(frame_start_dd), .I_valid(sample_valid),
        .I_x(sample_x), .I_y(sample_y),
        .I_gray(sample_gray), .I_background(sample_background),
        .O_offset(offset)
    );

    foreground_diff1 u_difference (
        .I_clk(I_clk), .I_rst_n(I_rst_n), .I_valid(sample_valid),
        .I_night_mode(I_night_mode),
        .I_gray(sample_gray), .I_background(sample_background),
        .I_exposure_offset(offset), .I_x(sample_x), .I_y(sample_y),
        .O_valid(foreground_valid), .O_foreground(foreground),
        .O_x(foreground_x), .O_y(foreground_y)
    );

    row_column_stats u_columns (
        .I_clk(I_clk), .I_rst_n(I_rst_n),
        .I_frame_start(frame_start_dd),
        .I_valid(foreground_valid), .I_foreground(foreground),
        .I_x(foreground_x), .I_y(foreground_y),
        .I_read_x(read_x), .O_column_count(column_count),
        .O_frame_ready(columns_ready), .O_overrun(O_row_overrun),
        .O_mask_valid(mask_write_valid), .O_mask_pixel(mask_write_pixel),
        .O_mask_x(mask_write_x), .O_mask_y(mask_write_y)
    );

    candidate_span u_span (
        .I_clk(I_clk), .I_rst_n(I_rst_n),
        .I_frame_ready(columns_ready), .I_column_count(column_count),
        .O_read_x(read_x), .O_done(O_column_done),
        .O_candidate_valid(O_candidate_valid),
        .O_left(O_left), .O_right(O_right)
    );

    foreground_mask_store u_mask (
        .I_clk(I_clk), .I_rst_n(I_rst_n),
        .I_write_valid(mask_write_valid), .I_write_pixel(mask_write_pixel),
        .I_write_x(mask_write_x), .I_write_y(mask_write_y),
        .I_read_en(mask_read_en), .I_read_x(mask_read_x),
        .I_read_y(mask_read_y), .O_read_valid(mask_read_valid),
        .O_read_pixel(mask_read_pixel),
        .O_read_x(mask_return_x), .O_read_y(mask_return_y)
    );

    candidate_box u_box (
        .I_clk(I_clk), .I_rst_n(I_rst_n),
        .I_candidate_done(O_column_done),
        .I_candidate_valid(O_candidate_valid),
        .I_left(O_left), .I_right(O_right),
        .O_read_en(mask_read_en), .O_read_x(mask_read_x),
        .O_read_y(mask_read_y),
        .I_mask_valid(mask_read_valid), .I_mask_pixel(mask_read_pixel),
        .I_mask_x(mask_return_x), .I_mask_y(mask_return_y),
        .O_done(O_box_done), .O_box_valid(O_box_valid),
        .O_x0(O_x0), .O_y0(O_y0), .O_x1(O_x1), .O_y1(O_y1)
    );
endmodule

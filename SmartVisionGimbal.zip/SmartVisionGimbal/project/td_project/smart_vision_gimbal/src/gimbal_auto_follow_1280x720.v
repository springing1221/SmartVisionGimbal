// Open-loop two-axis camera centering from completed 1280x720 box centers.
// Servo motion is intentionally rate limited; the camera image closes the
// loop on subsequent detection results.
module gimbal_auto_follow_1280x720 #(
    parameter [10:0] CENTER_X          = 11'd640,
    parameter [9:0]  CENTER_Y          = 10'd360,
    parameter [10:0] DEAD_ZONE_X       = 11'd64,
    parameter [9:0]  DEAD_ZONE_Y       = 10'd36,
    parameter [8:0]  BASE_MIN_ANGLE    = 9'd90,
    parameter [8:0]  BASE_MAX_ANGLE    = 9'd180,
    parameter [8:0]  BASE_INIT_ANGLE   = 9'd135,
    parameter [8:0]  TILT_MIN_ANGLE    = 9'd60,
    parameter [8:0]  TILT_MAX_ANGLE    = 9'd120,
    parameter [8:0]  TILT_INIT_ANGLE   = 9'd90,
    parameter [7:0]  RESULTS_PER_STEP  = 8'd6,
    parameter         HORIZONTAL_INVERT = 1'b1,
    parameter         VERTICAL_INVERT   = 1'b0
) (
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire        I_enable,
    input  wire        I_tilt_step_up,
    input  wire        I_tilt_step_down,
    input  wire        I_result_update,
    input  wire        I_target_valid,
    input  wire [10:0] I_target_x,
    input  wire [9:0]  I_target_y,
    output reg  [10:0] O_base_pulse_ticks,
    output reg  [10:0] O_tilt_pulse_ticks,
    output reg         O_follow_active
);
    reg [8:0] S_base_angle;
    reg [8:0] S_tilt_angle;
    reg [5:0] S_base_fraction;
    reg [5:0] S_tilt_fraction;
    reg [10:0] S_prev_x;
    reg [9:0]  S_prev_y;
    reg        S_have_previous;
    reg [1:0]  S_valid_streak;
    reg [7:0]  S_step_count;

    wire [10:0] S_delta_x = (I_target_x >= S_prev_x) ?
                              (I_target_x - S_prev_x) :
                              (S_prev_x - I_target_x);
    wire [9:0] S_delta_y = (I_target_y >= S_prev_y) ?
                             (I_target_y - S_prev_y) :
                             (S_prev_y - I_target_y);
    wire S_position_continuous = (S_delta_x <= 11'd192) &&
                                 (S_delta_y <= 10'd144);
    wire S_target_right = I_target_x > (CENTER_X + DEAD_ZONE_X);
    wire S_target_left  = I_target_x < (CENTER_X - DEAD_ZONE_X);
    wire S_target_down  = I_target_y > (CENTER_Y + DEAD_ZONE_Y);
    wire S_target_up    = I_target_y < (CENTER_Y - DEAD_ZONE_Y);
    wire S_base_frac_carry = (S_base_fraction + 6'd19) >= 6'd27;
    wire S_tilt_frac_carry = (S_tilt_fraction + 6'd5) >= 6'd9;
    wire S_confirmed = S_have_previous && S_position_continuous &&
                       (S_valid_streak >= 2'd2);

    task step_base_positive;
        begin
            if (S_base_angle < BASE_MAX_ANGLE) begin
                S_base_angle <= S_base_angle + 9'd1;
                if (S_base_frac_carry) begin
                    S_base_fraction <= S_base_fraction + 6'd19 - 6'd27;
                    O_base_pulse_ticks <= O_base_pulse_ticks + 11'd4;
                end else begin
                    S_base_fraction <= S_base_fraction + 6'd19;
                    O_base_pulse_ticks <= O_base_pulse_ticks + 11'd3;
                end
            end
        end
    endtask

    task step_base_negative;
        begin
            if (S_base_angle > BASE_MIN_ANGLE) begin
                S_base_angle <= S_base_angle - 9'd1;
                if (S_base_fraction >= 6'd19) begin
                    S_base_fraction <= S_base_fraction - 6'd19;
                    O_base_pulse_ticks <= O_base_pulse_ticks - 11'd3;
                end else begin
                    S_base_fraction <= S_base_fraction + 6'd8;
                    O_base_pulse_ticks <= O_base_pulse_ticks - 11'd4;
                end
            end
        end
    endtask

    task step_tilt_positive;
        begin
            if (S_tilt_angle < TILT_MAX_ANGLE) begin
                S_tilt_angle <= S_tilt_angle + 9'd1;
                if (S_tilt_frac_carry) begin
                    S_tilt_fraction <= S_tilt_fraction + 6'd5 - 6'd9;
                    O_tilt_pulse_ticks <= O_tilt_pulse_ticks + 11'd6;
                end else begin
                    S_tilt_fraction <= S_tilt_fraction + 6'd5;
                    O_tilt_pulse_ticks <= O_tilt_pulse_ticks + 11'd5;
                end
            end
        end
    endtask

    task step_tilt_negative;
        begin
            if (S_tilt_angle > TILT_MIN_ANGLE) begin
                S_tilt_angle <= S_tilt_angle - 9'd1;
                if (S_tilt_fraction >= 6'd5) begin
                    S_tilt_fraction <= S_tilt_fraction - 6'd5;
                    O_tilt_pulse_ticks <= O_tilt_pulse_ticks - 11'd5;
                end else begin
                    S_tilt_fraction <= S_tilt_fraction + 6'd4;
                    O_tilt_pulse_ticks <= O_tilt_pulse_ticks - 11'd6;
                end
            end
        end
    endtask

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            S_base_angle       <= BASE_INIT_ANGLE;
            S_tilt_angle       <= TILT_INIT_ANGLE;
            S_base_fraction    <= 6'd0;
            S_tilt_fraction    <= 6'd0;
            S_prev_x           <= CENTER_X;
            S_prev_y           <= CENTER_Y;
            S_have_previous    <= 1'b0;
            S_valid_streak     <= 2'd0;
            S_step_count       <= 8'd0;
            O_base_pulse_ticks <= 11'd750;
            O_tilt_pulse_ticks <= 11'd750;
            O_follow_active    <= 1'b0;
        end else if (!I_enable) begin
            // Require fresh, post-button detections before any movement.
            S_have_previous <= 1'b0;
            S_valid_streak  <= 2'd0;
            S_step_count    <= 8'd0;
            O_follow_active <= 1'b0;
            // KEY3/KEY4 always remain available for one-degree tilt trim.
            if (I_tilt_step_up && !I_tilt_step_down)
                step_tilt_positive;
            else if (I_tilt_step_down && !I_tilt_step_up)
                step_tilt_negative;
        end else if (I_tilt_step_up && !I_tilt_step_down) begin
            // Give a manual correction priority over a simultaneous detector
            // result. Reconfirm target continuity after the camera moves.
            step_tilt_positive;
            S_have_previous <= 1'b0;
            S_valid_streak  <= 2'd0;
            S_step_count    <= 8'd0;
            O_follow_active <= 1'b0;
        end else if (I_tilt_step_down && !I_tilt_step_up) begin
            step_tilt_negative;
            S_have_previous <= 1'b0;
            S_valid_streak  <= 2'd0;
            S_step_count    <= 8'd0;
            O_follow_active <= 1'b0;
        end else if (I_result_update) begin
            if (!I_target_valid) begin
                S_have_previous <= 1'b0;
                S_valid_streak  <= 2'd0;
                S_step_count    <= 8'd0;
                O_follow_active <= 1'b0;
            end else begin
                S_prev_x <= I_target_x;
                S_prev_y <= I_target_y;
                S_have_previous <= 1'b1;

                if (!S_have_previous || !S_position_continuous) begin
                    S_valid_streak  <= 2'd1;
                    S_step_count    <= 8'd0;
                    O_follow_active <= 1'b0;
                end else begin
                    if (S_valid_streak != 2'd3)
                        S_valid_streak <= S_valid_streak + 2'd1;

                    if (S_confirmed) begin
                        O_follow_active <= 1'b1;
                        if (S_step_count == RESULTS_PER_STEP - 8'd1) begin
                            S_step_count <= 8'd0;

                            if (S_target_right && !S_target_left) begin
                                if (HORIZONTAL_INVERT)
                                    step_base_negative;
                                else
                                    step_base_positive;
                            end else if (S_target_left && !S_target_right) begin
                                if (HORIZONTAL_INVERT)
                                    step_base_positive;
                                else
                                    step_base_negative;
                            end

                            if (S_target_down && !S_target_up) begin
                                if (VERTICAL_INVERT)
                                    step_tilt_negative;
                                else
                                    step_tilt_positive;
                            end else if (S_target_up && !S_target_down) begin
                                if (VERTICAL_INVERT)
                                    step_tilt_positive;
                                else
                                    step_tilt_negative;
                            end
                        end else begin
                            S_step_count <= S_step_count + 8'd1;
                        end
                    end
                end
            end
        end
    end
endmodule

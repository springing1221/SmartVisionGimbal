// Frame-safe application selector for the unified PH1P35 vision system.
// Only one expensive analysis branch is enabled at a time.
module unified_mode_controller #(
    parameter integer DEBOUNCE_CYCLES = 500000
) (
    input  wire       I_clk,
    input  wire       I_rst_n,
    input  wire       I_frame_start,
    input  wire [3:0] I_key_n,
    output reg  [1:0] O_app_mode,
    output reg  [3:0] O_filter_mode,
    output reg        O_night_mode,
    output reg        O_action_toggle,
    output wire       O_enable_gesture,
    output wire       O_enable_color_shape,
    output wire       O_enable_tracking,
    output wire       O_enable_filter
);
    localparam APP_FILTER      = 2'd0;
    localparam APP_GESTURE     = 2'd1;
    localparam APP_COLOR_SHAPE = 2'd2;
    localparam APP_TRACKING    = 2'd3;

    reg [3:0] key_meta, key_sync, key_stable, key_event;
    reg [19:0] debounce_count [0:3];
    reg [1:0] pending_app_mode;
    reg [3:0] pending_filter_mode;
    reg       pending_night_mode;
    integer i;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            key_meta <= 4'hf;
            key_sync <= 4'hf;
            key_stable <= 4'hf;
            key_event <= 4'd0;
            O_app_mode <= APP_FILTER;
            O_filter_mode <= 4'd0;
            O_night_mode <= 1'b0;
            O_action_toggle <= 1'b0;
            pending_app_mode <= APP_FILTER;
            pending_filter_mode <= 4'd0;
            pending_night_mode <= 1'b0;
            for (i = 0; i < 4; i = i + 1)
                debounce_count[i] <= 20'd0;
        end else begin
            key_meta <= I_key_n;
            key_sync <= key_meta;
            key_event <= 4'd0;
            for (i = 0; i < 4; i = i + 1) begin
                if (key_sync[i] == key_stable[i])
                    debounce_count[i] <= 20'd0;
                else if (debounce_count[i] == DEBOUNCE_CYCLES - 1) begin
                    debounce_count[i] <= 20'd0;
                    if (key_stable[i] && !key_sync[i])
                        key_event[i] <= 1'b1;
                    key_stable[i] <= key_sync[i];
                end else
                    debounce_count[i] <= debounce_count[i] + 1'b1;
            end

            // KEY1 advances the 14 real-time image effects.
            if (key_event[0])
                pending_filter_mode <= (pending_filter_mode == 4'd13) ? 4'd0 : pending_filter_mode + 1'b1;
            // KEY2 selects the application branch. The branch change is frame-latched.
            if (key_event[1])
                pending_app_mode <= pending_app_mode + 1'b1;
            // KEY3 is reserved for branch-specific action/arming in the top level.
            if (key_event[2])
                O_action_toggle <= ~O_action_toggle;
            // KEY4 changes the day/night image profile.
            if (key_event[3])
                pending_night_mode <= ~pending_night_mode;

            if (I_frame_start) begin
                O_app_mode <= pending_app_mode;
                O_filter_mode <= pending_filter_mode;
                O_night_mode <= pending_night_mode;
            end
        end
    end

    assign O_enable_filter      = (O_app_mode == APP_FILTER);
    assign O_enable_gesture     = (O_app_mode == APP_GESTURE);
    assign O_enable_color_shape = (O_app_mode == APP_COLOR_SHAPE);
    assign O_enable_tracking    = (O_app_mode == APP_TRACKING);
endmodule



module smart_vision_gimbal_top (
    input wire        I_sys_clk,
    input wire        I_rst_n,
      
    output wire       O_cam_scl,
    inout  wire       IO_cam_sda,
    output wire       O_cam_24m,
    output wire       O_cam_rst,
      
    input wire [3:0]  I_button,
    input wire [1:0]  I_switch,

    output wire       O_screen_pwm,
    output wire       O_gimbal_base_pwm,
    output wire       O_gimbal_tilt_pwm,
    output wire       O_tmds_ch0_p,
    output wire       O_tmds_ch1_p,
    output wire       O_tmds_ch2_p,
    output wire       O_tmds_clk_p,

    inout wire        IO_rx_clk_pad_n, 
    inout wire        IO_rx_clk_pad_p, 
    inout wire[3:0]   IO_rx_data_pad_n,
    inout wire[3:0]   IO_rx_data_pad_p,

    output wire[12:0] ddr_addr,
    output wire[ 1:0] ddr_ba,
    output wire[ 0:0] ddr_cke,
    output wire[ 0:0] ddr_odt,
    output wire[ 0:0] ddr_cs_n,
    output wire       ddr_ras_n,
    output wire       ddr_cas_n,
    output wire       ddr_we_n,
    output wire[ 0:0] ddr_ck_p,
    output wire[ 0:0] ddr_ck_n,
    inout wire[1:0]   ddr_dm,
    inout wire[15:0]  ddr_dq,
    inout wire[1:0]   ddr_dqs_p,
    inout wire[1:0]   ddr_dqs_n   
);


    wire        	S_100m_clk;
    wire        	S_24m_clk;
    wire        	S_aux_50m_clk;
	wire        	S_10m_clk;
		
	wire        	S_pll_lock;
    wire        	S_rst_n;
	reg  [17:0] 	S_cam_power_cnt;
	reg         	S_cam_pwdnb;
	reg         	S_cam_i2c_ready;
	(* keep = "true" *) wire [15:0] S_cam_sensor_id;
	(* keep = "true" *) wire        S_cam_sensor_id_ok;
	(* keep = "true" *) wire        S_cam_i2c_error;
	localparam integer CAM_PWDNB_LOW_CYCLES = 23810;  // >= 1 ms at 23.809524 MHz
	localparam integer CAM_I2C_START_CYCLES = 142857; // release + >= 5 ms
	
	wire [15:0] 	S_ae;
    wire [15:0] 	S_ag;
    wire 			S_cam_cfg_done;
    wire 			S_ae_cfg_done;
    wire 			S_ae_req; 

    /* No automatic exposure path in this isolated target-tracking build. */
    wire        S_manual_ae_req;
    wire [15:0] S_manual_ae;
    wire [15:0] S_manual_ag;
    wire        S_night_mode;
    wire        S_night_mode_legacy;
    wire        S_time_setting;
    wire [23:0] S_time_bcd;
    wire [1:0]  S_gain_key_n;
    reg [1:0]   S_gain_key_sync1, S_gain_key_sync2;
    wire [25:0] S_clock_display_hdmi;
    wire S_frame_store_start, S_frame_read_start;
    wire [1:0] S_frame_store_slot, S_frame_read_slot;
    wire [15:0] S_camera_frame_gray, S_read_frame_seq;
    wire S_read_frame_valid, S_read_frame_toggle;
    wire [9:0] S_camera_fps_tenths;
    wire S_camera_fps_valid, S_video_delay_valid;
    wire [7:0] S_video_delay_frames;
    wire S_roi_valid;
    wire S_roi_frame_start;
    wire [10:0] S_roi_x;
    wire [9:0] S_roi_y;
    wire        S_sensor_settings_ready;
    wire        S_detection_ready;
    reg [1:0]   S_sensor_ready_csi;
    reg [1:0]   S_setting_csi;
    reg         S_setting_csi_prev;
    wire S_setting_end_csi = S_setting_csi_prev && !S_setting_csi[1];
    reg         S_night_mode_csi_sync1;
    reg         S_night_mode_csi_sync2;
    reg         S_night_mode_csi_prev;
    wire        S_night_mode_change_csi = S_night_mode_csi_sync2 ^ S_night_mode_csi_prev;
    wire        S_tracking_switch;
    wire        S_tilt_step_up;
    wire        S_tilt_step_down;
	
	wire        	S_csi_rx_clk;  
    wire        	S_hs_rx_valid;  
    wire[15:0]  	S_hs_rx_data;   
	wire[1:0]   	S_lane_error;
	
	wire        	S_csi_frame_start;       
	wire        	S_csi_frame_end;         
	wire        	S_csi_valid;             
	wire[31:0]  	S_csi_data;  
	(* keep = "true" *) wire [15:0] S_csi_data_length;
		
	wire        	S_raw10_frame_start; 
	wire        	S_raw10_frame_end;   
	wire        	S_raw10_valid;       
	wire [39:0] 	S_raw10_data;

	wire 			S_axis_tlast;  
	wire 			S_axis_tuser;  
	wire [39:0]		S_axis_tdata;  
	wire 			S_axis_tvalid; 
	
	wire [39:0]		S_raw_tdata ;
	wire			S_raw_tlast ;
	wire 			S_raw_tvalid;
	wire 			S_raw_tuser ;
	
	wire			S_ISP_O_tready;
	wire [127:0]	S_ISP_O_tdata ;
	wire 			S_ISP_O_tlast ;
	wire 			S_ISP_O_tuser ;
	wire 			S_ISP_O_tvalid; 
	

    wire        S_ddr_clk;
    wire        S_hdmi_pixel_clk;
    wire        S_hdmi_serial_clk;
    wire        S_hdmi_rst_n;
    wire        S_video_out_rst_n;


    wire        S_vi_128b_frame_start;
    wire        S_vi_128b_valid;      
    wire[127:0] S_vi_128b_data;    
    
    wire        S_video_out_rd_busy;
    wire        S_video_in_wr_busy; 
    wire[1:0]   S_video_out_rp;     

    wire        S_ddr_user_wr_en;       
    wire        S_ddr_user_rd_en;       
    wire[24:0]  S_ddr_user_addr;        
    wire[127:0] S_ddr_user_wr_data;     
    wire        S_ddr_user_ready;       
    wire        S_ddr_user_rd_valid;    
    wire[127:0] S_ddr_user_rd_data;     

    wire        S_vi_ddr_wr_en;   
    wire[24:0]  S_vi_ddr_wr_addr; 
    wire[127:0] S_vi_ddr_wr_data;
    wire        S_vi_ddr_wr_ready;

    wire        S_vo_ddr_rd_en;   
    wire[24:0]  S_vo_ddr_rd_addr; 
    wire        S_vo_ddr_rd_ready;
    wire        S_vo_dbg_fifo_rst;
    wire        S_vo_dbg_ddr_rd_valid;
    wire        S_vo_dbg_fifo_rd_en;
    wire        S_vo_dbg_fifo_empty;

    wire        S_init_calib_complete; 
    wire[24:0]  S_mc_app_addr;          
    wire[2:0]   S_mc_app_cmd;           
    wire        S_mc_app_en;            
    wire[127:0] S_mc_app_wdf_data;      
    wire        S_mc_app_wdf_end;       
    wire[15:0]  S_mc_app_wdf_mask;      
    wire        S_mc_app_wdf_wren;      
    wire[127:0] S_mc_app_rd_data;       
    wire        S_mc_app_rd_data_end;   
    wire        S_mc_app_rd_data_valid; 
    wire        S_mc_app_rdy;           
    wire        S_mc_app_wdf_rdy;       
    wire        S_mc_dbg_fifo_afull;
    wire        S_mc_dbg_app_rdy;
    wire        S_mc_dbg_wdf_rdy;
    wire        S_mc_dbg_cmd_pop;

    wire        S_hdmi_vsync;
    wire        S_hdmi_hsync;
    wire        S_hdmi_de;
    wire        S_hdmi_user;
    wire        S_hdmi_last;
    wire        S_video_out_vsync;
    wire        S_hdmi_window_rd_en;
    wire        S_hdmi_out_vsync;
    wire        S_hdmi_out_hsync;
    wire        S_hdmi_out_de;
    wire[23:0]  S_hdmi_out_data;
    wire[23:0]  S_hdmi_out_data_final;
    // Unified post-mixer filter path.  It reuses the HDMI pixel clock and
    // existing OSD output, so it adds no capture-side or DDR frame buffer.
    wire [23:0] S_unified_filter_data;
    wire [23:0] S_pre_osd_video_data;
    wire [1:0]  S_unified_app_mode;
    wire [3:0]  S_unified_filter_mode;
    wire        S_unified_night_request;
    assign S_night_mode = S_unified_night_request;
    wire        S_unified_filter_enable;
    wire        S_unified_gesture_enable, S_unified_color_enable, S_unified_tracking_enable;
    wire        S_unified_action_toggle;
    reg [1:0]   S_unified_action_csi;
    wire        S_unified_gesture_rearm = S_unified_action_csi[1];
    wire S_hand_valid;
    wire [8:0] S_hand_xmin, S_hand_xmax;
    wire [7:0] S_hand_ymin, S_hand_ymax;
    wire [3:0] S_gesture_code;
    wire S_red_valid, S_green_valid, S_blue_valid, S_yellow_valid;
    wire [10:0] S_red_xmin, S_red_xmax, S_green_xmin, S_green_xmax, S_blue_xmin, S_blue_xmax, S_yellow_xmin, S_yellow_xmax;
    wire [9:0] S_red_ymin, S_red_ymax, S_green_ymin, S_green_ymax, S_blue_ymin, S_blue_ymax, S_yellow_ymin, S_yellow_ymax;
    wire [2:0] S_red_shape, S_green_shape, S_blue_shape, S_yellow_shape;
    wire        S_person_box_done;
    wire        S_person_box_valid;
    wire [10:0] S_person_x0, S_person_x1;
    wire [9:0]  S_person_y0, S_person_y1;
    wire [11:0] S_person_center_x_sum;
    wire [10:0] S_person_center_y_sum;
    wire [10:0] S_gimbal_target_x;
    wire [9:0]  S_gimbal_target_y;
    wire        S_gimbal_target_valid;
    wire        S_gimbal_result_update;
    wire [10:0] S_gimbal_base_ticks;
    wire [10:0] S_gimbal_tilt_ticks;
    wire        S_gimbal_follow_active;
    wire S_track_permit;
    reg [1:0] S_rebuild_guard;
    reg [1:0] S_detect_guard_sync;
    reg [7:0] S_rebuild_delay;
    wire S_tracking_enable = S_unified_tracking_enable && S_track_permit &&
                             !S_time_setting && S_rebuild_guard == 2'd0;
    wire [2:0] S_track_status;
    reg         S_person_toggle;
    reg [42:0]  S_person_box_hold;
    reg [1:0]   S_person_missed_frames;
    reg [1:0]   S_person_toggle_sync;
    reg         S_person_toggle_seen;
    reg [42:0]  S_person_box_pending;
    reg [42:0]  S_person_box_hdmi;
    reg [2:0]   S_track_status_hdmi_sync1;
    reg [2:0]   S_track_status_hdmi_sync2;
    reg         S_hdmi_vsync_prev;
    always @(posedge S_100m_clk or negedge S_rst_n) begin
        if (!S_rst_n) begin
            S_rebuild_guard <= 0;
            S_detect_guard_sync <= 0;
            S_rebuild_delay <= 0;
        end else begin
            S_detect_guard_sync <= {S_detect_guard_sync[0], S_detection_ready};
            if (S_time_setting) begin
                S_rebuild_guard <= 1;
                S_rebuild_delay <= 0;
            end else if (S_rebuild_guard == 1 && S_rebuild_delay != 8'hff)
                S_rebuild_delay <= S_rebuild_delay + 1'b1;
            else if (S_rebuild_guard == 1 && !S_detect_guard_sync[1])
                S_rebuild_guard <= 2;
            else if (S_rebuild_guard == 2 && S_detect_guard_sync[1])
                S_rebuild_guard <= 0;
        end
    end
    wire[23:0]  S_video_rd_data;
    reg         S_dbg_raw_seen;
    reg         S_dbg_isp_seen;
    reg         S_dbg_ddr_wr_seen;
    reg         S_dbg_ddr_rd_seen;
    reg         S_dbg_cam_cfg_seen;
    reg         S_dbg_hs_seen;
    reg         S_dbg_csi_seen;
    reg         S_dbg_raw10_seen;
    reg         S_dbg_isp_fs_seen;
    reg         S_dbg_isp_valid_seen;
    reg         S_dbg_ddr_req_seen;
    reg         S_dbg_ddr_ready_seen;
    reg [1:0]   S_dbg_raw_seen_sync;
    reg [1:0]   S_dbg_isp_seen_sync;
    reg [1:0]   S_dbg_ddr_wr_seen_sync;
    reg [1:0]   S_dbg_ddr_rd_seen_sync;
    reg [1:0]   S_dbg_cam_cfg_seen_sync;
    reg [1:0]   S_dbg_hs_seen_sync;
    reg [1:0]   S_dbg_csi_seen_sync;
    reg [1:0]   S_dbg_raw10_seen_sync;
    reg [1:0]   S_dbg_isp_fs_seen_sync;
    reg [1:0]   S_dbg_isp_valid_seen_sync;
    reg [1:0]   S_dbg_ddr_req_seen_sync;
    reg [1:0]   S_dbg_ddr_ready_seen_sync;
    reg         S_dbg_video_nonzero_seen;
    reg         S_dbg_rd_req_seen;
    reg         S_dbg_rd_valid_seen;
    reg         S_dbg_rd_nonzero_seen;
    reg [1:0]   S_dbg_rd_req_seen_sync;
    reg [1:0]   S_dbg_rd_valid_seen_sync;
    reg [1:0]   S_dbg_rd_nonzero_seen_sync;
    reg         S_dbg_mc_init_seen;
    reg         S_dbg_mc_app_rdy_seen;
    reg         S_dbg_mc_wdf_rdy_seen;
    reg         S_dbg_mc_cmd_pop_seen;
    reg [1:0]   S_dbg_mc_init_seen_sync;
    reg [1:0]   S_dbg_mc_app_rdy_seen_sync;
    reg [1:0]   S_dbg_mc_wdf_rdy_seen_sync;
    reg [1:0]   S_dbg_mc_cmd_pop_seen_sync;
    wire[3:0]   S_hdmi_debug_status;
    wire        S_lane_error_any;
    wire        S_csi_packet_start;
    reg         S_csi_length_active_d;
    reg [10:0]  S_mipi_line_count;
    reg         S_mipi_length_error;
    reg         S_mipi_lane_error;
    reg         S_mipi_frame_seen;
    reg         S_mipi_frame_done;
    reg         S_mipi_last_length_error;
    reg         S_mipi_last_line_error;
    reg         S_mipi_last_lane_error;
    reg         S_mipi_good_frame_toggle;
    wire[3:0]   S_mipi_diag_status_async;
    reg [3:0]   S_mipi_diag_status_sync1;
    reg [3:0]   S_mipi_diag_status_sync2;


    assign O_screen_pwm = 1'b1;
    assign S_video_out_vsync = ~S_hdmi_vsync;
    assign S_person_center_x_sum = {1'b0, S_person_x0} + {1'b0, S_person_x1};
    assign S_person_center_y_sum = {1'b0, S_person_y0} + {1'b0, S_person_y1};

    gimbal_result_cdc u_gimbal_result_cdc (
        .I_src_clk    ( S_csi_rx_clk          ),
        .I_src_rst_n  ( S_rst_n               ),
        .I_src_update ( S_person_box_done     ),
        .I_src_x      ( S_person_center_x_sum[11:1] ),
        .I_src_y      ( S_person_center_y_sum[10:1] ),
        .I_src_valid  ( S_person_box_valid    ),
        .I_dst_clk    ( S_100m_clk            ),
        .I_dst_rst_n  ( S_rst_n               ),
        .O_dst_x      ( S_gimbal_target_x     ),
        .O_dst_y      ( S_gimbal_target_y     ),
        .O_dst_valid  ( S_gimbal_target_valid ),
        .O_dst_update ( S_gimbal_result_update)
    );

    // SW1 enables tracking; SW2 switches the four keys to clock setting.
    switch_level_filter u_tracking_switch (
        .I_clk(S_100m_clk), .I_rst_n(S_rst_n), .I_switch(I_switch[0]),
        .O_level(S_tracking_switch)
    );

    switch_level_filter u_time_setting_switch (
        .I_clk(S_100m_clk), .I_rst_n(S_rst_n), .I_switch(I_switch[1]),
        .O_level(S_time_setting)
    );

    scheduled_clock_ctrl u_scheduled_clock (
        .I_clk(S_100m_clk), .I_rst_n(S_rst_n),
        .I_setting(S_time_setting), .I_key_n(I_button),
        .O_gain_key_n(S_gain_key_n),
        .O_tilt_step_up(S_tilt_step_up),
        .O_tilt_step_down(S_tilt_step_down),
        .O_time_bcd(S_time_bcd),
        .O_night_mode(S_night_mode_legacy)
    );

    clock_display_cdc u_clock_display_cdc (
        .I_src_clk(S_100m_clk), .I_src_rst_n(S_rst_n),
        .I_src_data({S_time_setting, S_night_mode, S_time_bcd}),
        .I_dst_clk(S_hdmi_pixel_clk), .I_dst_rst_n(S_hdmi_rst_n),
        .I_dst_frame_start(S_hdmi_vsync && !S_hdmi_vsync_prev),
        .O_dst_data(S_clock_display_hdmi)
    );

    gimbal_auto_follow_1280x720 #(
        // Reverse V14 automatic following; manual keys are unchanged.
        .HORIZONTAL_INVERT ( 1'b1 ),
        .VERTICAL_INVERT   ( 1'b1 )
    ) u_gimbal_auto_follow (
        .I_clk              ( S_100m_clk            ),
        .I_rst_n            ( S_rst_n               ),
        .I_enable           ( S_tracking_enable   ),
        .I_tilt_step_up     ( S_tilt_step_up      ),
        .I_tilt_step_down   ( S_tilt_step_down    ),
        .I_result_update    ( S_gimbal_result_update ),
        .I_target_valid     ( S_gimbal_target_valid  ),
        .I_target_x         ( S_gimbal_target_x      ),
        .I_target_y         ( S_gimbal_target_y      ),
        .O_base_pulse_ticks ( S_gimbal_base_ticks    ),
        .O_tilt_pulse_ticks ( S_gimbal_tilt_ticks    ),
        .O_follow_active    ( S_gimbal_follow_active )
    );

    gimbal_pwm_dual u_gimbal_pwm_dual (
        .I_clk              ( S_100m_clk          ),
        .I_rst_n            ( S_rst_n             ),
        .I_base_pulse_ticks ( S_gimbal_base_ticks ),
        .I_tilt_pulse_ticks ( S_gimbal_tilt_ticks ),
        .O_pwm_base         ( O_gimbal_base_pwm   ),
        .O_pwm_tilt         ( O_gimbal_tilt_pwm   )
    );

    startup_supervisor u_startup_supervisor (
        .I_clk(S_100m_clk), .I_rst_n(S_rst_n),
        .I_cam_cfg_done(S_cam_cfg_done), .I_ae_cfg_done(S_ae_cfg_done),
        .I_i2c_error(S_cam_i2c_error),
        .I_good_frame_toggle(S_mipi_good_frame_toggle),
        .I_detection_ready(S_detection_ready),
        .I_tracking_switch(S_unified_tracking_enable && !S_time_setting && S_rebuild_guard == 0),
        .I_follow_active(S_gimbal_follow_active),
        .O_sensor_ready(S_sensor_settings_ready),
        .O_track_permit(S_track_permit),
        .O_i2c_warning(),
        .O_status(S_track_status)
    );

    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if (!S_rst_n) begin
            S_person_toggle <= 1'b0;
            S_person_box_hold <= 43'd0;
            S_person_missed_frames <= 2'd0;
        end else if (!S_detection_ready) begin
            if (S_person_box_hold[42]) begin
                S_person_box_hold[42] <= 1'b0;
                S_person_toggle <= ~S_person_toggle;
            end
            S_person_missed_frames <= 0;
        end else if (S_person_box_done) begin
            if (S_person_box_valid) begin
                S_person_box_hold <= {1'b1, S_person_x0,
                                      S_person_y0, S_person_x1, S_person_y1};
                S_person_toggle <= ~S_person_toggle;
                S_person_missed_frames <= 2'd0;
            end else if (S_person_missed_frames == 2'd2) begin
                S_person_box_hold[42] <= 1'b0;
                S_person_toggle <= ~S_person_toggle;
                S_person_missed_frames <= 2'd3;
            end else if (S_person_missed_frames != 2'd3) begin
                S_person_missed_frames <= S_person_missed_frames + 2'd1;
            end
        end
    end

    always @(posedge S_hdmi_pixel_clk or negedge S_hdmi_rst_n) begin
        if (!S_hdmi_rst_n) begin
            S_person_toggle_sync <= 2'b00;
            S_person_toggle_seen <= 1'b0;
            S_person_box_pending <= 43'd0;
            S_person_box_hdmi <= 43'd0;
            S_track_status_hdmi_sync1 <= 3'd0;
            S_track_status_hdmi_sync2 <= 3'd0;
            S_hdmi_vsync_prev <= 1'b0;
        end else begin
            S_person_toggle_sync <= {S_person_toggle_sync[0], S_person_toggle};
            S_track_status_hdmi_sync1 <= S_track_status;
            S_track_status_hdmi_sync2 <= S_track_status_hdmi_sync1;
            S_hdmi_vsync_prev <= S_hdmi_vsync;
            if (S_person_toggle_sync[1] != S_person_toggle_seen) begin
                S_person_toggle_seen <= S_person_toggle_sync[1];
                S_person_box_pending <= S_person_box_hold;
            end
            if (S_hdmi_vsync && !S_hdmi_vsync_prev)
                S_person_box_hdmi <= S_person_box_pending;
        end
    end

	
    assign S_rst_n 		= S_pll_lock;
    assign S_hdmi_rst_n = S_pll_lock;

    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_raw_seen <= 1'b0;
        else if(S_raw10_frame_start | S_axis_tvalid)
            S_dbg_raw_seen <= 1'b1;
    end

    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_isp_seen <= 1'b0;
        else if(S_ISP_O_tuser | S_ISP_O_tvalid)
            S_dbg_isp_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_ddr_wr_seen <= 1'b0;
        else if(S_vi_ddr_wr_en)
            S_dbg_ddr_wr_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_ddr_rd_seen <= 1'b0;
        else if(S_ddr_user_rd_valid)
            S_dbg_ddr_rd_seen <= 1'b1;
    end

    always @(posedge S_24m_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_cam_cfg_seen <= 1'b0;
        else if(S_cam_cfg_done)
            S_dbg_cam_cfg_seen <= 1'b1;
    end

    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if (!S_rst_n) begin
            S_night_mode_csi_sync1 <= 1'b0;
            S_night_mode_csi_sync2 <= 1'b0;
            S_night_mode_csi_prev <= 1'b0;
            S_sensor_ready_csi <= 0;
            S_setting_csi <= 0;
            S_setting_csi_prev <= 0;
        end else begin
            S_night_mode_csi_sync1 <= S_night_mode;
            S_night_mode_csi_sync2 <= S_night_mode_csi_sync1;
            S_night_mode_csi_prev <= S_night_mode_csi_sync2;
            S_sensor_ready_csi <= {S_sensor_ready_csi[0], S_sensor_settings_ready};
            S_setting_csi <= {S_setting_csi[0], S_time_setting};
            S_setting_csi_prev <= S_setting_csi[1];
        end
    end

    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_hs_seen <= 1'b0;
        else if(S_hs_rx_valid)
            S_dbg_hs_seen <= 1'b1;
    end

    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_csi_seen <= 1'b0;
        else if(S_csi_frame_start | S_csi_valid)
            S_dbg_csi_seen <= 1'b1;
    end

    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_raw10_seen <= 1'b0;
        else if(S_raw10_frame_start | S_raw10_valid)
            S_dbg_raw10_seen <= 1'b1;
    end

    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_isp_fs_seen <= 1'b0;
        else if(S_ISP_O_tuser)
            S_dbg_isp_fs_seen <= 1'b1;
    end

    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_isp_valid_seen <= 1'b0;
        else if(S_ISP_O_tvalid)
            S_dbg_isp_valid_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_ddr_req_seen <= 1'b0;
        else if(S_vi_ddr_wr_en)
            S_dbg_ddr_req_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_ddr_ready_seen <= 1'b0;
        else if(S_ddr_user_ready)
            S_dbg_ddr_ready_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_video_out_rst_n) begin
        if(!S_video_out_rst_n)
            S_dbg_rd_req_seen <= 1'b0;
        else if(S_video_out_vsync)
            S_dbg_rd_req_seen <= 1'b0;
        else if(S_vo_ddr_rd_en)
            S_dbg_rd_req_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_video_out_rst_n) begin
        if(!S_video_out_rst_n)
            S_dbg_rd_valid_seen <= 1'b0;
        else if(S_video_out_vsync)
            S_dbg_rd_valid_seen <= 1'b0;
        else if(S_ddr_user_rd_valid)
            S_dbg_rd_valid_seen <= 1'b1;
    end

    always @(posedge S_hdmi_pixel_clk or negedge S_video_out_rst_n) begin
        if(!S_video_out_rst_n)
            S_dbg_rd_nonzero_seen <= 1'b0;
        else if(S_video_out_vsync)
            S_dbg_rd_nonzero_seen <= 1'b0;
        else if(S_hdmi_window_rd_en && (S_video_rd_data != 24'd0))
            S_dbg_rd_nonzero_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_mc_init_seen <= 1'b0;
        else if(S_init_calib_complete)
            S_dbg_mc_init_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_mc_app_rdy_seen <= 1'b0;
        else if(S_mc_dbg_app_rdy)
            S_dbg_mc_app_rdy_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_mc_wdf_rdy_seen <= 1'b0;
        else if(S_mc_dbg_wdf_rdy)
            S_dbg_mc_wdf_rdy_seen <= 1'b1;
    end

    always @(posedge S_ddr_clk or negedge S_rst_n) begin
        if(!S_rst_n)
            S_dbg_mc_cmd_pop_seen <= 1'b0;
        else if(S_mc_dbg_cmd_pop)
            S_dbg_mc_cmd_pop_seen <= 1'b1;
    end

    always @(posedge S_hdmi_pixel_clk or negedge S_hdmi_rst_n) begin
        if(!S_hdmi_rst_n) begin
            S_dbg_cam_cfg_seen_sync <= 2'b00;
            S_dbg_hs_seen_sync      <= 2'b00;
            S_dbg_csi_seen_sync     <= 2'b00;
            S_dbg_raw10_seen_sync   <= 2'b00;
            S_dbg_raw_seen_sync    <= 2'b00;
            S_dbg_isp_seen_sync    <= 2'b00;
            S_dbg_ddr_wr_seen_sync <= 2'b00;
            S_dbg_ddr_rd_seen_sync <= 2'b00;
            S_dbg_isp_fs_seen_sync  <= 2'b00;
            S_dbg_isp_valid_seen_sync <= 2'b00;
            S_dbg_ddr_req_seen_sync <= 2'b00;
            S_dbg_ddr_ready_seen_sync <= 2'b00;
            S_dbg_video_nonzero_seen <= 1'b0;
            S_dbg_rd_req_seen_sync <= 2'b00;
            S_dbg_rd_valid_seen_sync <= 2'b00;
            S_dbg_rd_nonzero_seen_sync <= 2'b00;
            S_dbg_mc_init_seen_sync <= 2'b00;
            S_dbg_mc_app_rdy_seen_sync <= 2'b00;
            S_dbg_mc_wdf_rdy_seen_sync <= 2'b00;
            S_dbg_mc_cmd_pop_seen_sync <= 2'b00;
        end
        else begin
            S_dbg_cam_cfg_seen_sync <= {S_dbg_cam_cfg_seen_sync[0], S_dbg_cam_cfg_seen};
            S_dbg_hs_seen_sync      <= {S_dbg_hs_seen_sync[0],      S_dbg_hs_seen};
            S_dbg_csi_seen_sync     <= {S_dbg_csi_seen_sync[0],     S_dbg_csi_seen};
            S_dbg_raw10_seen_sync   <= {S_dbg_raw10_seen_sync[0],   S_dbg_raw10_seen};
            S_dbg_raw_seen_sync    <= {S_dbg_raw_seen_sync[0],    S_dbg_raw_seen};
            S_dbg_isp_seen_sync    <= {S_dbg_isp_seen_sync[0],    S_dbg_isp_seen};
            S_dbg_ddr_wr_seen_sync <= {S_dbg_ddr_wr_seen_sync[0], S_dbg_ddr_wr_seen};
            S_dbg_ddr_rd_seen_sync <= {S_dbg_ddr_rd_seen_sync[0], S_dbg_ddr_rd_seen};
            S_dbg_isp_fs_seen_sync  <= {S_dbg_isp_fs_seen_sync[0],  S_dbg_isp_fs_seen};
            S_dbg_isp_valid_seen_sync <= {S_dbg_isp_valid_seen_sync[0], S_dbg_isp_valid_seen};
            S_dbg_ddr_req_seen_sync <= {S_dbg_ddr_req_seen_sync[0], S_dbg_ddr_req_seen};
            S_dbg_ddr_ready_seen_sync <= {S_dbg_ddr_ready_seen_sync[0], S_dbg_ddr_ready_seen};
            S_dbg_rd_req_seen_sync <= {S_dbg_rd_req_seen_sync[0], S_dbg_rd_req_seen};
            S_dbg_rd_valid_seen_sync <= {S_dbg_rd_valid_seen_sync[0], S_dbg_rd_valid_seen};
            S_dbg_rd_nonzero_seen_sync <= {S_dbg_rd_nonzero_seen_sync[0], S_dbg_rd_nonzero_seen};
            S_dbg_mc_init_seen_sync <= {S_dbg_mc_init_seen_sync[0], S_dbg_mc_init_seen};
            S_dbg_mc_app_rdy_seen_sync <= {S_dbg_mc_app_rdy_seen_sync[0], S_dbg_mc_app_rdy_seen};
            S_dbg_mc_wdf_rdy_seen_sync <= {S_dbg_mc_wdf_rdy_seen_sync[0], S_dbg_mc_wdf_rdy_seen};
            S_dbg_mc_cmd_pop_seen_sync <= {S_dbg_mc_cmd_pop_seen_sync[0], S_dbg_mc_cmd_pop_seen};
            if(S_hdmi_window_rd_en && (S_video_rd_data != 24'd0))
                S_dbg_video_nonzero_seen <= 1'b1;
        end
    end

    assign S_lane_error_any = |S_lane_error;

    // A RAW10 line contains 1280 * 10 / 8 = 1600 bytes.  The CSI parser
    // reports the number of 16-bit lane words, therefore the expected value
    // is 1600 / 2 = 800 = 16'h0320.  Count one long packet whenever that
    // decoded length changes from zero to non-zero.
    assign S_csi_packet_start = (S_csi_data_length != 16'd0) &&
                                !S_csi_length_active_d;

    always @(posedge S_csi_rx_clk or negedge S_rst_n) begin
        if(!S_rst_n) begin
            S_csi_length_active_d      <= 1'b0;
            S_mipi_line_count          <= 11'd0;
            S_mipi_length_error        <= 1'b0;
            S_mipi_lane_error          <= 1'b0;
            S_mipi_frame_seen          <= 1'b0;
            S_mipi_frame_done          <= 1'b0;
            S_mipi_last_length_error   <= 1'b0;
            S_mipi_last_line_error     <= 1'b0;
            S_mipi_last_lane_error     <= 1'b0;
            S_mipi_good_frame_toggle   <= 1'b0;
        end
        else begin
            S_csi_length_active_d <= (S_csi_data_length != 16'd0);

            if(S_csi_frame_start) begin
                S_mipi_line_count   <= 11'd0;
                S_mipi_length_error <= 1'b0;
                S_mipi_lane_error   <= 1'b0;
                S_mipi_frame_seen   <= 1'b1;
            end
            else begin
                if(S_csi_packet_start) begin
                    S_mipi_line_count <= S_mipi_line_count + 11'd1;
                    if(S_csi_data_length != 16'h0320)
                        S_mipi_length_error <= 1'b1;
                end

                if(S_lane_error_any)
                    S_mipi_lane_error <= 1'b1;
            end

            // Publish only a completed frame, so the HDMI-domain diagnostic
            // sees a stable result rather than counters changing every line.
            if(S_csi_frame_end) begin
                S_mipi_frame_done        <= 1'b1;
                S_mipi_last_length_error <= S_mipi_length_error;
                S_mipi_last_line_error   <= (S_mipi_line_count != 11'd720);
                S_mipi_last_lane_error   <= S_mipi_lane_error |
                                            S_lane_error_any;
                if (S_mipi_frame_seen && !S_mipi_length_error &&
                    S_mipi_line_count == 11'd720 &&
                    !(S_mipi_lane_error | S_lane_error_any))
                    S_mipi_good_frame_toggle <= ~S_mipi_good_frame_toggle;
            end
        end
    end

    // Diagnostic result codes consumed by hdmi_mixer DEBUG_MODE=4:
    // 0=config incomplete, 1=no HS traffic, 2=no completed CSI frame,
    // 3=lane error, 4=wrong RAW10 line length, 5=wrong lines/frame,
    // 6=the observed MIPI frame structure is correct, 7=I2C error.
    // I2C error has the highest priority because O_cfg_done only indicates
    // that the write sequencer reached its end; it does not prove that every
    // sensor register write was acknowledged successfully.
    assign S_mipi_diag_status_async =
        S_cam_i2c_error              ? 4'd7 :
        !S_cam_cfg_done              ? 4'd0 :
        !S_dbg_hs_seen               ? 4'd1 :
        !(S_mipi_frame_seen &&
          S_mipi_frame_done)         ? 4'd2 :
        S_mipi_last_lane_error       ? 4'd3 :
        S_mipi_last_length_error     ? 4'd4 :
        S_mipi_last_line_error       ? 4'd5 : 4'd6;

    always @(posedge S_hdmi_pixel_clk or negedge S_hdmi_rst_n) begin
        if(!S_hdmi_rst_n) begin
            S_mipi_diag_status_sync1 <= 4'd0;
            S_mipi_diag_status_sync2 <= 4'd0;
        end
        else begin
            S_mipi_diag_status_sync1 <= S_mipi_diag_status_async;
            S_mipi_diag_status_sync2 <= S_mipi_diag_status_sync1;
        end
    end

    assign S_vo_dbg_fifo_rst = 1'b0;
    assign S_vo_dbg_ddr_rd_valid = 1'b0;
    assign S_vo_dbg_fifo_rd_en = 1'b0;
    assign S_vo_dbg_fifo_empty = 1'b0;
    assign S_mc_dbg_fifo_afull = 1'b0;
    assign S_mc_dbg_app_rdy = 1'b0;
    assign S_mc_dbg_wdf_rdy = 1'b0;
    assign S_mc_dbg_cmd_pop = 1'b0;

    assign S_hdmi_debug_status = S_mipi_diag_status_sync2;
	
	// J9 pin 37 is connected to the module's PWDNB/XSHUTDN input.
	// Hold the sensor in power-down after PLL lock, then allow its internal
	// power-up sequence to finish before the first I2C transaction.
	always @(posedge S_24m_clk or negedge S_pll_lock) begin
		if (!S_pll_lock) begin
			S_cam_power_cnt <= 18'd0;
			S_cam_pwdnb <= 1'b0;
			S_cam_i2c_ready <= 1'b0;
		end else begin
			if (S_cam_power_cnt < CAM_I2C_START_CYCLES)
				S_cam_power_cnt <= S_cam_power_cnt + 1'b1;
			if (S_cam_power_cnt >= CAM_PWDNB_LOW_CYCLES)
				S_cam_pwdnb <= 1'b1;
			if (S_cam_power_cnt >= CAM_I2C_START_CYCLES - 1)
				S_cam_i2c_ready <= 1'b1;
		end
	end

	assign O_cam_rst 	= S_cam_pwdnb;
    assign O_cam_24m 	= S_24m_clk;
	
	
	
	
    PLL u_PLL(
        .refclk      ( I_sys_clk         ),
        .reset    	 ( ~I_rst_n          ),
        
        .clk0_out    ( S_100m_clk        ),
        .clk1_out    ( S_24m_clk         ),

        .clk4_out    ( S_hdmi_pixel_clk  ),
        .clk5_out    ( S_hdmi_serial_clk ),

        .lock        ( S_pll_lock        )

    );


	

  
    always @(posedge S_24m_clk or negedge S_rst_n) begin
        if (!S_rst_n) begin
            S_gain_key_sync1 <= 2'b11;
            S_gain_key_sync2 <= 2'b11;
        end else begin
            S_gain_key_sync1 <= S_gain_key_n;
            S_gain_key_sync2 <= S_gain_key_sync1;
        end
    end

  ae_set u_ae_set (
      .I_clk(S_24m_clk),
      .I_rst(~S_rst_n),
      .I_btn({S_gain_key_sync2,2'b11}),
      .I_cam_cfg_done(S_cam_cfg_done),
      .I_ae_cfg_done(S_ae_cfg_done),
      .O_ae_req(S_manual_ae_req),
      .O_ae(S_manual_ae),
      .O_ag(S_manual_ag)
  );

    // Restore V6's direct manual camera-control path. KEY1 lowers and KEY2
    // raises analog gain; AE remains at the V6 720p60 maximum of 1991.
    // Clock scheduling changes only the FPGA image and detector mode;
    // KEY1/KEY2 still set sensor gain outside the clock editor.
    assign S_ae_req = S_manual_ae_req;
    assign S_ae = S_manual_ae;
    assign S_ag = S_manual_ag;
  
    uicfgcs520 #(
      .CLK_DIV(23809524 / 100000 - 1)
  ) u_uicfgcs520 (
      .I_clk(S_24m_clk),  //系统时钟输入
      .I_rst_n(S_cam_i2c_ready), // SC520CS power-up delay completed
      .I_ae_req(S_ae_req),
      .I_ae(S_ae),
      .I_ag(S_ag),
      .O_cam_scl(O_cam_scl),  //I2C总线，SCL时钟
      .IO_cam_sda(IO_cam_sda),  //I2C总线，SDA数据
      .O_cfg_done(S_cam_cfg_done),  //摄像头寄存器初始化完成
      .O_ae_cfg_done(S_ae_cfg_done),  //AE配置完成
      .O_sensor_id(S_cam_sensor_id),
      .O_sensor_id_ok(S_cam_sensor_id_ok),
      .O_iic_error(S_cam_i2c_error)
  );
	
    mipi_dphy_rx_ph1p_mipiio_wrapper#(
        .DPHY_RX_LOCATION      ( "DPHY0" ),
        .HS_EQUALIZER          ( "3dB"   ),// 828 Mbps/Lane接收均衡
        .HS_VGA_GAIN           ( "8dB" ),//"-3dB","-1.5dB","0dB","1.5dB","3dB","4.5dB","6dB","7.5dB"
        .LANE_NUM              ( 2       ),
        .BYTE_NUM              ( 1       )
    )u_mipi_dphy_rx_ph1p_mipiio_wrapper(
        .I_lp_clk              ( S_100m_clk       ),
        .I_rst                 ( ~S_rst_n         ),

        .I_clk_lane_in_delay   ( 6'd0             ),
        .I_data_lane0_in_delay ( 6'd0             ),
        .I_data_lane1_in_delay ( 6'd0             ),
        .I_data_lane2_in_delay ( 6'd0             ),
        .I_data_lane3_in_delay ( 6'd0             ),

        .I_lane_invert         ( 4'b0000          ),
     
        .O_hs_rx_clk           ( S_csi_rx_clk     ),
        .O_hs_rx_valid         ( S_hs_rx_valid    ),
        .O_hs_rx_data          ( S_hs_rx_data     ),
      
        .O_lp_rx_lane0_p       (  ),
        .O_lp_rx_lane0_n       (  ),
      
        .I_lp_tx_en            ( 1'b0             ),
        .I_lp_tx_lane0_p       ( 1'b1             ),
        .I_lp_tx_lane0_n       ( 1'b1             ),
      
        .O_lane_match_error    (                  ),
        .O_lane_error          ( S_lane_error     ),
      
        .IO_rx_clk_pad_n       ( IO_rx_clk_pad_n  ),
        .IO_rx_clk_pad_p       ( IO_rx_clk_pad_p  ),
        .IO_rx_data_pad_n      ( IO_rx_data_pad_n ),
        .IO_rx_data_pad_p      ( IO_rx_data_pad_p )
    );
	
	
 //  cwc cwc_inst
 //(
 //    .probe0(S_hs_rx_valid),
 //    .probe1(S_hs_rx_data),
 //    .probe2(S_lane_error),
 //    .clk(S_csi_rx_clk)
 //);

 //csi 解码为RAW数据
csi_unpacket_2lane u_csi_unpacket(
.I_clk                 ( S_csi_rx_clk       ),
.I_rst_n               ( S_rst_n        	),
.I_hs_valid            ( S_hs_rx_valid     ),
.I_hs_data             ( S_hs_rx_data      ),

.O_csi_frame_start     ( S_csi_frame_start ),
.O_csi_frame_end       ( S_csi_frame_end   ),
.O_csi_valid           ( S_csi_valid       ),
.O_csi_data            ( S_csi_data        ),
.O_data_length         ( S_csi_data_length )
);


//解码为RAW8
raw10_unpacket_2lane u_raw10_unpacket (
.I_clk  (S_csi_rx_clk),
.I_rst_n(S_rst_n),

.I_csi_frame_start(S_csi_frame_start),
.I_csi_frame_end  (S_csi_frame_end),
.I_csi_valid      (S_csi_valid),
.I_csi_data       (S_csi_data),

.O_raw10_frame_start(S_raw10_frame_start),
.O_raw10_frame_end  (S_raw10_frame_end),
.O_raw10_valid      (S_raw10_valid),
.O_raw10_data       (S_raw10_data)
  );


//将数据转为stream流
uial2axis #(
.IMG_WIDTH(1280),
.IMG_HEIGHT(720),
.INPUT_DATA_WIDTH(40)
) 
u_uial2axis (
.I_native_clk(S_csi_rx_clk),
.I_rst_n     (S_rst_n),
.I_data      (S_raw10_data       ),
.I_data_valid(S_raw10_valid      ),
.I_data_start(S_raw10_frame_start),
.I_data_end  (S_raw10_frame_end  ),
.axis_tvalid (S_axis_tvalid),
.axis_tdata  (S_axis_tdata ),
.axis_tuser  (S_axis_tuser ),
.axis_tlast  (S_axis_tlast )
);
	

// SC520CS原厂HD模式已经直接输出1280x720 RAW10，无需FPGA窗口裁剪。
assign S_raw_tdata  = S_axis_tdata;
assign S_raw_tlast  = S_axis_tlast;
assign S_raw_tvalid = S_axis_tvalid;
assign S_raw_tuser  = S_axis_tuser;


//cwc1 cwc1_Inst
//  (
//      .probe0(S_axis_tuser),
//      .probe1(S_axis_tvalid),
//      .probe2(S_axis_tlast),
//      .probe3(S_axis_tdata),
//      .probe4(S_ISP_O_tuser),
//      .probe5(S_ISP_O_tvalid),
//      .probe6(S_ISP_O_tlast),
//      .probe7(S_ISP_O_tdata),
//      .probe8 (S_raw_tdata ),
//      .probe9 (S_raw_tlast ),
//      .probe10(S_raw_tvalid),
//      .probe11(S_raw_tuser ),
//      .clk(S_csi_rx_clk)
//  );


//ISP算法顶层模块
isp_top u_isp_top (
.axi4s_video_aclk(S_csi_rx_clk),
.I_rst_n         (S_rst_n),
.I_night_mode     (S_night_mode_csi_sync2),
.I_sensor_ready   (S_sensor_ready_csi[1]),
.I_mode_change    (S_night_mode_change_csi || S_setting_end_csi),
        .I_gesture_rearm  (S_unified_gesture_rearm),
.O_detection_ready(S_detection_ready),
.I_tlast         (S_raw_tlast	),
.I_tuser         (S_raw_tuser	),
.I_tdata         (S_raw_tdata	),
.I_tvalid        (S_raw_tvalid	),
.I_tdest         (),
.O_tready        (S_ISP_O_tready),
.O_tdata         (S_ISP_O_tdata ),
.O_tlast         (S_ISP_O_tlast ),
.O_tuser         (S_ISP_O_tuser ),
.O_tvalid        (S_ISP_O_tvalid),
.I_tready        (),
.O_avg_luma      (),
.O_luma_frame_done(),
.O_person_box_done(S_person_box_done),
.O_person_box_valid(S_person_box_valid),
.O_person_x0(S_person_x0), .O_person_y0(S_person_y0),
.O_person_x1(S_person_x1), .O_person_y1(S_person_y1)
,.O_hand_valid(S_hand_valid), .O_hand_xmin(S_hand_xmin), .O_hand_xmax(S_hand_xmax), .O_hand_ymin(S_hand_ymin), .O_hand_ymax(S_hand_ymax), .O_gesture_code(S_gesture_code)
,.O_red_valid(S_red_valid), .O_green_valid(S_green_valid), .O_blue_valid(S_blue_valid), .O_yellow_valid(S_yellow_valid)
,.O_red_xmin(S_red_xmin), .O_red_xmax(S_red_xmax), .O_green_xmin(S_green_xmin), .O_green_xmax(S_green_xmax), .O_blue_xmin(S_blue_xmin), .O_blue_xmax(S_blue_xmax), .O_yellow_xmin(S_yellow_xmin), .O_yellow_xmax(S_yellow_xmax)
,.O_red_ymin(S_red_ymin), .O_red_ymax(S_red_ymax), .O_green_ymin(S_green_ymin), .O_green_ymax(S_green_ymax), .O_blue_ymin(S_blue_ymin), .O_blue_ymax(S_blue_ymax), .O_yellow_ymin(S_yellow_ymin), .O_yellow_ymax(S_yellow_ymax)
,.O_red_shape(S_red_shape), .O_green_shape(S_green_shape), .O_blue_shape(S_blue_shape), .O_yellow_shape(S_yellow_shape)
  );

    video_in u_video_in(
        .I_rst_n              (  S_rst_n             ),

        .I_camera_clk         ( S_csi_rx_clk          ),
        .I_camera_frame_start ( S_ISP_O_tuser  ),
        .I_camera_valid       ( S_ISP_O_tvalid ),
        .I_camera_data        ( S_ISP_O_tdata  ),
        .I_mipi_rx_error      ( 1'b0			      ),

        .I_ddr_clk            ( S_ddr_clk             ),
		.I_display_pause      ( 1'b0                  ),
        .I_video_out_rd_busy  ( S_video_out_rd_busy   ),
        .O_video_in_wr_busy   ( S_video_in_wr_busy    ),
        .O_video_out_rp       ( S_video_out_rp        ),
        .O_frame_store_start  ( S_frame_store_start   ),
        .O_frame_store_slot   ( S_frame_store_slot    ),

        .O_ddr_user_wr_en     ( S_vi_ddr_wr_en        ),
        .O_ddr_user_addr      ( S_vi_ddr_wr_addr      ),
        .O_ddr_user_wr_data   ( S_vi_ddr_wr_data      ),
        .I_ddr_user_ready     ( S_ddr_user_ready      )
    );



    assign S_ddr_user_wr_en    = S_vi_ddr_wr_en;

    assign S_ddr_user_rd_en    = S_vo_ddr_rd_en;

    assign S_ddr_user_addr     = S_vi_ddr_wr_en ? S_vi_ddr_wr_addr :
                                 S_vo_ddr_rd_en ? S_vo_ddr_rd_addr : 'd0;

    assign S_ddr_user_wr_data  = S_vi_ddr_wr_data;


    assign S_video_out_rst_n = S_hdmi_rst_n;

    video_out u_video_out(
        .I_rst_n             ( S_video_out_rst_n    ),
        .I_ddr_clk           ( S_ddr_clk            ),
 
        .O_video_out_rd_busy ( S_video_out_rd_busy  ),
        .I_video_in_wr_busy  ( S_video_in_wr_busy   ),
        .I_video_out_rp      ( S_video_out_rp       ),
        .O_frame_read_start  ( S_frame_read_start   ),
        .O_frame_read_slot   ( S_frame_read_slot    ),
 
        .O_ddr_user_rd_en    ( S_vo_ddr_rd_en       ),
        .O_ddr_user_addr     ( S_vo_ddr_rd_addr     ),
        .I_ddr_user_ready    ( S_ddr_user_ready     ),
        .I_ddr_user_rd_valid ( S_ddr_user_rd_valid  ),
        .I_ddr_user_rd_data  ( S_ddr_user_rd_data   ),

        .I_dsi_clk           ( S_hdmi_pixel_clk     ),
        .I_video_vsync       ( S_video_out_vsync    ),
        .I_video_rd_en       ( S_hdmi_window_rd_en  ),
        .O_vdieo_data        ( S_video_rd_data      )
    );

    frame_identity u_frame_identity (
        .I_csi_clk(S_csi_rx_clk), .I_ddr_clk(S_ddr_clk), .I_rst_n(S_rst_n),
        .I_camera_start(S_raw10_frame_start), .I_isp_start(S_ISP_O_tuser),
        .I_store_start(S_frame_store_start), .I_store_slot(S_frame_store_slot),
        .I_read_start(S_frame_read_start), .I_read_slot(S_frame_read_slot),
        .O_camera_gray(S_camera_frame_gray), .O_read_sequence(S_read_frame_seq),
        .O_read_valid(S_read_frame_valid), .O_read_toggle(S_read_frame_toggle)
    );
    video_measure u_video_measure (
        .I_clk(S_hdmi_pixel_clk), .I_rst_n(S_hdmi_rst_n),
        .I_camera_gray(S_camera_frame_gray), .I_read_sequence(S_read_frame_seq),
        .I_read_valid(S_read_frame_valid), .I_read_toggle(S_read_frame_toggle),
        .I_output_first_pixel(S_roi_frame_start),
        .O_fps_tenths(S_camera_fps_tenths), .O_fps_valid(S_camera_fps_valid),
        .O_delay_frames(S_video_delay_frames), .O_delay_valid(S_video_delay_valid)
    );



    mc_to_user_interface u_mc_to_user_interface(
        .I_clk                   ( S_ddr_clk               ),
        .I_rst_n                 ( S_rst_n                 ),

        .I_ddr_user_wr_en        ( S_ddr_user_wr_en        ),
        .I_ddr_user_rd_en        ( S_ddr_user_rd_en        ),
        .I_ddr_user_addr         ( S_ddr_user_addr         ),
        .I_ddr_user_wr_data      ( S_ddr_user_wr_data      ),
        .O_ddr_user_ready        ( S_ddr_user_ready        ),
        .O_ddr_user_rd_valid     ( S_ddr_user_rd_valid     ),
        .O_ddr_user_rd_data      ( S_ddr_user_rd_data      ),
            
        .O_mc_app_en             ( S_mc_app_en             ),
        .O_mc_app_addr           ( S_mc_app_addr           ),
        .O_mc_app_cmd            ( S_mc_app_cmd            ),
        .I_mc_app_rdy            ( S_mc_app_rdy            ),
        .O_mc_app_wdf_wren       ( S_mc_app_wdf_wren       ),
        .O_mc_app_wdf_data       ( S_mc_app_wdf_data       ),
        .O_mc_app_wdf_end        ( S_mc_app_wdf_end        ),
        .O_mc_app_wdf_mask       ( S_mc_app_wdf_mask       ),
        .I_mc_app_wdf_rdy        ( S_mc_app_wdf_rdy        ),
        .I_mc_app_rd_data        ( S_mc_app_rd_data        ),
        .I_mc_app_rd_data_end    ( S_mc_app_rd_data_end    ),
        .I_mc_app_rd_data_valid  ( S_mc_app_rd_data_valid  )
    );



    ph1p35_324_ddr_wrapper u_ph1p35_324_ddr_wrapper(
        .I_sys_clk              ( I_sys_clk              ),
        .I_sys_rst_n            ( S_rst_n                ),

        .O_ddr_clk              ( S_ddr_clk              ),
        .O_init_calib_complete  ( S_init_calib_complete  ),
        .I_mc_app_addr          ( S_mc_app_addr          ),
        .I_mc_app_cmd           ( S_mc_app_cmd           ),
        .I_mc_app_en            ( S_mc_app_en            ),
        .I_mc_app_wdf_data      ( S_mc_app_wdf_data      ),
        .I_mc_app_wdf_end       ( S_mc_app_wdf_end       ),
        .I_mc_app_wdf_mask      ( S_mc_app_wdf_mask      ),
        .I_mc_app_wdf_wren      ( S_mc_app_wdf_wren      ),
        .O_mc_app_rd_data       ( S_mc_app_rd_data       ),
        .O_mc_app_rd_data_end   ( S_mc_app_rd_data_end   ),
        .O_mc_app_rd_data_valid ( S_mc_app_rd_data_valid ),
        .O_mc_app_rdy           ( S_mc_app_rdy           ),
        .O_mc_app_wdf_rdy       ( S_mc_app_wdf_rdy       ),

        .ddr_addr               ( ddr_addr               ),
        .ddr_ba                 ( ddr_ba                 ),
        .ddr_cke                ( ddr_cke                ),
        .ddr_odt                ( ddr_odt                ),
        .ddr_cs_n               ( ddr_cs_n               ),
        .ddr_ras_n              ( ddr_ras_n              ),
        .ddr_cas_n              ( ddr_cas_n              ),
        .ddr_we_n               ( ddr_we_n               ),
        .ddr_ck_p               ( ddr_ck_p               ),
        .ddr_ck_n               ( ddr_ck_n               ),
        .ddr_dm                 ( ddr_dm                 ),
        .ddr_dq                 ( ddr_dq                 ),
        .ddr_dqs_p              ( ddr_dqs_p              ),
        .ddr_dqs_n              ( ddr_dqs_n              )
    );



    uivtc #(
        .H_ActiveSize ( 1280 ),
        .H_FrameSize  ( 1650 ),
        .H_SyncStart  ( 1390 ),
        .H_SyncEnd    ( 1430 ),
        .V_ActiveSize ( 720  ),
        .V_FrameSize  ( 750  ),
        .V_SyncStart  ( 725  ),
        .V_SyncEnd    ( 730  )
    )u_hdmi_vtc(
        .I_vtc_rstn    ( S_hdmi_rst_n    ),
        .I_vtc_clk     ( S_hdmi_pixel_clk ),
        .O_vtc_vs      ( S_hdmi_vsync     ),
        .O_vtc_hs      ( S_hdmi_hsync     ),
        .O_vtc_de_valid( S_hdmi_de        ),
        .O_vtc_user    ( S_hdmi_user      ),
        .O_vtc_last    ( S_hdmi_last      )
    );

    // Keep the original OSD composition order: camera pixels are filtered
    // first, then the Logo, status text and detection boxes are overlaid.
    // This preserves the original OSD colors and glyph shapes in every mode.
    unified_mode_controller u_unified_mode_controller (
        .I_clk              (S_hdmi_pixel_clk),
        .I_rst_n            (S_hdmi_rst_n),
        .I_frame_start      (S_hdmi_user),
        .I_key_n            (I_button),
        .O_app_mode         (S_unified_app_mode),
        .O_filter_mode      (S_unified_filter_mode),
        .O_night_mode       (S_unified_night_request),
        .O_action_toggle    (S_unified_action_toggle),
        .O_enable_gesture   (S_unified_gesture_enable), .O_enable_color_shape(S_unified_color_enable),
        .O_enable_tracking  (S_unified_tracking_enable), .O_enable_filter(S_unified_filter_enable)
    );

    image_processing_3x3 #(
        .IMG_WIDTH(1280), .IMG_HEIGHT(720)
    ) u_unified_image_processing (
        .I_clk(S_hdmi_pixel_clk), .I_rst_n(S_hdmi_rst_n),
        .I_video_de(S_hdmi_window_rd_en), .I_video_user(S_hdmi_user),
        .I_video_last(S_hdmi_last), .I_mode(S_unified_filter_mode),
        .I_video_data(S_video_rd_data), .O_video_data(S_unified_filter_data)
    );

    assign S_pre_osd_video_data = (S_unified_filter_enable && |S_unified_filter_mode) ?
                                  S_unified_filter_data : S_video_rd_data;

    hdmi_mixer #(
        .H_OFFSET   ( 0    ),
        .V_OFFSET   ( 0    ),
        .IMG_WIDTH  ( 1280 ),
        .IMG_HEIGHT ( 720  ),
        // Normal camera display.  Set to 4 only when the MIPI diagnostic
        // full-screen status page is needed.
        .DEBUG_MODE ( 0    )
    )u_hdmi_mixer(
        .I_clk           ( S_hdmi_pixel_clk   ),
        .I_rst_n         ( S_hdmi_rst_n       ),
        .I_video_vsync   ( S_hdmi_vsync       ),
        .I_video_hsync   ( S_hdmi_hsync       ),
        .I_video_de      ( S_hdmi_de          ),
        .I_video_user    ( S_hdmi_user        ),
        .I_video_last    ( S_hdmi_last        ),
        .I_debug_status  ( S_hdmi_debug_status),
        .I_night_mode    ( S_clock_display_hdmi[24] ),
        .I_time_setting  ( S_clock_display_hdmi[25] ),
        .I_time_bcd      ( S_clock_display_hdmi[23:0] ),
        .I_latency_valid ( S_video_delay_valid ),
        .I_latency_frames( S_video_delay_frames ),
        .I_fps_valid     ( S_camera_fps_valid ),
        .I_fps_tenths    ( S_camera_fps_tenths ),
        .I_track_status  ( S_track_status_hdmi_sync2 ),
        .I_box_valid     ( S_person_box_hdmi[42] ),
        .I_box_x0        ( S_person_box_hdmi[41:31] ),
        .I_box_y0        ( S_person_box_hdmi[30:21] ),
        .I_box_x1        ( S_person_box_hdmi[20:10] ),
        .I_box_y1        ( S_person_box_hdmi[9:0] ),
        .O_video_rd_en   ( S_hdmi_window_rd_en),
        .I_video_rd_data ( S_pre_osd_video_data),
        .O_hdmi_vsync    ( S_hdmi_out_vsync   ),
        .O_hdmi_hsync    ( S_hdmi_out_hsync   ),
        .O_hdmi_de       ( S_hdmi_out_de      ),
        .O_hdmi_data     ( S_hdmi_out_data    ),
        .O_roi_valid     ( S_roi_valid        ),
        .O_roi_frame_start( S_roi_frame_start ),
        .O_roi_x         ( S_roi_x            ),
        .O_roi_y         ( S_roi_y            ),
        .O_roi_rgb       (                    )
    );

    // KEY3 request crosses into the camera domain for a fresh hand background.
    always @(posedge S_csi_rx_clk or negedge S_rst_n)
        if (!S_rst_n) S_unified_action_csi <= 2'b00;
        else S_unified_action_csi <= {S_unified_action_csi[0], S_unified_action_toggle};

    unified_result_overlay u_unified_result_overlay(
        .I_clk(S_hdmi_pixel_clk), .I_rst_n(S_hdmi_rst_n), .I_de(S_hdmi_out_de), .I_user(S_hdmi_user), .I_last(S_hdmi_last), .I_rgb(S_hdmi_out_data),
        .I_gesture_enable(S_unified_gesture_enable), .I_hand_valid(S_hand_valid), .I_hand_xmin(S_hand_xmin), .I_hand_xmax(S_hand_xmax), .I_hand_ymin(S_hand_ymin), .I_hand_ymax(S_hand_ymax), .I_gesture_code(S_gesture_code),
        .I_color_enable(S_unified_color_enable), .I_red_valid(S_red_valid), .I_green_valid(S_green_valid), .I_blue_valid(S_blue_valid), .I_yellow_valid(S_yellow_valid),
        .I_red_xmin(S_red_xmin), .I_red_xmax(S_red_xmax), .I_green_xmin(S_green_xmin), .I_green_xmax(S_green_xmax), .I_blue_xmin(S_blue_xmin), .I_blue_xmax(S_blue_xmax), .I_yellow_xmin(S_yellow_xmin), .I_yellow_xmax(S_yellow_xmax),
        .I_red_ymin(S_red_ymin), .I_red_ymax(S_red_ymax), .I_green_ymin(S_green_ymin), .I_green_ymax(S_green_ymax), .I_blue_ymin(S_blue_ymin), .I_blue_ymax(S_blue_ymax), .I_yellow_ymin(S_yellow_ymin), .I_yellow_ymax(S_yellow_ymax),
        .I_red_shape(S_red_shape), .I_green_shape(S_green_shape), .I_blue_shape(S_blue_shape), .I_yellow_shape(S_yellow_shape), .O_rgb(S_hdmi_out_data_final));

    hdmi_tx u_hdmi_tx(
        .I_pixel_clk        ( S_hdmi_pixel_clk  ),
        .I_serial_clk       ( S_hdmi_serial_clk ),
        .I_rst              ( ~S_hdmi_rst_n     ),
        .I_key_in           ( 1'b0              ),
        .I_edid_read_trig   ( 1'b0              ),
        .O_edid_read_valid  (                   ),
        .O_edid_read_data   (                   ),
        .I_video_rgb_enable ( 1'b1              ),
        .I_video_in_vs      ( S_hdmi_out_vsync  ),
        .I_video_in_de      ( S_hdmi_out_de     ),
        .I_video_in_user    ( 1'b0              ),
        .I_video_in_valid   ( 1'b0              ),
        .I_video_in_last    ( 1'b0              ),
        .O_video_in_ready   (                   ),
        .I_video_in_data    ( S_hdmi_out_data_final ),
        .I_audio_valid      ( 1'b0              ),
        .I_audio_left_data  ( 24'd0             ),
        .I_audio_right_data ( 24'd0             ),
        .I_i2s_BCLK         ( 1'b0              ),
        .I_i2s_LRCK         ( 1'b0              ),
        .I_i2s_DOUT         ( 1'b0              ),
        .O_ddc_scl          (                   ),
        .O_hdmi_clk_p       (                   ),
        .O_hdmi_tx_p        (                   ),
        .O_tmds_ch0_p       ( O_tmds_ch0_p      ),
        .O_tmds_ch1_p       ( O_tmds_ch1_p      ),
        .O_tmds_ch2_p       ( O_tmds_ch2_p      ),
        .O_tmds_clk_p       ( O_tmds_clk_p      )
    );

    
endmodule

// Keep a latched I2C warning visible, but accept a camera that has actually
// produced fresh, structurally valid video frames. A stalled stream revokes
// tracking permission within VIDEO_TIMEOUT_CYCLES.
module startup_supervisor #(
    parameter integer VIDEO_TIMEOUT_CYCLES = 100000000
)(
    input wire I_clk, I_rst_n,
    input wire I_cam_cfg_done, I_ae_cfg_done, I_i2c_error,
    input wire I_good_frame_toggle, I_detection_ready,
    input wire I_tracking_switch, I_follow_active,
    output wire O_sensor_ready, O_track_permit, O_i2c_warning,
    output wire [2:0] O_status
);
    reg [1:0] cam_done_sync, ae_done_sync, i2c_error_sync;
    reg [1:0] frame_toggle_sync, detection_ready_sync;
    reg frame_toggle_seen, frame_seen;
    reg [26:0] video_timeout;
    wire video_live = frame_seen && video_timeout < VIDEO_TIMEOUT_CYCLES;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            cam_done_sync <= 2'b00;
            ae_done_sync <= 2'b00;
            i2c_error_sync <= 2'b00;
            frame_toggle_sync <= 2'b00;
            detection_ready_sync <= 2'b00;
            frame_toggle_seen <= 1'b0;
            frame_seen <= 1'b0;
            video_timeout <= 27'd0;
        end else begin
            cam_done_sync <= {cam_done_sync[0], I_cam_cfg_done};
            ae_done_sync <= {ae_done_sync[0], I_ae_cfg_done};
            i2c_error_sync <= {i2c_error_sync[0], I_i2c_error};
            frame_toggle_sync <= {frame_toggle_sync[0], I_good_frame_toggle};
            detection_ready_sync <= {detection_ready_sync[0], I_detection_ready};
            if (frame_toggle_sync[1] != frame_toggle_seen) begin
                frame_toggle_seen <= frame_toggle_sync[1];
                frame_seen <= 1'b1;
                video_timeout <= 27'd0;
            end else if (video_timeout < VIDEO_TIMEOUT_CYCLES) begin
                video_timeout <= video_timeout + 1'b1;
            end
        end
    end

    assign O_i2c_warning = i2c_error_sync[1];
    assign O_sensor_ready = cam_done_sync[1] && ae_done_sync[1] && video_live;
    assign O_track_permit = O_sensor_ready && detection_ready_sync[1] && video_live;
    assign O_status = i2c_error_sync[1] && !video_live ? 3'd4 :
                      !(cam_done_sync[1] && ae_done_sync[1]) ? 3'd3 :
                      !video_live ? 3'd5 :
                      !detection_ready_sync[1] ? 3'd6 :
                      !I_tracking_switch ? 3'd0 :
                      I_follow_active ? 3'd2 : 3'd1;
endmodule

// Hold AE/AG constant throughout the entire grouped I2C transaction. A done
// level left high from the previous transaction is not an acknowledgement:
// first observe busy (done low), then completion (done high).
module sensor_mode_config (
    input wire I_clk, I_rst_n, I_cam_done, I_ae_done, I_error, I_mode,
    input wire [15:0] I_day_ae, I_day_ag,
    output reg O_request,
    output reg [15:0] O_ae, O_ag,
    output reg O_applied_mode,
    output wire O_ready
);
    reg [1:0] state;
    reg applied_valid, transaction_mode;
    wire [15:0] wanted_ae = I_mode ? 16'd1991 : I_day_ae;
    wire [15:0] wanted_ag = I_mode ? 16'd176 : I_day_ag;
    wire settings_match = applied_valid && O_applied_mode == I_mode &&
                          O_ae == wanted_ae && O_ag == wanted_ag;
    assign O_ready = I_cam_done && I_ae_done && !I_error && state == 0 && settings_match;
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            state <= 0; applied_valid <= 0; transaction_mode <= 0;
            O_request <= 0; O_ae <= 1991; O_ag <= 144; O_applied_mode <= 0;
        end else begin
            case (state)
                0: if (I_cam_done && I_ae_done && !I_error && !settings_match) begin
                    O_ae <= wanted_ae;
                    O_ag <= wanted_ag;
                    transaction_mode <= I_mode;
                    O_request <= 1;
                    state <= 1;
                end
                1: if (!I_ae_done) begin
                    O_request <= 0;
                    state <= 2;
                end
                2: if (I_ae_done) begin
                    O_applied_mode <= transaction_mode;
                    applied_valid <= 1;
                    state <= 0;
                end
                default: begin state <= 0; O_request <= 0; applied_valid <= 0; end
            endcase
        end
    end
endmodule

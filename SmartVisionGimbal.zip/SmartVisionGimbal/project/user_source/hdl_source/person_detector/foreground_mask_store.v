// One-bit 320x180 cleaned foreground mask with a synchronous read port.
// Readout starts only after row_column_stats has finished row 179.
module foreground_mask_store (
    input  wire       I_clk,
    input  wire       I_rst_n,
    input  wire       I_write_valid,
    input  wire       I_write_pixel,
    input  wire [8:0] I_write_x,
    input  wire [7:0] I_write_y,
    input  wire       I_read_en,
    input  wire [8:0] I_read_x,
    input  wire [7:0] I_read_y,
    output reg        O_read_valid,
    output reg        O_read_pixel,
    output reg  [8:0] O_read_x,
    output reg  [7:0] O_read_y
);
    reg mask [0:57599];
    wire [15:0] write_address =
        {I_write_y, 8'd0} + {2'd0, I_write_y, 6'd0} + I_write_x;
    wire [15:0] read_address =
        {I_read_y, 8'd0} + {2'd0, I_read_y, 6'd0} + I_read_x;

    always @(posedge I_clk) begin
        if (I_write_valid)
            mask[write_address] <= I_write_pixel;
        if (I_read_en)
            O_read_pixel <= mask[read_address];
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            O_read_valid <= 1'b0;
            O_read_x <= 9'd0;
            O_read_y <= 8'd0;
        end else begin
            O_read_valid <= I_read_en;
            if (I_read_en) begin
                O_read_x <= I_read_x;
                O_read_y <= I_read_y;
            end
        end
    end
endmodule

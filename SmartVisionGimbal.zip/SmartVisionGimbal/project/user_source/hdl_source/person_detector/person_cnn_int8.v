// Four stride-2 INT8 convolutions and a global-average/linear classifier.
// One MAC is reused over all taps, leaving DSP and slice capacity for later work.
module person_cnn_int8 (
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire        I_roi_write,
    input  wire [12:0] I_roi_addr,
    input  wire [7:0]  I_roi_gray,
    input  wire        I_roi_ready,
    output wire        O_busy,
    output reg         O_done,
    output reg         O_person,
    output reg signed [31:0] O_score
);
    localparam IDLE = 3'd0, PREP = 3'd1, FETCH = 3'd2,
               ACCUM = 3'd3, POOL = 3'd4, FCMAC = 3'd5;
    reg [2:0] state;
    reg [1:0] layer;
    reg [5:0] oc, ic, oy;
    reg [4:0] ox;
    reg [1:0] ky, kx;
    reg signed [31:0] acc, fc_acc;
    reg [15:0] channel_sum;
    reg [7:0] pooled_q;
    reg [7:0] roi_q, buffer_a_q, buffer_b_q;
    reg [7:0] w0_q, w1_q, w2_q, w3_q;
    reg [13:0] src_addr_q, weight_addr_q;
    reg tap_inside_q;

    (* ram_style = "bram" *) reg [7:0] roi [0:4607];
    (* ram_style = "bram" *) reg [7:0] buffer_a [0:13823];
    (* ram_style = "bram" *) reg [7:0] buffer_b [0:5759];
    (* rom_style = "bram" *) reg [7:0] w0 [0:107];
    (* rom_style = "bram" *) reg [7:0] w1 [0:2159];
    (* rom_style = "bram" *) reg [7:0] w2 [0:5759];
    (* rom_style = "bram" *) reg [7:0] w3 [0:13823];
    reg signed [31:0] b0 [0:11];
    reg signed [31:0] b1 [0:19];
    reg signed [31:0] b2 [0:31];
    reg signed [31:0] b3 [0:47];
    reg [7:0] fc_w [0:47];
    reg signed [31:0] fc_b [0:0];

    initial begin
        $readmemh("../../../user_source/hdl_source/person_detector/w0.mem", w0);
        $readmemh("../../../user_source/hdl_source/person_detector/w1.mem", w1);
        $readmemh("../../../user_source/hdl_source/person_detector/w2.mem", w2);
        $readmemh("../../../user_source/hdl_source/person_detector/w3.mem", w3);
        $readmemh("../../../user_source/hdl_source/person_detector/b0.mem", b0);
        $readmemh("../../../user_source/hdl_source/person_detector/b1.mem", b1);
        $readmemh("../../../user_source/hdl_source/person_detector/b2.mem", b2);
        $readmemh("../../../user_source/hdl_source/person_detector/b3.mem", b3);
        $readmemh("../../../user_source/hdl_source/person_detector/fc_w.mem", fc_w);
        $readmemh("../../../user_source/hdl_source/person_detector/fc_b.mem", fc_b);
    end

    assign O_busy = state != IDLE;

    reg [5:0] last_ic, last_oc;
    reg [5:0] last_oy;
    reg [4:0] last_ox;
    reg [3:0] shift;
    reg signed [31:0] current_bias, next_bias;
    reg [13:0] src_index, weight_index, dst_index;
    reg tap_inside;
    integer iy, ix;

    always @* begin
        iy = 2 * oy + ky - 1;
        ix = 2 * ox + kx - 1;
        src_index = 14'd0;
        weight_index = 14'd0;
        dst_index = 14'd0;
        tap_inside = 1'b0;
        current_bias = 32'sd0;
        next_bias = 32'sd0;
        last_ic = 6'd0;
        last_oc = 6'd11;
        last_oy = 6'd47;
        last_ox = 5'd23;
        shift = 4'd7;
        case (layer)
            2'd0: begin
                tap_inside = iy >= 0 && iy < 96 && ix >= 0 && ix < 48;
                src_index = iy * 48 + ix;
                weight_index = oc * 9 + ky * 3 + kx;
                dst_index = oc * 1152 + oy * 24 + ox;
                current_bias = b0[oc];
                next_bias = b0[oc + 6'd1];
            end
            2'd1: begin
                last_ic = 6'd11; last_oc = 6'd19;
                last_oy = 6'd23; last_ox = 5'd11; shift = 4'd8;
                tap_inside = iy >= 0 && iy < 48 && ix >= 0 && ix < 24;
                src_index = ic * 1152 + iy * 24 + ix;
                weight_index = (oc * 12 + ic) * 9 + ky * 3 + kx;
                dst_index = oc * 288 + oy * 12 + ox;
                current_bias = b1[oc];
                next_bias = b1[oc + 6'd1];
            end
            2'd2: begin
                last_ic = 6'd19; last_oc = 6'd31;
                last_oy = 6'd11; last_ox = 5'd5; shift = 4'd7;
                tap_inside = iy >= 0 && iy < 24 && ix >= 0 && ix < 12;
                src_index = ic * 288 + iy * 12 + ix;
                weight_index = (oc * 20 + ic) * 9 + ky * 3 + kx;
                dst_index = oc * 72 + oy * 6 + ox;
                current_bias = b2[oc];
                next_bias = b2[oc + 6'd1];
            end
            2'd3: begin
                last_ic = 6'd31; last_oc = 6'd47;
                last_oy = 6'd5; last_ox = 5'd2; shift = 4'd9;
                tap_inside = iy >= 0 && iy < 12 && ix >= 0 && ix < 6;
                src_index = ic * 72 + iy * 6 + ix;
                weight_index = (oc * 32 + ic) * 9 + ky * 3 + kx;
                dst_index = oc * 18 + oy * 3 + ox;
                current_bias = b3[oc];
                next_bias = b3[oc + 6'd1];
            end
        endcase
    end

    wire last_tap = ic == last_ic && ky == 2'd2 && kx == 2'd2;
    wire last_output = oc == last_oc && oy == last_oy && ox == last_ox;
    wire [7:0] src_q = layer == 2'd0 ? roi_q :
                       layer == 2'd2 ? buffer_b_q : buffer_a_q;
    wire [7:0] weight_q = layer == 2'd0 ? w0_q :
                          layer == 2'd1 ? w1_q :
                          layer == 2'd2 ? w2_q : w3_q;
    wire signed [31:0] product = tap_inside_q ?
        $signed({1'b0, src_q}) * $signed(weight_q) : 32'sd0;
    wire signed [31:0] completed_acc = acc + product;
    wire signed [31:0] rounded = (completed_acc + (32'sd1 <<< (shift - 1))) >>> shift;
    wire [7:0] activation = rounded < 0 ? 8'd0 :
                            rounded > 255 ? 8'd255 : rounded[7:0];
    wire [15:0] channel_total = channel_sum + {8'd0, activation};
    wire [7:0] pooled = (channel_sum + 16'd9) / 16'd18;
    wire signed [31:0] fc_product = $signed({1'b0, pooled_q}) * $signed(fc_w[oc]);
    wire signed [31:0] final_score = fc_acc + fc_product;

    always @(posedge I_clk) begin
        if (I_roi_write)
            roi[I_roi_addr] <= I_roi_gray;
        if (state == FETCH) begin
            roi_q <= roi[src_addr_q[12:0]];
            buffer_a_q <= buffer_a[src_addr_q];
            buffer_b_q <= buffer_b[src_addr_q];
            w0_q <= w0[weight_addr_q];
            w1_q <= w1[weight_addr_q];
            w2_q <= w2[weight_addr_q];
            w3_q <= w3[weight_addr_q];
        end
        if (state == ACCUM && last_tap) begin
            if (layer == 2'd0 || layer == 2'd2)
                buffer_a[dst_index] <= activation;
            else
                buffer_b[dst_index] <= activation;
        end
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            state <= IDLE;
            layer <= 2'd0;
            oc <= 6'd0; ic <= 6'd0; oy <= 6'd0; ox <= 5'd0;
            ky <= 2'd0; kx <= 2'd0;
            acc <= 32'sd0;
            fc_acc <= 32'sd0;
            channel_sum <= 16'd0;
            pooled_q <= 8'd0;
            tap_inside_q <= 1'b0;
            O_done <= 1'b0;
            O_person <= 1'b0;
            O_score <= 32'sd0;
        end else begin
            O_done <= 1'b0;
            case (state)
                IDLE: if (I_roi_ready) begin
                    layer <= 2'd0;
                    oc <= 6'd0; ic <= 6'd0; oy <= 6'd0; ox <= 5'd0;
                    ky <= 2'd0; kx <= 2'd0;
                    acc <= b0[0];
                    fc_acc <= fc_b[0];
                    channel_sum <= 16'd0;
                    state <= PREP;
                end
                PREP: begin
                    src_addr_q <= src_index;
                    weight_addr_q <= weight_index;
                    tap_inside_q <= tap_inside;
                    state <= FETCH;
                end
                FETCH: state <= ACCUM;
                ACCUM: begin
                    if (!last_tap) begin
                        acc <= completed_acc;
                        if (kx != 2'd2)
                            kx <= kx + 2'd1;
                        else begin
                            kx <= 2'd0;
                            if (ky != 2'd2)
                                ky <= ky + 2'd1;
                            else begin
                                ky <= 2'd0;
                                ic <= ic + 6'd1;
                            end
                        end
                    end else begin
                        ic <= 6'd0; ky <= 2'd0; kx <= 2'd0;
                        if (layer == 2'd3)
                            channel_sum <= channel_total;
                        if (layer == 2'd3 && oy == last_oy && ox == last_ox) begin
                            state <= POOL;
                        end else if (last_output) begin
                            layer <= layer + 2'd1;
                            oc <= 6'd0; oy <= 6'd0; ox <= 5'd0;
                            case (layer)
                                2'd0: acc <= b1[0];
                                2'd1: acc <= b2[0];
                                2'd2: acc <= b3[0];
                            endcase
                            state <= PREP;
                        end else begin
                            if (ox == last_ox) begin
                                ox <= 5'd0;
                                if (oy == last_oy) begin
                                    oy <= 6'd0;
                                    oc <= oc + 6'd1;
                                    acc <= next_bias;
                                end else begin
                                    oy <= oy + 6'd1;
                                    acc <= current_bias;
                                end
                            end else begin
                                ox <= ox + 5'd1;
                                acc <= current_bias;
                            end
                            state <= PREP;
                        end
                    end
                    if (!last_tap)
                        state <= PREP;
                end
                POOL: begin
                    pooled_q <= pooled;
                    state <= FCMAC;
                end
                FCMAC: begin
                    fc_acc <= final_score;
                    channel_sum <= 16'd0;
                    if (oc == 6'd47) begin
                        O_score <= final_score;
                        O_person <= final_score > 32'sd32;
                        O_done <= 1'b1;
                        state <= IDLE;
                    end else begin
                        oc <= oc + 6'd1;
                        oy <= 6'd0; ox <= 5'd0;
                        acc <= next_bias;
                        state <= PREP;
                    end
                end
                default: state <= IDLE;
            endcase
        end
    end
endmodule

// Nearest-neighbor 48x96 grayscale crop from the displayed 1280x720 stream.
// A new crop starts only when the classifier can consume a full frame.
module roi_sampler (
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire        I_enable,
    input  wire        I_valid,
    input  wire [10:0] I_x,
    input  wire [9:0]  I_y,
    input  wire [23:0] I_rgb,
    input  wire        I_box_valid,
    input  wire [10:0] I_box_x0,
    input  wire [9:0]  I_box_y0,
    input  wire [10:0] I_box_x1,
    input  wire [9:0]  I_box_y1,
    output reg         O_write,
    output reg  [12:0] O_addr,
    output reg  [7:0]  O_gray,
    output reg         O_ready
);
    reg active;
    reg [10:0] target_x, x_start, x_step;
    reg [9:0] target_y, y_step;
    reg [6:0] x_rem, x_fraction;
    reg [6:0] y_rem, y_fraction;
    reg [5:0] column;
    reg [6:0] row;

    wire [10:0] box_width = I_box_x1 - I_box_x0;
    wire [9:0] box_height = I_box_y1 - I_box_y0;
    wire [10:0] pad_x = box_width >> 4;
    wire [9:0] pad_y = box_height >> 4;
    wire [10:0] left = I_box_x0 > pad_x ? I_box_x0 - pad_x : 11'd0;
    wire [9:0] top = I_box_y0 > pad_y ? I_box_y0 - pad_y : 10'd1;
    wire [11:0] right_sum = {1'b0, I_box_x1} + {1'b0, pad_x};
    wire [10:0] bottom_sum = {1'b0, I_box_y1} + {1'b0, pad_y};
    wire [10:0] right = right_sum > 12'd1280 ? 11'd1280 : right_sum[10:0];
    wire [9:0] bottom = bottom_sum > 11'd720 ? 10'd720 : bottom_sum[9:0];
    wire [10:0] crop_width = right - left;
    wire [9:0] crop_height = bottom - top;
    wire [6:0] next_x_fraction = {1'b0, x_fraction} + x_rem;
    wire [7:0] next_y_fraction = {1'b0, y_fraction} + y_rem;
    wire [15:0] luma = I_rgb[23:16] * 8'd77 +
                       I_rgb[15:8] * 8'd150 + I_rgb[7:0] * 8'd29 + 16'd128;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            active <= 1'b0;
            target_x <= 11'd0;
            target_y <= 10'd0;
            x_start <= 11'd0;
            x_step <= 11'd0;
            y_step <= 10'd0;
            x_rem <= 7'd0;
            y_rem <= 7'd0;
            x_fraction <= 7'd0;
            y_fraction <= 7'd0;
            column <= 6'd0;
            row <= 7'd0;
            O_write <= 1'b0;
            O_addr <= 13'd0;
            O_gray <= 8'd0;
            O_ready <= 1'b0;
        end else begin
            O_write <= 1'b0;
            O_ready <= 1'b0;
            if (I_valid && I_x == 11'd0 && I_y == 10'd0) begin
                active <= I_enable && I_box_valid &&
                          crop_width >= 11'd48 && crop_height >= 10'd96;
                x_start <= left;
                target_x <= left;
                target_y <= top;
                x_step <= crop_width / 11'd48;
                x_rem <= crop_width % 11'd48;
                y_step <= crop_height / 10'd96;
                y_rem <= crop_height % 10'd96;
                x_fraction <= 7'd0;
                y_fraction <= 7'd0;
                column <= 6'd0;
                row <= 7'd0;
            end else if (active && I_valid) begin
                if (I_y == target_y && I_x == target_x && column < 6'd48) begin
                    O_write <= 1'b1;
                    O_addr <= (row << 5) + (row << 4) + column;
                    O_gray <= luma[15:8];
                    column <= column + 6'd1;
                    target_x <= target_x + x_step + (next_x_fraction >= 7'd48);
                    x_fraction <= next_x_fraction >= 7'd48 ?
                                  next_x_fraction - 7'd48 : next_x_fraction;
                end
                if (I_x == 11'd1279 && I_y == target_y) begin
                    if (row == 7'd95) begin
                        active <= 1'b0;
                        O_ready <= column == 6'd48 ||
                                   (column == 6'd47 && I_x == target_x);
                    end else begin
                        row <= row + 7'd1;
                        column <= 6'd0;
                        target_x <= x_start;
                        x_fraction <= 7'd0;
                        target_y <= target_y + y_step + (next_y_fraction >= 8'd96);
                        y_fraction <= next_y_fraction >= 8'd96 ?
                                      next_y_fraction - 8'd96 : next_y_fraction;
                    end
                end
            end
        end
    end
endmodule

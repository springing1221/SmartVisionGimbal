# Candidate-box tracking build

Open `lab_ex1_mipi_hdmi/td_project/camera_to_dsi_display.al` in Tang Dynasty.
The active top-level design does not instantiate the CNN. The latest build is
`lab_ex1_mipi_hdmi/td_project/person_proposal_strong_bounds_1280x720.bit`.
The preceding build is `person_proposal_connected_rows_1280x720.bit`.
The previous candidate builds (`person_proposal_1280x720.bit`,
`person_proposal_bounds_1280x720.bit`, and
`person_proposal_mask_extent_1280x720.bit`) and the separate CNN experiment
(`person_cnn_tracking_1280x720.bit`) are preserved for comparison.

The camera-side proposal compares a 320x180 grayscale sample with one fixed
background image. Start with an empty, stationary scene. One candidate is
selected from foreground column counts, then checked against area and height
gates. The box is held through two missing proposals, cleared on the third,
and transferred to HDMI at a frame boundary. X/Y in the overlay are the box
center in 1280x720 screen coordinates. This is a foreground candidate, not
a person classification result.

The latest source scans at least 32 sampled pixels to either side of the
selected column span. Only foreground islands near that span contribute to
each row's bounds. Up to eight blank pixels within an island are bridged; a
row island must contain at least three foreground pixels and reach within eight
sampled pixels of the candidate span. Columns with more than 20 strong
foreground pixels (difference greater than 85) restrict the horizontal box.
Row results are registered before frame bounds are updated to meet timing.
The strongest vertical run sets the top while later foreground rows can extend
the bottom. The candidate-span width gate remains at 90 sampled columns.
A candidate touching the image side can be boxed. The visible box remains
limited to X=4..1275 and Y=4..695. The empirical Y=696 exclusive bottom limit
needs a check on the display. Tang Dynasty routing and bit generation passed
with setup WNS +110 ps, hold WNS +20 ps, and zero timing violations. The routed
design uses 18,425/21,216 slices, 70/108 RAMs, and 9/40 DSPs. Slice headroom
is about 13%, so additional processing needs a resource budget. Live box
accuracy still needs testing with this exact bitstream on the board.

The fixed background can produce a persistent false box when lighting or
objects change, as seen on the doorway in the formal capture. Nearby or
connected foreground changes can still widen the box. The available formal
JPEG capture belongs to an older bitstream and cannot verify this revision.
Future tracking
with a moving pan/tilt camera requires motion compensation or a local target
tracker; otherwise the fixed background subtraction becomes invalid.

// Compare a registered sample from background_sample with its background.
module foreground_diff1 #(
    parameter [7:0] THRESHOLD = 8'd55,
    parameter [7:0] STRONG_THRESHOLD = 8'd85
)(
    input  wire              I_clk,
    input  wire              I_rst_n,
    input  wire              I_valid,
    input  wire [7:0]        I_gray,
    input  wire [7:0]        I_background,
    input  wire signed [8:0] I_exposure_offset,
    input  wire [8:0]        I_x,
    input  wire [7:0]        I_y,
    output reg               O_valid,
    output reg               O_foreground,
    output reg               O_strong_foreground,
    output reg  [8:0]        O_x,
    output reg  [7:0]        O_y
);
    wire signed [9:0] delta =
        $signed({2'b00, I_gray}) - $signed({2'b00, I_background}) -
        {{1{I_exposure_offset[8]}}, I_exposure_offset};
    wire [9:0] magnitude = delta[9] ? -delta : delta;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            O_valid <= 1'b0;
            O_foreground <= 1'b0;
            O_strong_foreground <= 1'b0;
            O_x <= 9'd0;
            O_y <= 8'd0;
        end else begin
            O_valid <= I_valid;
            O_foreground <= I_valid && (magnitude > {2'b00, THRESHOLD});
            O_strong_foreground <= I_valid &&
                                   (magnitude > {2'b00, STRONG_THRESHOLD});
            O_x <= I_x;
            O_y <= I_y;
        end
    end
endmodule

// Scan around the selected column span. Only horizontal foreground islands
// near that span contribute to the weak box. Persistent strong columns limit
// its horizontal extent, while small gaps within a limb are bridged.
module candidate_box #(
    // The current HDMI capture shows 22 blank lines before active image data.
    parameter [9:0] DISPLAY_Y_END = 10'd696
) (
    input  wire       I_clk,
    input  wire       I_rst_n,
    input  wire       I_candidate_done,
    input  wire       I_candidate_valid,
    input  wire [8:0] I_left,
    input  wire [8:0] I_right,
    input  wire       I_strong_valid,
    input  wire [8:0] I_strong_left,
    input  wire [8:0] I_strong_right,
    output wire       O_read_en,
    output wire [8:0] O_read_x,
    output wire [7:0] O_read_y,
    input  wire       I_mask_valid,
    input  wire       I_mask_pixel,
    input  wire [8:0] I_mask_x,
    input  wire [7:0] I_mask_y,
    output reg        O_done,
    output reg        O_box_valid,
    output reg  [10:0] O_x0,
    output reg  [9:0] O_y0,
    output reg  [10:0] O_x1,
    output reg  [9:0] O_y1
);
    localparam [1:0] IDLE = 2'd0, SCAN = 2'd1,
                     WAIT_LAST = 2'd2, FINALIZE = 2'd3;
    reg [1:0] state;
    reg [8:0] left;
    reg [8:0] right;
    reg [8:0] read_x;
    reg [7:0] read_y;
    reg [8:0] row_pixels;
    reg [8:0] row_min;
    reg [8:0] row_first_x;
    reg [8:0] row_last_x;
    reg island_active;
    reg [3:0] island_gap;
    reg [8:0] island_first_x, island_last_x, island_pixels;
    reg [8:0] anchor_left, anchor_right;
    reg strong_valid;
    reg [8:0] strong_left, strong_right;
    reg summary_valid;
    reg [8:0] summary_pixels, summary_first_x, summary_last_x;
    reg [7:0] summary_y;
    reg geometry_ok;
    reg run_active;
    reg [3:0] gap_rows;
    reg [15:0] run_area;
    reg [7:0] run_first_y;
    reg [15:0] best_area;
    reg [7:0] best_first_y;
    reg [8:0] all_left, all_right;
    reg [7:0] all_last_y;

    wire [8:0] span_width = I_right - I_left;
    wire [8:0] side_margin = (span_width >> 1) > 9'd32 ?
                             (span_width >> 1) : 9'd32;
    wire [8:0] proposed_left = (I_left >= side_margin + 9'd1) ?
                               I_left - side_margin : 9'd1;
    wire [9:0] right_sum = {1'b0, I_right} + {1'b0, side_margin};
    wire [8:0] proposed_right = (right_sum <= 10'd319) ?
                                right_sum[8:0] : 9'd319;
    wire [8:0] proposed_row_min = span_width / 9'd10;
    wire [8:0] proposed_anchor_left = (I_left > 9'd8) ?
                                      I_left - 9'd8 : 9'd0;
    wire [9:0] anchor_right_sum = {1'b0, I_right} + 10'd8;
    wire [8:0] proposed_anchor_right = (anchor_right_sum < 10'd320) ?
                                       anchor_right_sum[8:0] : 9'd319;
    wire row_start = I_mask_x == left;
    wire row_end = I_mask_x == right - 9'd1;
    wire old_island_active = !row_start && island_active;
    wire split_island = I_mask_pixel && old_island_active && island_gap > 4'd8;
    wire old_island_near = island_last_x >= anchor_left &&
                           island_first_x <= anchor_right &&
                           island_pixels >= 9'd3;
    wire [8:0] completed_pixels = (split_island && old_island_near) ?
                                   island_pixels : 9'd0;
    wire [8:0] completed_first_x = (split_island && old_island_near) ?
                                    island_first_x : 9'd320;
    wire [8:0] completed_last_x = (split_island && old_island_near) ?
                                   island_last_x : 9'd0;
    wire new_island = I_mask_pixel && (!old_island_active || split_island);
    wire next_island_active = I_mask_pixel || old_island_active;
    wire [8:0] next_island_first_x = new_island ? I_mask_x : island_first_x;
    wire [8:0] next_island_last_x = I_mask_pixel ? I_mask_x : island_last_x;
    wire [8:0] next_island_pixels = new_island ? 9'd1 :
                                    island_pixels + {8'd0, I_mask_pixel};
    wire next_island_near = next_island_active &&
                            next_island_last_x >= anchor_left &&
                            next_island_first_x <= anchor_right &&
                            next_island_pixels >= 9'd3;
    wire [8:0] end_pixels = (row_end && next_island_near) ?
                             next_island_pixels : 9'd0;
    wire [8:0] end_first_x = (row_end && next_island_near) ?
                              next_island_first_x : 9'd320;
    wire [8:0] end_last_x = (row_end && next_island_near) ?
                             next_island_last_x : 9'd0;
    wire [8:0] previous_row_pixels = row_start ? 9'd0 : row_pixels;
    wire [8:0] previous_row_first_x = row_start ? 9'd320 : row_first_x;
    wire [8:0] previous_row_last_x = row_start ? 9'd0 : row_last_x;
    wire [8:0] next_row_pixels = previous_row_pixels +
                                 completed_pixels + end_pixels;
    wire [8:0] next_row_first_x = (completed_first_x < previous_row_first_x) ?
                                    completed_first_x : previous_row_first_x;
    wire [8:0] accepted_row_first_x = (end_first_x < next_row_first_x) ?
                                        end_first_x : next_row_first_x;
    wire [8:0] next_row_last_x = (completed_last_x > previous_row_last_x) ?
                                   completed_last_x : previous_row_last_x;
    wire [8:0] accepted_row_last_x = (end_last_x > next_row_last_x) ?
                                       end_last_x : next_row_last_x;
    wire row_occupied = summary_pixels >= row_min;
    wire [8:0] merged_left = (row_occupied && summary_first_x < all_left) ?
                             summary_first_x : all_left;
    wire [8:0] merged_right = (row_occupied && summary_last_x > all_right) ?
                              summary_last_x : all_right;
    wire [15:0] merged_area = (run_active ? run_area : 16'd0) +
                              {7'd0, summary_pixels};
    wire use_current = run_active && run_area >= best_area;
    wire [15:0] selected_area = use_current ? run_area : best_area;
    wire [7:0] selected_first_y = use_current ? run_first_y : best_first_y;
    wire [8:0] weak_left = (all_left >= 9'd4) ?
                           all_left - 9'd3 : 9'd1;
    wire [9:0] weak_right_sum = {1'b0, all_right} + 10'd4;
    wire [8:0] weak_right = (weak_right_sum <= 10'd319) ?
                            weak_right_sum[8:0] : 9'd319;
    wire [8:0] strong_padded_left = (strong_left > 9'd6) ?
                                    strong_left - 9'd6 : 9'd1;
    wire [9:0] strong_right_sum = {1'b0, strong_right} + 10'd8;
    wire [8:0] strong_padded_right = (strong_right_sum <= 10'd319) ?
                                     strong_right_sum[8:0] : 9'd319;
    wire use_strong = strong_valid && strong_left <= strong_right;
    wire [8:0] final_left = (use_strong && strong_padded_left > weak_left) ?
                            strong_padded_left : weak_left;
    wire [8:0] final_right = (use_strong && strong_padded_right < weak_right) ?
                             strong_padded_right : weak_right;
    wire [10:0] padded_bottom = {1'b0, all_last_y, 2'b00} + 11'd12;
    wire final_valid = selected_area >= 16'd600 &&
                       (all_last_y - selected_first_y + 8'd1 >= 8'd30) &&
                       final_left <= final_right && geometry_ok;

    assign O_read_en = state == SCAN;
    assign O_read_x = read_x;
    assign O_read_y = read_y;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            state <= IDLE;
            left <= 9'd0;
            right <= 9'd0;
            read_x <= 9'd0;
            read_y <= 8'd8;
            row_pixels <= 9'd0;
            row_min <= 9'd6;
            row_first_x <= 9'd320;
            row_last_x <= 9'd0;
            island_active <= 1'b0;
            island_gap <= 4'd0;
            island_first_x <= 9'd320;
            island_last_x <= 9'd0;
            island_pixels <= 9'd0;
            anchor_left <= 9'd0;
            anchor_right <= 9'd0;
            strong_valid <= 1'b0;
            strong_left <= 9'd0;
            strong_right <= 9'd0;
            summary_valid <= 1'b0;
            summary_pixels <= 9'd0;
            summary_first_x <= 9'd320;
            summary_last_x <= 9'd0;
            summary_y <= 8'd0;
            geometry_ok <= 1'b0;
            run_active <= 1'b0;
            gap_rows <= 4'd0;
            run_area <= 16'd0;
            run_first_y <= 8'd0;
            best_area <= 16'd0;
            best_first_y <= 8'd0;
            all_left <= 9'd320;
            all_right <= 9'd0;
            all_last_y <= 8'd0;
            O_done <= 1'b0;
            O_box_valid <= 1'b0;
            O_x0 <= 11'd0;
            O_y0 <= 10'd0;
            O_x1 <= 11'd0;
            O_y1 <= 10'd0;
        end else begin
            O_done <= 1'b0;
            O_box_valid <= 1'b0;
            summary_valid <= 1'b0;
            if (state == IDLE && I_candidate_done) begin
                if (I_candidate_valid && proposed_left < proposed_right) begin
                    left <= proposed_left;
                    right <= proposed_right;
                    read_x <= proposed_left;
                    read_y <= 8'd8;
                    row_pixels <= 9'd0;
                    row_first_x <= 9'd320;
                    row_last_x <= 9'd0;
                    island_active <= 1'b0;
                    island_gap <= 4'd0;
                    island_first_x <= 9'd320;
                    island_last_x <= 9'd0;
                    island_pixels <= 9'd0;
                    anchor_left <= proposed_anchor_left;
                    anchor_right <= proposed_anchor_right;
                    strong_valid <= I_strong_valid;
                    strong_left <= I_strong_left;
                    strong_right <= I_strong_right;
                    summary_valid <= 1'b0;
                    row_min <= (proposed_row_min > 9'd6) ? proposed_row_min : 9'd6;
                    geometry_ok <= span_width <= 9'd90;
                    run_active <= 1'b0;
                    gap_rows <= 4'd0;
                    run_area <= 16'd0;
                    best_area <= 16'd0;
                    all_left <= 9'd320;
                    all_right <= 9'd0;
                    all_last_y <= 8'd0;
                    state <= SCAN;
                end else begin
                    O_done <= 1'b1;
                end
            end
            if (state == SCAN) begin
                if (read_x == right - 9'd1) begin
                    read_x <= left;
                    if (read_y == 8'd179)
                        state <= WAIT_LAST;
                    else
                        read_y <= read_y + 8'd1;
                end else begin
                    read_x <= read_x + 9'd1;
                end
            end
            if (I_mask_valid) begin
                if (row_end) begin
                    summary_valid <= 1'b1;
                    summary_pixels <= next_row_pixels;
                    summary_first_x <= accepted_row_first_x;
                    summary_last_x <= accepted_row_last_x;
                    summary_y <= I_mask_y;
                    row_pixels <= 9'd0;
                    row_first_x <= 9'd320;
                    row_last_x <= 9'd0;
                    island_active <= 1'b0;
                    island_gap <= 4'd0;
                    island_pixels <= 9'd0;
                end else begin
                    row_pixels <= next_row_pixels;
                    row_first_x <= next_row_first_x;
                    row_last_x <= next_row_last_x;
                    island_active <= next_island_active;
                    island_first_x <= next_island_first_x;
                    island_last_x <= next_island_last_x;
                    island_pixels <= next_island_pixels;
                    if (I_mask_pixel)
                        island_gap <= 4'd0;
                    else if (island_gap < 4'd9)
                        island_gap <= island_gap + 4'd1;
                end
            end
            if (summary_valid) begin
                if (row_occupied) begin
                    run_active <= 1'b1;
                    gap_rows <= 4'd0;
                    run_area <= merged_area;
                    if (!run_active)
                        run_first_y <= summary_y;
                    all_left <= merged_left;
                    all_right <= merged_right;
                    all_last_y <= summary_y;
                end else if (run_active) begin
                    if (gap_rows == 4'd15) begin
                        if (run_area > best_area) begin
                            best_area <= run_area;
                            best_first_y <= run_first_y;
                        end
                        run_active <= 1'b0;
                        gap_rows <= 4'd0;
                    end else begin
                        gap_rows <= gap_rows + 4'd1;
                    end
                end
                if (summary_y == 8'd179)
                    state <= FINALIZE;
            end
            if (state == FINALIZE) begin
                O_done <= 1'b1;
                O_box_valid <= final_valid;
                if (final_valid) begin
                    O_x0 <= {final_left, 2'b00};
                    O_x1 <= {final_right, 2'b00};
                    O_y0 <= (selected_first_y >= 8'd3) ?
                            {selected_first_y - 8'd2, 2'b00} : 10'd4;
                    O_y1 <= (padded_bottom >= {1'b0, DISPLAY_Y_END}) ?
                            DISPLAY_Y_END : padded_bottom[9:0];
                end
                state <= IDLE;
            end
        end
    end
endmodule

// Four grayscale samples per clock, matching the pre-repacker RGB96 beat.
// Background samples and the signed exposure correction are supplied by
// separate blocks; this stage does not allocate a frame buffer.
module foreground_diff4 #(
    parameter [7:0] THRESHOLD = 8'd35
)(
    input  wire               I_clk,
    input  wire               I_rst_n,
    input  wire               I_valid,
    input  wire [31:0]        I_gray,
    input  wire [31:0]        I_background,
    input  wire signed [8:0]  I_exposure_offset,
    output reg                O_valid,
    output reg  [3:0]         O_foreground
);
    genvar lane;
    generate
        for (lane = 0; lane < 4; lane = lane + 1) begin : g_lane
            wire signed [9:0] delta =
                $signed({2'b00, I_gray[lane*8 +: 8]}) -
                $signed({2'b00, I_background[lane*8 +: 8]}) -
                {{1{I_exposure_offset[8]}}, I_exposure_offset};
            wire [9:0] magnitude = delta[9] ? -delta : delta;
            always @(posedge I_clk or negedge I_rst_n) begin
                if (!I_rst_n)
                    O_foreground[lane] <= 1'b0;
                else
                    O_foreground[lane] <= I_valid && (magnitude > {2'b00, THRESHOLD});
            end
        end
    endgenerate

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n)
            O_valid <= 1'b0;
        else
            O_valid <= I_valid;
    end
endmodule

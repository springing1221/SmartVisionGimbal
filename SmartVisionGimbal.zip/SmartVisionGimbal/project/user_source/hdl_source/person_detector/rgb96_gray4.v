// Four RGB888 pixels from the 96-bit AWB stream, before 96-to-128 packing.
// Approximate OpenCV's grayscale coefficients with a sum divided by 256.
module rgb96_gray4 (
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire        I_valid,
    input  wire [95:0] I_rgb,
    output reg         O_valid,
    output reg  [31:0] O_gray
);
    genvar lane;
    reg [95:0] rgb_d;
    reg valid_d;
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            rgb_d <= 96'd0;
            valid_d <= 1'b0;
        end else begin
            rgb_d <= I_rgb;
            valid_d <= I_valid;
        end
    end
    generate
        for (lane = 0; lane < 4; lane = lane + 1) begin : g_lane
            wire [23:0] rgb = rgb_d[lane*24 +: 24];
            wire [7:0] r = rgb[23:16];
            wire [7:0] g = rgb[15:8];
            wire [7:0] b = rgb[7:0];
            wire [15:0] re = {8'd0, r};
            wire [15:0] ge = {8'd0, g};
            wire [15:0] be = {8'd0, b};
            wire [15:0] weighted =
                (re << 6) + (re << 3) + (re << 2) + re +
                (ge << 7) + (ge << 4) + (ge << 2) + (ge << 1) +
                (be << 4) + (be << 3) + (be << 2) + be + 16'd128;
            always @(posedge I_clk or negedge I_rst_n) begin
                if (!I_rst_n)
                    O_gray[lane*8 +: 8] <= 8'd0;
                else
                    O_gray[lane*8 +: 8] <= weighted[15:8];
            end
        end
    endgenerate

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n)
            O_valid <= 1'b0;
        else
            O_valid <= valid_d;
    end
endmodule

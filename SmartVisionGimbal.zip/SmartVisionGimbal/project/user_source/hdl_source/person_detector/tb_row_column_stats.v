`timescale 1ns/1ps
module tb_row_column_stats;
    reg clk = 1'b0;
    always #5 clk = ~clk;
    reg rst_n = 1'b0;
    reg frame_start = 1'b0;
    reg valid = 1'b0;
    reg foreground = 1'b0;
    reg strong_foreground = 1'b0;
    reg [8:0] x = 9'd0;
    reg [7:0] y = 8'd0;
    wire [8:0] read_x;
    wire [7:0] count;
    wire [7:0] strong_count;
    wire ready;
    wire overrun;
    wire done;
    wire candidate_valid;
    wire [8:0] left;
    wire [8:0] right;
    wire strong_valid;
    wire [8:0] strong_left, strong_right;
    integer result_count = 0;
    integer ix;
    integer iy;

    row_column_stats stats (
        .I_clk(clk), .I_rst_n(rst_n), .I_frame_start(frame_start),
        .I_valid(valid), .I_foreground(foreground),
        .I_strong_foreground(strong_foreground), .I_x(x), .I_y(y),
        .I_read_x(read_x), .O_column_count(count),
        .O_strong_column_count(strong_count),
        .O_frame_ready(ready), .O_overrun(overrun)
    );
    candidate_span scanner (
        .I_clk(clk), .I_rst_n(rst_n), .I_frame_ready(ready),
        .I_column_count(count), .I_strong_column_count(strong_count),
        .O_read_x(read_x), .O_done(done),
        .O_candidate_valid(candidate_valid), .O_left(left), .O_right(right),
        .O_strong_valid(strong_valid),
        .O_strong_left(strong_left), .O_strong_right(strong_right)
    );

    task send_row;
        input integer row_y;
        input integer mode;
        begin
            for (ix = 0; ix < 320; ix = ix + 1) begin
                @(negedge clk);
                valid = 1'b1;
                x = ix;
                y = row_y;
                foreground = (mode == 2) ||
                             ((mode == 1) && ix >= 60 && ix < 130) ||
                             ((mode == 3) && ix >= 70 && ix < 90);
                strong_foreground = (mode == 2) ||
                                    ((mode == 1) && ix >= 100 && ix < 130) ||
                                    ((mode == 3) && ix >= 70 && ix < 90);
            end
            @(negedge clk);
            valid = 1'b0;
            foreground = 1'b0;
            strong_foreground = 1'b0;
            repeat (325) @(negedge clk);
        end
    endtask

    always @(negedge clk) begin
        if (done) begin
            result_count = result_count + 1;
            if (result_count == 1 &&
                (!candidate_valid || left != 60 || right != 130 ||
                 !strong_valid || strong_left != 100 ||
                 strong_right != 129 || overrun))
                $fatal(1, "first frame failed: core=[%d,%d] strong=[%d,%d]",
                       left, right, strong_left, strong_right);
            if (result_count == 2 && (candidate_valid || strong_valid || overrun))
                $fatal(1, "empty second frame reused an old candidate");
        end
    end

    initial begin
        repeat (3) @(negedge clk);
        rst_n = 1'b1;
        @(negedge clk);
        frame_start = 1'b1;
        @(negedge clk);
        frame_start = 1'b0;
        for (iy = 20; iy <= 100; iy = iy + 1)
            send_row(iy, iy == 50 ? 2 : 1);
        for (iy = 150; iy <= 170; iy = iy + 1)
            send_row(iy, 3);
        send_row(179, 0);
        repeat (2200) @(negedge clk);
        if (result_count != 1)
            $fatal(1, "first frame did not complete");
        frame_start = 1'b1;
        @(negedge clk);
        frame_start = 1'b0;
        send_row(179, 0);
        repeat (1500) @(negedge clk);
        if (result_count != 2)
            $fatal(1, "second frame did not complete");
        $display("ROW_COLUMN_STATS_OK");
        $finish;
    end
endmodule

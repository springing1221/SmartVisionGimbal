// Buffer one 320-pixel sample row, reject broad exposure-artifact rows,
// and accumulate weak/strong foreground columns for rows 8..144.
// Cleared mask pixels are also streamed through the last sampled image row.
module row_column_stats (
    input  wire       I_clk,
    input  wire       I_rst_n,
    input  wire       I_frame_start,
    input  wire       I_valid,
    input  wire       I_foreground,
    input  wire       I_strong_foreground,
    input  wire [8:0] I_x,
    input  wire [7:0] I_y,
    input  wire [8:0] I_read_x,
    output reg  [7:0] O_column_count,
    output reg  [7:0] O_strong_column_count,
    output reg        O_frame_ready,
    output reg        O_overrun,
    output reg        O_mask_valid,
    output reg        O_mask_pixel,
    output reg  [8:0] O_mask_x,
    output reg  [7:0] O_mask_y
);
    reg line_bits [0:319];
    reg strong_line_bits [0:319];
    reg [7:0] column_count [0:319];
    reg [7:0] strong_column_count [0:319];
    reg column_tag [0:319];
    reg frame_tag;
    reg [8:0] row_sum;
    reg drain;
    reg [8:0] drain_x;
    reg [7:0] drain_y;
    reg row_accept;
    integer i;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n)
            O_column_count <= 8'd0;
        else
            O_column_count <= (I_read_x < 9'd320 &&
                               column_tag[I_read_x] == frame_tag) ?
                               column_count[I_read_x] : 8'd0;
        if (!I_rst_n)
            O_strong_column_count <= 8'd0;
        else
            O_strong_column_count <= (I_read_x < 9'd320 &&
                                      column_tag[I_read_x] == frame_tag) ?
                                      strong_column_count[I_read_x] : 8'd0;
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            frame_tag <= 1'b0;
            row_sum <= 9'd0;
            drain <= 1'b0;
            drain_x <= 9'd0;
            drain_y <= 8'd0;
            row_accept <= 1'b0;
            O_frame_ready <= 1'b0;
            O_overrun <= 1'b0;
            O_mask_valid <= 1'b0;
            O_mask_pixel <= 1'b0;
            O_mask_x <= 9'd0;
            O_mask_y <= 8'd0;
            for (i = 0; i < 320; i = i + 1) begin
                column_count[i] <= 8'd0;
                strong_column_count[i] <= 8'd0;
                column_tag[i] <= 1'b0;
            end
        end else if (I_frame_start) begin
            frame_tag <= ~frame_tag;
            for (i = 0; i < 320; i = i + 1)
                column_tag[i] <= frame_tag;
            row_sum <= 9'd0;
            drain <= 1'b0;
            O_frame_ready <= 1'b0;
            O_overrun <= 1'b0;
            O_mask_valid <= 1'b0;
        end else begin
            O_mask_valid <= 1'b0;
            if (drain) begin
                O_mask_valid <= 1'b1;
                O_mask_pixel <= row_accept && line_bits[drain_x];
                O_mask_x <= drain_x;
                O_mask_y <= drain_y;
                if (column_tag[drain_x] != frame_tag) begin
                    column_count[drain_x] <=
                        drain_y < 8'd145 && row_accept && line_bits[drain_x] ?
                        8'd1 : 8'd0;
                    strong_column_count[drain_x] <=
                        drain_y < 8'd145 && row_accept &&
                        strong_line_bits[drain_x] ? 8'd1 : 8'd0;
                    column_tag[drain_x] <= frame_tag;
                end else begin
                    if (drain_y < 8'd145 && row_accept && line_bits[drain_x])
                        column_count[drain_x] <= column_count[drain_x] + 8'd1;
                    if (drain_y < 8'd145 && row_accept &&
                        strong_line_bits[drain_x])
                        strong_column_count[drain_x] <=
                            strong_column_count[drain_x] + 8'd1;
                end
                if (drain_x == 9'd319) begin
                    drain <= 1'b0;
                    if (drain_y == 8'd179)
                        O_frame_ready <= 1'b1;
                end else begin
                    drain_x <= drain_x + 9'd1;
                end
            end

            if (I_valid && I_y >= 8'd8 && I_y <= 8'd179 && I_x < 9'd320) begin
                if (drain) begin
                    O_overrun <= 1'b1;
                end else begin
                    line_bits[I_x] <= I_foreground;
                    strong_line_bits[I_x] <= I_strong_foreground;
                    if (I_x == 9'd0)
                        row_sum <= {8'd0, I_foreground};
                    else
                        row_sum <= row_sum + {8'd0, I_foreground};
                    if (I_x == 9'd319) begin
                        row_accept <= (row_sum + {8'd0, I_foreground}) <= 9'd208;
                        drain_y <= I_y;
                        drain_x <= 9'd0;
                        drain <= 1'b1;
                    end
                end
            end
        end
    end
endmodule

// Sample one pixel from each four-pixel beat on every fourth video line.
// Assert I_capture for at least one clock before a frame-start pulse while
// the scene is empty. The captured 320x180 grayscale frame is then held.
module background_sample (
    input  wire       I_clk,
    input  wire       I_rst_n,
    input  wire       I_capture,
    input  wire       I_frame_start,
    input  wire       I_line_end,
    input  wire       I_valid,
    input  wire [31:0] I_gray,
    output reg        O_valid,
    output reg  [7:0] O_gray,
    output reg  [7:0] O_background,
    output reg  [8:0] O_x,
    output reg  [7:0] O_y,
    output reg        O_background_ready
);
    reg [7:0] background [0:57599];
    reg [8:0] beat_x;
    reg [9:0] line_y;
    reg [15:0] address;
    reg capture_pending;
    reg capturing;
    reg [15:0] captured_count;

    wire [8:0] current_x = I_frame_start ? 9'd0 : beat_x;
    wire [9:0] current_y = I_frame_start ? 10'd0 : line_y;
    wire [15:0] current_address = I_frame_start ? 16'd0 : address;
    wire capture_this_frame = I_frame_start && (capture_pending || I_capture);
    wire sample_pixel = I_valid && (current_y[1:0] == 2'b00) &&
                        (current_x < 9'd320) && (current_y < 10'd720);

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            beat_x <= 9'd0;
            line_y <= 10'd0;
            address <= 16'd0;
            capture_pending <= 1'b0;
            capturing <= 1'b0;
            captured_count <= 16'd0;
            O_valid <= 1'b0;
            O_gray <= 8'd0;
            O_background <= 8'd0;
            O_x <= 9'd0;
            O_y <= 8'd0;
            O_background_ready <= 1'b0;
        end else begin
            O_valid <= 1'b0;
            if (I_capture)
                capture_pending <= 1'b1;

            if (I_frame_start) begin
                beat_x <= 9'd0;
                line_y <= 10'd0;
                address <= 16'd0;
                if (capture_this_frame) begin
                    capturing <= 1'b1;
                    captured_count <= 16'd0;
                    capture_pending <= 1'b0;
                    O_background_ready <= 1'b0;
                end else if (capturing) begin
                    capturing <= 1'b0;
                    O_background_ready <= (captured_count == 16'd57600);
                end
            end

            if (I_line_end) begin
                beat_x <= 9'd0;
                if (current_y < 10'd720)
                    line_y <= current_y + 10'd1;
            end else if (I_valid && current_x < 9'd320) begin
                beat_x <= current_x + 9'd1;
            end

            if (sample_pixel) begin
                if (capture_this_frame || (capturing && !I_frame_start)) begin
                    background[current_address] <= I_gray[7:0];
                    captured_count <= capture_this_frame ? 16'd1 : captured_count + 16'd1;
                end else if (!capture_this_frame &&
                             (O_background_ready ||
                              (I_frame_start && capturing && captured_count == 16'd57600))) begin
                    O_gray <= I_gray[7:0];
                    O_background <= background[current_address];
                    O_x <= current_x;
                    O_y <= current_y[9:2];
                    O_valid <= 1'b1;
                end
                address <= current_address + 16'd1;
            end
        end
    end
endmodule

// Estimate global brightness shift from two 32x32 wall patches.
// The result is applied to the next frame, as required by a streaming path.
module exposure_offset (
    input  wire              I_clk,
    input  wire              I_rst_n,
    input  wire              I_frame_start,
    input  wire              I_valid,
    input  wire [8:0]        I_x,
    input  wire [7:0]        I_y,
    input  wire [7:0]        I_gray,
    input  wire [7:0]        I_background,
    output reg signed [8:0] O_offset
);
    reg signed [18:0] left_sum;
    reg signed [18:0] right_sum;
    reg [10:0] left_count;
    reg [10:0] right_count;
    wire signed [8:0] delta =
        $signed({1'b0, I_gray}) - $signed({1'b0, I_background});
    wire signed [18:0] extended_delta = {{10{delta[8]}}, delta};
    wire left_patch = (I_x >= 9'd8) && (I_x < 9'd40) &&
                      (I_y >= 8'd20) && (I_y < 8'd52);
    wire right_patch = (I_x >= 9'd280) && (I_x < 9'd312) &&
                       (I_y >= 8'd20) && (I_y < 8'd52);

    function signed [8:0] mean1024;
        input signed [18:0] value;
        begin
            if (value < 0)
                mean1024 = -((-value) >>> 10);
            else
                mean1024 = value >>> 10;
        end
    endfunction

    wire signed [8:0] left_mean = mean1024(left_sum);
    wire signed [8:0] right_mean = mean1024(right_sum);

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            left_sum <= 19'sd0;
            right_sum <= 19'sd0;
            left_count <= 11'd0;
            right_count <= 11'd0;
            O_offset <= 9'sd0;
        end else if (I_frame_start) begin
            if (left_count == 11'd1024 && right_count == 11'd1024)
                O_offset <= (left_mean > right_mean) ? left_mean : right_mean;
            left_sum <= 19'sd0;
            right_sum <= 19'sd0;
            left_count <= 11'd0;
            right_count <= 11'd0;
        end else if (I_valid) begin
            if (left_patch) begin
                left_sum <= left_sum + extended_delta;
                left_count <= left_count + 11'd1;
            end
            if (right_patch) begin
                right_sum <= right_sum + extended_delta;
                right_count <= right_count + 11'd1;
            end
        end
    end
endmodule

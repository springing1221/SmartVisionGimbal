/*
 * 帧平均亮度跨时钟域模块
 *
 * I_frame_done 是视频时钟域中的单周期脉冲。若直接将该脉冲同步到
 * I_dst_clk 域，目标时钟可能在整个脉冲期间都未采样到高电平，造成
 * 帧事件丢失。因此这里使用 toggle 事件而非直接同步脉冲。
 */
module luma_cdc
(
    input  wire       I_src_clk,
    input  wire       I_src_rst_n,
    input  wire [7:0] I_avg_luma,
    input  wire       I_frame_done,

    input  wire       I_dst_clk,
    input  wire       I_dst_rst_n,
    output reg  [7:0] O_avg_luma,
    output reg        O_new_luma
);

    /*
     * 源时钟域：先锁存整帧亮度，再翻转事件位。
     * 亮度保持至下一帧完成，远长于目标域同步和采样所需的几个时钟，
     * 因此可按 bundled-data（数据随事件保持）方式跨域。
     */
    reg [7:0] S_luma_hold;
    reg       S_luma_toggle;

    always @(posedge I_src_clk or negedge I_src_rst_n) begin
        if (!I_src_rst_n) begin
            S_luma_hold   <= 8'd0;
            S_luma_toggle <= 1'b0;
        end else if (I_frame_done) begin
            S_luma_hold   <= I_avg_luma;
            S_luma_toggle <= ~S_luma_toggle;
        end
    end

    /*
     * 目标时钟域：toggle 经过两级寄存器同步后，比较当前值和已处理值。
     * toggle 状态会一直保持到下一帧事件，故不会像单周期脉冲那样漏采。
     */
    reg S_toggle_sync1;
    reg S_toggle_sync2;
    reg S_toggle_seen;
    reg [1:0] S_capture_delay;

    always @(posedge I_dst_clk or negedge I_dst_rst_n) begin
        if (!I_dst_rst_n) begin
            S_toggle_sync1  <= 1'b0;
            S_toggle_sync2  <= 1'b0;
            S_toggle_seen   <= 1'b0;
            S_capture_delay <= 2'd0;
            O_avg_luma      <= 8'd0;
            O_new_luma      <= 1'b0;
        end else begin
            /* 两级同步器只用于单 bit toggle，降低亚稳态传播风险。 */
            S_toggle_sync1 <= S_luma_toggle;
            S_toggle_sync2 <= S_toggle_sync1;

            /* 默认拉低，O_new_luma 仅在亮度锁存周期内为高。 */
            O_new_luma <= 1'b0;

            if ((S_capture_delay == 2'd0) &&
                (S_toggle_sync2 != S_toggle_seen)) begin
                /*
                 * 已发现新事件。先记住该 toggle，再额外等待两个目标时钟，
                 * 使源域锁存的 8-bit 总线具有充足稳定时间后再读取。
                 * 不能把 8 个 bit 分别同步后立即拼接使用，否则各 bit 的
                 * 到达周期可能不同，形成错误的中间码。
                 */
                S_toggle_seen   <= S_toggle_sync2;
                S_capture_delay <= 2'd2;
            end else if (S_capture_delay != 2'd0) begin
                S_capture_delay <= S_capture_delay - 1'b1;
                if (S_capture_delay == 2'd1) begin
                    /* 数据已稳定：在同一周期更新数据并发出一个周期通知。 */
                    O_avg_luma <= S_luma_hold;
                    O_new_luma <= 1'b1;
                end
            end
        end
    end

endmodule

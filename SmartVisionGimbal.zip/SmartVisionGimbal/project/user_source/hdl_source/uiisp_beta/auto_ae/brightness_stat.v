/*
 * 帧亮度统计模块
 *
 * 本模块只观察 Demosaic 后、AWB 前的 96-bit RGB888 数据流，不产生视频
 * 数据输出，也不参与 AXI-Stream 的 ready 握手，因此不会阻塞原有视频通路。
 */
module brightness_stat
(
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire [95:0] I_tdata,
    input  wire        I_tvalid,
    input  wire        I_tuser,
    input  wire        I_tlast,

    output reg  [7:0]  O_avg_luma,
    output reg         O_frame_done
);

    /*
     * 96-bit RGB888 排列已按现有 awb.v 的拆包方式确认：
     *   像素0 = I_tdata[23:0]   = {R[23:16], G[15:8], B[7:0]}
     *   像素1 = I_tdata[47:24]  = {R[47:40], G[39:32], B[31:24]}
     *   像素2 = I_tdata[71:48]  = {R[71:64], G[63:56], B[55:48]}
     *   像素3 = I_tdata[95:72]  = {R[95:88], G[87:80], B[79:72]}
     */
    wire [7:0] S_r0;
    wire [7:0] S_g0;
    wire [7:0] S_b0;
    wire [7:0] S_r1;
    wire [7:0] S_g1;
    wire [7:0] S_b1;
    wire [7:0] S_r2;
    wire [7:0] S_g2;
    wire [7:0] S_b2;
    wire [7:0] S_r3;
    wire [7:0] S_g3;
    wire [7:0] S_b3;

    assign S_r0 = I_tdata[23:16];
    assign S_g0 = I_tdata[15:8];
    assign S_b0 = I_tdata[7:0];
    assign S_r1 = I_tdata[47:40];
    assign S_g1 = I_tdata[39:32];
    assign S_b1 = I_tdata[31:24];
    assign S_r2 = I_tdata[71:64];
    assign S_g2 = I_tdata[63:56];
    assign S_b2 = I_tdata[55:48];
    assign S_r3 = I_tdata[95:88];
    assign S_g3 = I_tdata[87:80];
    assign S_b3 = I_tdata[79:72];

    /*
     * 单像素亮度近似：Y = (R + 2*G + B) / 4。
     * 2*G 用左移实现，除以 4 用右移实现；中间加法最大为 1020，
     * 所以使用 10-bit 中间量。
     */
    function [7:0] calc_luma;
        input [7:0] r;
        input [7:0] g;
        input [7:0] b;
        reg   [9:0] rgb_sum;
        begin
            rgb_sum = {2'b00, r} + {1'b0, g, 1'b0} + {2'b00, b};
            calc_luma = rgb_sum[9:2];
        end
    endfunction

    wire [7:0] S_luma0;
    wire [7:0] S_luma1;
    wire [7:0] S_luma2;
    wire [7:0] S_luma3;
    wire [9:0] S_beat_luma;

    assign S_luma0 = calc_luma(S_r0, S_g0, S_b0);
    assign S_luma1 = calc_luma(S_r1, S_g1, S_b1);
    assign S_luma2 = calc_luma(S_r2, S_g2, S_b2);
    assign S_luma3 = calc_luma(S_r3, S_g3, S_b3);

    /* 每个有效时钟的四个像素亮度之和，范围为 0~1020。 */
    assign S_beat_luma = {2'b00, S_luma0} + {2'b00, S_luma1} +
                          {2'b00, S_luma2} + {2'b00, S_luma3};

    /*
     * 1280*720 = 921600 个像素，最大亮度累计值为
     * 921600*255 = 235008000，小于 2^28 = 268435456，
     * 故帧累加器使用 28 bit，包含当前拍相加后的最大值也不会溢出。
     */
    reg  [27:0] S_luma_sum;
    reg  [9:0]  S_line_count;
    reg         S_frame_active;

    /*
     * 在最后一拍，将寄存器中的累计值和当前拍相加后进行固定尺寸归一化。
     *
     * 921600 = 4096 * 225。先右移 12 bit（除以 4096），再乘以
     * ceil(2^24/225)=74566 并右移 24 bit，得到除以 225 的精确整数商。
     * 对本模块的输入范围（最大 235008000）而言，该常数乘法结果与
     * floor(总亮度/921600) 一致。这样综合为移位和常数乘法，不会实例化
     * 运行时除法器。
     */
    wire [27:0] S_luma_sum_with_beat;
    wire [15:0] S_luma_div_4096;
    wire [32:0] S_luma_recip_product;
    wire [7:0]  S_frame_avg_luma;

    assign S_luma_sum_with_beat = S_luma_sum + {18'd0, S_beat_luma};
    assign S_luma_div_4096      = S_luma_sum_with_beat[27:12];
    assign S_luma_recip_product = S_luma_div_4096 * 17'd74566;
    assign S_frame_avg_luma     = S_luma_recip_product[31:24];

    /*
     * I_tuser 表示一帧第一个有效拍：立即清除旧帧累计并计入该拍。
     * I_tlast 表示当前行最后一个有效拍。S_line_count 保存当前行号
     * （第一行为 0）；第 720 行的 I_tlast 到来时，锁存包含该拍的
     * 全帧平均值，并将 O_frame_done 拉高一个时钟。下一帧 I_tuser
     * 再次到来时重新启动统计。
     */
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            S_luma_sum    <= 28'd0;
            S_line_count  <= 10'd0;
            S_frame_active <= 1'b0;
            O_avg_luma    <= 8'd0;
            O_frame_done  <= 1'b0;
        end else begin
            O_frame_done <= 1'b0;

            if (I_tvalid) begin
                if (I_tuser) begin
                    /* 帧开始拍也属于新帧，不能遗漏。 */
                    S_luma_sum     <= {18'd0, S_beat_luma};
                    S_line_count   <= I_tlast ? 10'd1 : 10'd0;
                    S_frame_active <= 1'b1;
                end else if (S_frame_active) begin
                    if (I_tlast && (S_line_count == 10'd719)) begin
                        /* 第 720 行末：结果包含当前有效拍的四个像素。 */
                        O_avg_luma    <= S_frame_avg_luma;
                        O_frame_done  <= 1'b1;
                        S_luma_sum    <= 28'd0;
                        S_line_count  <= 10'd0;
                        S_frame_active <= 1'b0;
                    end else begin
                        S_luma_sum <= S_luma_sum_with_beat;
                        if (I_tlast)
                            S_line_count <= S_line_count + 1'b1;
                    end
                end
            end
        end
    end

endmodule

/*
 * 简单分级步进自动曝光控制器
 *
 * 本模块工作在摄像头/I2C 控制时钟域。它只生成 AE/AG 数值和单周期
 * 请求脉冲，不包含 I2C 逻辑，也不直接连接视频时钟域。
 */
module auto_ae_ctrl #(
    parameter [7:0]  LUMA_LOW = 8'd95,
    parameter [7:0]  LUMA_HIGH = 8'd125,
    parameter [15:0] AG_STEP = 16'd4
)
(
    input  wire        I_clk,
    input  wire        I_rst_n,
    input  wire [7:0]  I_avg_luma,
    input  wire        I_new_luma,
    input  wire        I_cam_cfg_done,
    input  wire        I_ae_cfg_done,
    input  wire        I_key1_n,
    input  wire        I_key2_n,
    input  wire        I_key3_n,
    input  wire        I_key4_n,

    output reg         O_ae_req,
    output reg  [15:0] O_ae,
    output reg  [15:0] O_ag,
    output wire [15:0] O_debug_ae_step,
    output wire [15:0] O_debug_update_frames
);

    /* 与官方 ae_set.v 保持一致的合法范围。 */
    localparam [15:0] AE_MIN = 16'd2;
    localparam [15:0] AE_MAX = 16'd1991;
    localparam [15:0] AG_MIN = 16'd16;
    localparam [15:0] AG_MAX = 16'd176;

    /* 按键调节的运行时范围和默认值。 */
    localparam [15:0] AE_STEP_MIN = 16'd16;
    localparam [15:0] AE_STEP_MAX = 16'd512;
    localparam [15:0] AE_STEP_DELTA = 16'd16;
    localparam [15:0] UPDATE_FRAMES_MIN = 16'd1;
    localparam [15:0] UPDATE_FRAMES_MAX = 16'd32;
    localparam [18:0] KEY_DEBOUNCE_CYCLES = 19'd480000;

    /*
     * 运行时可调参数：复位后的默认值可通过板载按键修改，无需重新综合。
     * 24 MHz 下 KEY_DEBOUNCE_CYCLES=480000 对应约 20 ms 消抖时间。
     */
    reg [15:0] R_ae_step;
    reg [15:0] R_update_frames;

    /* 四个低有效异步按键的两级同步器。 */
    reg R_key1_sync1, R_key1_sync2;
    reg R_key2_sync1, R_key2_sync2;
    reg R_key3_sync1, R_key3_sync2;
    reg R_key4_sync1, R_key4_sync2;

    /* 消抖后的按键电平：1 为释放，0 为稳定按下。 */
    reg R_key1_stable, R_key2_stable, R_key3_stable, R_key4_stable;
    reg R_key1_stable_d, R_key2_stable_d, R_key3_stable_d, R_key4_stable_d;
    reg [18:0] R_key1_db_count, R_key2_db_count;
    reg [18:0] R_key3_db_count, R_key4_db_count;

    wire S_key1_pressed;
    wire S_key2_pressed;
    wire S_key3_pressed;
    wire S_key4_pressed;

    assign S_key1_pressed = R_key1_stable_d && !R_key1_stable;
    assign S_key2_pressed = R_key2_stable_d && !R_key2_stable;
    assign S_key3_pressed = R_key3_stable_d && !R_key3_stable;
    assign S_key4_pressed = R_key4_stable_d && !R_key4_stable;

    assign O_debug_ae_step       = R_ae_step;
    assign O_debug_update_frames = R_update_frames;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            R_key1_sync1 <= 1'b1;
            R_key1_sync2 <= 1'b1;
            R_key2_sync1 <= 1'b1;
            R_key2_sync2 <= 1'b1;
            R_key3_sync1 <= 1'b1;
            R_key3_sync2 <= 1'b1;
            R_key4_sync1 <= 1'b1;
            R_key4_sync2 <= 1'b1;
        end else begin
            R_key1_sync1 <= I_key1_n;
            R_key1_sync2 <= R_key1_sync1;
            R_key2_sync1 <= I_key2_n;
            R_key2_sync2 <= R_key2_sync1;
            R_key3_sync1 <= I_key3_n;
            R_key3_sync2 <= R_key3_sync1;
            R_key4_sync1 <= I_key4_n;
            R_key4_sync2 <= R_key4_sync1;
        end
    end

    /* 同步后的电平连续保持约 20 ms 后，才更新消抖状态。 */
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            R_key1_stable   <= 1'b1;
            R_key2_stable   <= 1'b1;
            R_key3_stable   <= 1'b1;
            R_key4_stable   <= 1'b1;
            R_key1_db_count <= 19'd0;
            R_key2_db_count <= 19'd0;
            R_key3_db_count <= 19'd0;
            R_key4_db_count <= 19'd0;
        end else begin
            if (R_key1_sync2 == R_key1_stable)
                R_key1_db_count <= 19'd0;
            else if (R_key1_db_count == (KEY_DEBOUNCE_CYCLES - 1'b1)) begin
                R_key1_stable   <= R_key1_sync2;
                R_key1_db_count <= 19'd0;
            end else
                R_key1_db_count <= R_key1_db_count + 1'b1;

            if (R_key2_sync2 == R_key2_stable)
                R_key2_db_count <= 19'd0;
            else if (R_key2_db_count == (KEY_DEBOUNCE_CYCLES - 1'b1)) begin
                R_key2_stable   <= R_key2_sync2;
                R_key2_db_count <= 19'd0;
            end else
                R_key2_db_count <= R_key2_db_count + 1'b1;

            if (R_key3_sync2 == R_key3_stable)
                R_key3_db_count <= 19'd0;
            else if (R_key3_db_count == (KEY_DEBOUNCE_CYCLES - 1'b1)) begin
                R_key3_stable   <= R_key3_sync2;
                R_key3_db_count <= 19'd0;
            end else
                R_key3_db_count <= R_key3_db_count + 1'b1;

            if (R_key4_sync2 == R_key4_stable)
                R_key4_db_count <= 19'd0;
            else if (R_key4_db_count == (KEY_DEBOUNCE_CYCLES - 1'b1)) begin
                R_key4_stable   <= R_key4_sync2;
                R_key4_db_count <= 19'd0;
            end else
                R_key4_db_count <= R_key4_db_count + 1'b1;
        end
    end

    /* 对稳定按键的下降沿检测，长按只会形成一次单周期按下事件。 */
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            R_key1_stable_d <= 1'b1;
            R_key2_stable_d <= 1'b1;
            R_key3_stable_d <= 1'b1;
            R_key4_stable_d <= 1'b1;
        end else begin
            R_key1_stable_d <= R_key1_stable;
            R_key2_stable_d <= R_key2_stable;
            R_key3_stable_d <= R_key3_stable;
            R_key4_stable_d <= R_key4_stable;
        end
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            R_ae_step       <= 16'd64;
            R_update_frames <= 16'd8;
        end else begin
            /* KEY1/KEY2 调 AE_STEP，KEY3/KEY4 调帧更新间隔。 */
            if (S_key1_pressed) begin
                if (R_ae_step <= (AE_STEP_MIN + AE_STEP_DELTA))
                    R_ae_step <= AE_STEP_MIN;
                else
                    R_ae_step <= R_ae_step - AE_STEP_DELTA;
            end else if (S_key2_pressed) begin
                if (R_ae_step >= (AE_STEP_MAX - AE_STEP_DELTA))
                    R_ae_step <= AE_STEP_MAX;
                else
                    R_ae_step <= R_ae_step + AE_STEP_DELTA;
            end

            if (S_key3_pressed) begin
                if (R_update_frames <= UPDATE_FRAMES_MIN)
                    R_update_frames <= UPDATE_FRAMES_MIN;
                else
                    R_update_frames <= R_update_frames - 1'b1;
            end else if (S_key4_pressed) begin
                if (R_update_frames >= UPDATE_FRAMES_MAX)
                    R_update_frames <= UPDATE_FRAMES_MAX;
                else
                    R_update_frames <= R_update_frames + 1'b1;
            end
        end
    end

    reg [15:0] S_update_frame_count;
    reg        S_wait_cfg;
    reg        S_seen_cfg_busy;
    reg        S_initial_cfg_done;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            /* 官方 ae_set.v 的默认目标值。 */
            O_ae                 <= 16'd1991;
            O_ag                 <= 16'd144;
            O_ae_req             <= 1'b0;
            S_update_frame_count <= 16'd0;
            S_wait_cfg           <= 1'b0;
            S_seen_cfg_busy      <= 1'b0;
            S_initial_cfg_done   <= 1'b0;
        end else begin
            /* 请求默认拉低；仅在真正更新 AE/AG 的一个时钟周期拉高。 */
            O_ae_req <= 1'b0;

            if (S_wait_cfg) begin
                /*
                 * uicfgcs520 收到请求后会把 I_ae_cfg_done 拉低，所有
                 * AE 寄存器写完后再拉高。必须看到低再看到高，才确认
                 * 本次请求已完整执行，期间不允许发出重复请求。
                 */
                if (!I_ae_cfg_done) begin
                    S_seen_cfg_busy <= 1'b1;
                end else if (S_seen_cfg_busy) begin
                    S_wait_cfg      <= 1'b0;
                    S_seen_cfg_busy <= 1'b0;
                    /*
                     * 首次请求同样必须完整经历 I_ae_cfg_done 的低到高。
                     * 至此才确认默认 AE=1991、AG=144 已实际写入传感器，
                     * 后续才允许依据亮度进行自动调节。
                     */
                    if (!S_initial_cfg_done)
                        S_initial_cfg_done <= 1'b1;
                end
            end else if (!S_initial_cfg_done) begin
                /*
                 * 与官方 ae_set.v 复位后让“当前输出值”和“目标值”不同、
                 * 以触发一次默认写入的做法对应。本模块输出本身已经是
                 * 默认目标值，因此用独立状态显式发起一次强制写入，确保
                 * AE=1991、AG=144 真正通过 uicfgcs520 写入 SC520。
                 */
                if (I_cam_cfg_done && I_ae_cfg_done) begin
                    O_ae_req        <= 1'b1;
                    S_wait_cfg      <= 1'b1;
                    S_seen_cfg_busy <= 1'b0;
                end
            end else if (I_new_luma && I_cam_cfg_done && I_ae_cfg_done) begin
                /*
                 * 帧间隔控制：只对已满足配置空闲条件的亮度样本计数。
                 * UPDATE_FRAMES=4 时约每四帧最多调整一次，避免逐帧
                 * 调节导致亮度抖动，也给传感器/I2C 留出稳定时间。
                 */
                if (S_update_frame_count >= (R_update_frames - 1'b1)) begin
                    S_update_frame_count <= 16'd0;

                    /*
                     * 死区 [LUMA_LOW, LUMA_HIGH] 内保持 AE/AG 不变。
                     * 过暗时先提高 AE，AE 到顶后才提高 AG：优先延长
                     * 曝光通常比提高增益引入更少的噪声。
                     */
                    if (I_avg_luma < LUMA_LOW) begin
                        if (O_ae < AE_MAX) begin
                            if ((AE_MAX - O_ae) <= R_ae_step)
                                O_ae <= AE_MAX;
                            else
                                O_ae <= O_ae + R_ae_step;
                            O_ae_req        <= 1'b1;
                            S_wait_cfg      <= 1'b1;
                            S_seen_cfg_busy <= 1'b0;
                        end else if (O_ag < AG_MAX) begin
                            if ((AG_MAX - O_ag) <= AG_STEP)
                                O_ag <= AG_MAX;
                            else
                                O_ag <= O_ag + AG_STEP;
                            O_ae_req        <= 1'b1;
                            S_wait_cfg      <= 1'b1;
                            S_seen_cfg_busy <= 1'b0;
                        end
                    end

                    /*
                     * 过亮时先降低 AG，再降低 AE。先撤掉增益可避免在
                     * 不必要时缩短曝光并保持较好的信噪比；AG 已到最小
                     * 值后才降低 AE。所有更新均在边界处严格限幅。
                     */
                    else if (I_avg_luma > LUMA_HIGH) begin
                        if (O_ag > AG_MIN) begin
                            if ((O_ag - AG_MIN) <= AG_STEP)
                                O_ag <= AG_MIN;
                            else
                                O_ag <= O_ag - AG_STEP;
                            O_ae_req        <= 1'b1;
                            S_wait_cfg      <= 1'b1;
                            S_seen_cfg_busy <= 1'b0;
                        end else if (O_ae > AE_MIN) begin
                            if ((O_ae - AE_MIN) <= R_ae_step)
                                O_ae <= AE_MIN;
                            else
                                O_ae <= O_ae - R_ae_step;
                            O_ae_req        <= 1'b1;
                            S_wait_cfg      <= 1'b1;
                            S_seen_cfg_busy <= 1'b0;
                        end
                    end
                end else begin
                    S_update_frame_count <= S_update_frame_count + 1'b1;
                end
            end
        end
    end

endmodule
